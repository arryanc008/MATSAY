# Demo guide

A 5 to 6 minute walkthrough. Everything here works with no API keys; the notes say what changes if you add them.

## Before you start

- Open https://matsay.vercel.app (or `npm run dev` locally).
- Click **Demo Commander Session** on the login page.
- Keep the Fleet Map in a second tab if you want to switch quickly.

## Script

**1. Command Center (30 s)**
Start here. Point out the KPI cards and the pending recommendations. This is the "single screen" idea from the problem statement.

**2. Fleet Map (45 s)**
Show the vessels, ports, restricted zones and the two storm systems. Zoom into the Arabian Sea / Bay of Bengal area. Click a vessel to open its details panel.
If `AISSTREAM_API_KEY` is set, live AIS vessels also appear.

**3. Weather & Ocean (30 s)**
Select a vessel and show wind, waves and current at its position. This data comes from Open-Meteo in real time.

**4. Fuel Intelligence (60 s)**
Change speed, load, wind and wave height and watch fuel per day, voyage fuel, cost and CO2 change. Say clearly that this is a formula model (Admiralty + weather penalties), not a trained ML model.

**5. Routes (45 s)**
Show the planned route against the optimized one and read the "why was the route changed" panel.

**6. Optimization (60 s)**
Move the objective weights (fuel, cost, CO2, time, utilization, reliability), tick constraints, and run. Open a recommendation.
Be upfront: this run is a simulation of the workflow; the final numbers are illustrative. The real quantum-inspired search is the next milestone.

**7. Human-in-the-loop (30 s)**
On a recommendation choose Approve, Modify or Reject and add a note. With a database configured the decision is saved and shows up in the audit log.

**8. Scenarios and MATSAY Ops (45 s)**
Use the Scenarios sliders (for example fuel price +20%). Then ask MATSAY Ops a fleet question. With `GEMINI_API_KEY` the answer comes from Gemini; without it the screen shows a fallback reply.

## Questions judges may ask

**Is the fleet data real?**
The 6 vessels are a demo dataset. The pipeline for real AIS (AISStream WebSocket) and real weather (Open-Meteo) is built; weather is live now, AIS goes live when a key is added.

**Where is the quantum part?**
The prototype has the multi-objective setup and UI for it. The search itself is simulated at this stage and is on the roadmap. Be honest about this.

**Why different from the stack in the PPT (Next.js, FastAPI, PostGIS, Redis, Mapbox)?**
The prototype was built on React + Vite, Express, PostgreSQL and Leaflet to ship fast. The PPT describes the target architecture; see [ROADMAP.md](ROADMAP.md).

**How is it safe to use AI for decisions?**
It never acts on its own. Every recommendation needs a commander decision and gets logged.
