# Architecture

## Overview

MATSAY is a single Node project. One Express server serves the JSON API and, depending on mode, either the Vite dev middleware or the built static files.

```
Browser (React SPA)
   |  fetch /api/*
   v
Express (server.ts)
   |-- vesselDatabaseService  --> PostgreSQL (Drizzle)   [or demo dataset if no DB]
   |-- metoceanService        --> Open-Meteo APIs        [+ weather_cache table]
   |-- aisStreamManager       --> AISStream.io WebSocket [needs API key]
   `-- /api/ai                --> Google Gemini          [needs API key]
```

The fuel model (`src/services/fuelModel.ts`) and the optimization run (`src/services/optimizationEngine.ts`) run **in the browser**. They are plain TypeScript functions with no server dependency.

## Run modes

| Mode | Command | Behaviour |
|---|---|---|
| Development | `npm run dev` | `tsx server.ts`, Vite mounted as middleware, HMR on |
| Production build | `npm run build` | Vite writes the SPA to `dist/` |
| Vercel | push to repo | `api/index.ts` exports the Express app as a function; `vercel.json` rewrites `/api/*` to it and everything else to `index.html` |

When `process.env.VERCEL` is set, `server.ts` does not call `listen()`; Vercel invokes the exported app instead.

## Frontend

- `App.tsx` does simple path-based routing from a `currentPath` value kept in context (no router library).
- `MaritimeContext` holds the app state: vessels, ports, alerts, messages, optimization weights/constraints, session, audit trail.
- On load and then every 60 seconds, the context calls `/api/health`, `/api/ais/vessels`, `/api/alerts`, `/api/communications`, `/api/audit-logs` and `/api/weather/live` for the active vessel. If a call fails, the UI keeps the demo data it already has.
- The map is built directly with Leaflet (`components/map/FleetGISMap.tsx`) with OpenStreetMap tiles plus an OpenSeaMap seamark overlay.

## Backend

Everything is in `server.ts`. See [API.md](API.md) for the endpoint list.

Fallback rules worth knowing:

- **No database configured**: read endpoints return the built-in demo data; write endpoints return success but store nothing.
- **No AIS key**: the AIS manager stays in `UNAVAILABLE` state and `/api/ais/*` says so.
- **No Gemini key**: `/api/ai` returns `{ available: false }` and the UI shows a fallback reply.

## Database

Tables (see `src/db/schema.ts`):

| Table | Purpose |
|---|---|
| `users` | Planned: Firebase UID to role mapping (not used by the UI yet) |
| `vessels` | Fleet records with position, cargo and fuel data |
| `ports` | Port code, location, berths, average wait |
| `weather_cache` | Open-Meteo responses, reused for 30 minutes within about 0.25 degrees |
| `alerts` | Operational alerts, with an `acknowledged` flag |
| `communications` | Operational messages |
| `audit_logs` | Commander decisions on recommendations |
| `optimization_runs` | Reserved for storing optimization results (not written to yet) |

On startup the server inserts the demo fleet, ports and alerts if the `vessels` table is empty.

## Security notes

- API keys for AIS and Gemini are read on the server only, they are never sent to the browser.
- `firebase-applet-config.json` contains the Firebase **web** config. These values identify the project and are not secret, but you should restrict the API key to your domains in the Google Cloud console.
- `.env*` files are git-ignored except `.env.example`.
- `src/middleware/auth.ts` can verify Firebase ID tokens, but no route uses it yet. Treat all write endpoints as open for now.
