# Fuel and emission model

Source: `src/services/fuelModel.ts`, function `calculateFuelPrediction`.

## Inputs

| Input | Meaning |
|---|---|
| `vessel` | Vessel record (uses deadweight tonnage) |
| `speedKts` | Speed through water |
| `cargoLoadPct` | Cargo utilization, 0 to 100 |
| `distanceNm` | Voyage distance in nautical miles |
| `windSpeedKts`, `windAngleRelDeg` | Wind speed and relative angle (0 = headwind, 180 = following) |
| `waveHeightM` | Significant wave height |
| `currentSpeedKts`, `currentAngleRelDeg` | Current speed and relative angle (0 = adverse, 180 = favourable) |
| `fuelType` | VLSFO, MGO, LNG, Methanol or Ammonia |
| `fuelPricePerMtUsd` | Optional price override |

## Steps

**1. Speed over ground**

```
currentBenefit = currentSpeed * cos(currentAngle)
SOG = max(4, speed + currentBenefit)
```

**2. Displacement and calm-water power (Admiralty formula)**

```
displacement = DWT * 1.15 * (0.4 + 0.6 * cargoLoad/100)
P_calm (kW)  = displacement^(2/3) * speed^3 / 580
```

580 is a generic Admiralty coefficient for a modern hull form. A real vessel needs its own value.

**3. Added resistance from weather**

```
windPenalty% = (wind/20)^1.8 * max(0, cos(windAngle)) * 7.5
wavePenalty% = (waveHeight/1.5)^1.6 * 6.2
P_total      = P_calm * (1 + (windPenalty + wavePenalty)/100)
```

These are simple empirical approximations, in the spirit of the ISO 15016 / Kwon style of correction, not a full implementation of either.

**4. Fuel burn**

```
fuel per day (MT) = P_total * SFOC * 24 / 1,000,000
voyage hours      = distance / SOG
voyage fuel (MT)  = fuel per day / 24 * voyage hours
```

SFOC (g/kWh) used: LNG 165, Methanol 290, everything else 178.

**5. Cost and CO2**

```
cost = voyage fuel * price per MT
CO2  = voyage fuel * emission factor
```

| Fuel | Default price (USD/MT) | CO2 factor (t CO2 / t fuel) |
|---|---|---|
| VLSFO | 645 | 3.114 |
| MGO | 820 | 3.206 |
| LNG | 580 | 2.750 |
| Methanol | 710 | 1.375 |
| Ammonia | 950 | 0.05 |

## Output

`estimatedDurationHours`, `speedOverGroundKts`, `predictedFuelMtPerDay`, `totalPredictedFuelMt`, `fuelCostUsd`, `co2EmissionsTons`, `weatherFuelPenaltyPct`, `currentBenefitKts`, `sfocGramsPerKwh`, `admiraltyCoefficient`.

## Worked example

A 60,000 DWT vessel at 75% load, 14 kn, no wind or waves, no current, VLSFO:

```
displacement = 60000 * 1.15 * (0.4 + 0.6*0.75) = 58,650 t
P_calm       = 58650^(2/3) * 14^3 / 580 = 1509.5 * 2744 / 580 = about 7,140 kW
fuel/day     = 7140 * 178 * 24 / 1e6 = about 30.5 MT
```

Use the Fuel Intelligence screen to try your own numbers.

## Known gaps

- One fixed Admiralty coefficient for every vessel
- Fixed SFOC per fuel type; real engines vary with load
- No hull fouling, trim, draft or sea-margin factors
- Not validated against real consumption data yet
