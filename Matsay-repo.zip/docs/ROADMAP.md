# Roadmap

## Where the prototype stands vs the proposed solution

The idea submission describes a larger target architecture. This table keeps the two honest side by side.

| Area | Proposed (PPT) | Prototype today |
|---|---|---|
| Frontend | Next.js, React, TypeScript, Tailwind | React, TypeScript, Vite, Tailwind |
| Map | Mapbox GL JS / Leaflet | Leaflet (OSM + OpenSeaMap) |
| Backend | FastAPI services | Express (Node) |
| Database | PostgreSQL + PostGIS | PostgreSQL (no PostGIS yet) |
| Cache | Redis | Postgres weather cache only |
| AIS | Real-time ingestion | AISStream WebSocket client, needs key |
| Weather / ocean | Weather & ocean APIs | Open-Meteo, live |
| Optimization | Quantum-inspired multi-objective engine | UI + simulated run |
| Prediction | Predictive ML for fuel / ETA / risk | Physics-based fuel model |
| AI assistant | LLM with tool calling | Gemini chat with a fleet summary in the prompt (no tool calling yet) |
| Human-in-the-loop | Commander approval | Done, with audit log |

## Next steps

### 1. Real quantum-inspired optimizer (highest priority)
- Encode route / speed choices as Q-bit angles
- Rotation-gate update toward the best solution found so far
- Use `calculateFuelPrediction` as the fuel and CO2 objective
- Keep a non-dominated set for the Pareto view
- Store runs in the existing `optimization_runs` table
- Compare against a plain genetic algorithm to show whether the quantum-inspired version actually helps

### 2. Real routing
- Build a sea-lane graph with waypoints and chokepoints
- Weather-weighted edges, restricted-zone and storm avoidance
- Replace hand-written waypoint lists

### 3. Authentication and roles
- Use Firebase Auth in the login screen
- Apply `requireAuth` to write endpoints
- Roles: commander, operator, viewer

### 4. Data layer
- PostGIS for geofencing and spatial queries
- Redis for live AIS and weather cache
- Move heavy computation to a separate service

### 5. Model quality
- Calibrate the fuel model with noon-report data
- Per-vessel coefficients and SFOC curves
- Compare predicted and actual fuel in the Analytics screen

### 6. Engineering
- Unit tests for `fuelModel.ts`
- API tests for the Express routes
- CI to run lint and tests on every push
- Consider a stricter production start script (the current `start` script runs `node server.ts` directly)
