# API reference

Base URL: `http://localhost:3000` in development. All responses are JSON.

| Method | Path | Description |
|---|---|---|
| GET | `/api/health` | Server status, database status (`CONNECTED`, `FALLBACK_ACTIVE`, `DISCONNECTED`), AIS and weather integration status |
| GET | `/api/vessels` | Fleet list from the database, or the demo fleet if no database is configured |
| GET | `/api/ports` | Port list |
| GET | `/api/weather/live?lat=&lng=` | Wind, waves, current, sea temperature, pressure for a point. Defaults to 6.25, 78.4 if params are missing |
| GET | `/api/ais` | AIS summary: availability, status message, vessel count, vessels |
| GET | `/api/ais/status` | AIS connection state only |
| GET | `/api/ais/vessels` | Live vessels received from AISStream.io |
| POST | `/api/ai` | Ask the Gemini assistant. Body: `{ "query": string, "fleetSummary"?: object }` |
| GET | `/api/alerts` | Alert list |
| POST | `/api/alerts/:id/ack` | Mark an alert as acknowledged |
| GET | `/api/communications` | Operational messages |
| POST | `/api/communications` | Store a message. Body: `channel`, `sender`, `recipient`, `subject`, `body`, `urgent`, `status` (all optional, defaults are filled in) |
| GET | `/api/audit-logs` | Commander decisions |
| POST | `/api/audit-logs` | Store a decision. Body: `commanderName`, `recommendationId`, `vesselName`, `action` (`APPROVED` / `MODIFIED` / `REJECTED`), `notes` |

## Examples

```bash
curl http://localhost:3000/api/health

curl "http://localhost:3000/api/weather/live?lat=12.5&lng=80.3"

curl -X POST http://localhost:3000/api/ai \
  -H "Content-Type: application/json" \
  -d '{"query":"Which vessel has the highest fuel burn today?"}'
```

If Gemini is not configured the last call returns:

```json
{ "available": false, "message": "AI assistant is temporarily unavailable" }
```

## Error behaviour

- Data endpoints return `503` with a short `error` message if the database call fails.
- `/api/ai` always returns `200`; check the `available` field.
- `/api/ai` returns `400` if `query` is missing or not a string.
- No endpoint requires authentication right now.
