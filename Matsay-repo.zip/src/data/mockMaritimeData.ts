import type { Vessel, Port, RestrictedZone, StormSystem, AlertItem, CommunicationMessage } from '../types/maritime.ts';

export const INITIAL_PORTS: Port[] = [
  {
    id: 'port-singapore',
    name: 'Port of Singapore',
    country: 'Singapore',
    coordinates: { lat: 1.290270, lng: 103.851959 },
    code: 'SGSIN',
    berthsAvailable: 14,
    averageWaitHours: 4.2,
    currentVesselsCount: 142
  },
  {
    id: 'port-colombo',
    name: 'Port of Colombo',
    country: 'Sri Lanka',
    coordinates: { lat: 6.9497, lng: 79.8428 },
    code: 'LKCMB',
    berthsAvailable: 5,
    averageWaitHours: 8.5,
    currentVesselsCount: 68
  },
  {
    id: 'port-mumbai-jnpt',
    name: 'Jawaharlal Nehru Port (JNPT)',
    country: 'India',
    coordinates: { lat: 18.9499, lng: 72.9515 },
    code: 'INNSA',
    berthsAvailable: 6,
    averageWaitHours: 6.1,
    currentVesselsCount: 54
  },
  {
    id: 'port-jebel-ali',
    name: 'Jebel Ali Port (Dubai)',
    country: 'United Arab Emirates',
    coordinates: { lat: 25.0113, lng: 55.0617 },
    code: 'AEJEA',
    berthsAvailable: 9,
    averageWaitHours: 3.8,
    currentVesselsCount: 88
  },
  {
    id: 'port-salalah',
    name: 'Port of Salalah',
    country: 'Oman',
    coordinates: { lat: 16.9419, lng: 54.0044 },
    code: 'OMSLL',
    berthsAvailable: 4,
    averageWaitHours: 5.0,
    currentVesselsCount: 39
  },
  {
    id: 'port-rotterdam',
    name: 'Port of Rotterdam',
    country: 'Netherlands',
    coordinates: { lat: 51.95, lng: 4.13 },
    code: 'NLRTM',
    berthsAvailable: 12,
    averageWaitHours: 5.6,
    currentVesselsCount: 190
  },
  {
    id: 'port-suez',
    name: 'Port of Port Said / Suez North',
    country: 'Egypt',
    coordinates: { lat: 31.2653, lng: 32.3019 },
    code: 'EGPSD',
    berthsAvailable: 3,
    averageWaitHours: 14.2,
    currentVesselsCount: 76
  }
];

export const RESTRICTED_ZONES: RestrictedZone[] = [
  {
    id: 'zone-hra-gulf-aden',
    name: 'Gulf of Aden High Risk Transit Corridor',
    type: 'Piracy High Risk Area',
    severity: 'Warning',
    notes: 'BMP5 maritime security procedures active; convoy escorts advised',
    coordinates: [
      { lat: 12.0, lng: 44.0 },
      { lat: 14.5, lng: 47.0 },
      { lat: 14.0, lng: 53.0 },
      { lat: 11.0, lng: 51.5 }
    ]
  },
  {
    id: 'zone-marine-sanctuary',
    name: 'Chagos-Lakshadweep Pelagic Conservation Sanctuary',
    type: 'Marine Protected Area',
    severity: 'Restricted',
    notes: 'Zero discharge; mandatory 5nm buffer zone for acoustic disturbance reduction',
    coordinates: [
      { lat: -5.0, lng: 70.0 },
      { lat: -5.0, lng: 73.5 },
      { lat: -7.5, lng: 73.5 },
      { lat: -7.5, lng: 70.0 }
    ]
  },
  {
    id: 'zone-malacca-tss',
    name: 'Strait of Malacca Traffic Separation Scheme (TSS)',
    type: 'ECA Emission Control',
    severity: 'Strict Speed Limit',
    notes: 'Max transit speed 14 kts; low sulphur 0.10% m/m compliant fuel required',
    coordinates: [
      { lat: 2.2, lng: 101.8 },
      { lat: 1.3, lng: 103.5 },
      { lat: 1.1, lng: 104.2 },
      { lat: 1.8, lng: 102.2 }
    ]
  }
];

export const ACTIVE_STORMS: StormSystem[] = [
  {
    id: 'storm-cyclone-shakti',
    name: 'Tropical Cyclone 03B (SHAKTI)',
    category: 'Cyclone Cat 2',
    coordinates: { lat: 11.8, lng: 86.4 },
    radiusNm: 180,
    maxWindKts: 68,
    movementSpeedKts: 11,
    headingDeg: 315
  },
  {
    id: 'storm-depression-arabian',
    name: 'Tropical Depression 02A',
    category: 'Tropical Depression',
    coordinates: { lat: 17.2, lng: 64.8 },
    radiusNm: 95,
    maxWindKts: 38,
    movementSpeedKts: 8,
    headingDeg: 280
  }
];

export const INITIAL_VESSELS: Vessel[] = [
  {
    id: 'vessel-01',
    name: 'MV OCEAN STAR',
    imo: '9876543',
    mmsi: '563124000',
    type: 'Container',
    status: 'IN TRANSIT',
    scheduleStatus: 'On Schedule',
    position: { lat: 6.25, lng: 78.40 },
    heading: 96,
    speedKts: 18.4,
    destination: 'Port of Singapore',
    origin: 'Jawaharlal Nehru Port (JNPT)',
    eta: 'Oct 04, 2026 14:30 UTC',
    etd: 'Sep 29, 2026 08:00 UTC',
    cargoDescription: 'Electronics & Industrial Machinery (14,200 TEU)',
    cargoUtilizationPct: 88.5,
    specs: {
      lengthM: 366.5,
      beamM: 51.2,
      draftM: 15.2,
      deadweightTons: 145000,
      capacityTeuOrM3: '14,800 TEU',
      fuelType: 'VLSFO',
      mainEngine: 'MAN B&W 11G95ME-C9.5 (54,900 kW)',
      operatingSpeedKts: 18.5,
      builtYear: 2021,
      flag: 'Singapore'
    },
    telemetry: {
      fuelRemainingMt: 1840,
      fuelConsumptionMtPerDay: 48.6,
      co2EmissionsTonsPerDay: 152.1,
      engineRpm: 72,
      engineLoadPct: 76,
      shaftPowerKw: 38500,
      waterDepthM: 3420,
      seaTemperatureC: 28.4,
      airTemperatureC: 29.8,
      windSpeedKts: 14.2,
      windDirectionDeg: 215,
      waveHeightM: 1.8,
      currentSpeedKts: 1.2,
      currentDirectionDeg: 85
    },
    plannedRoute: [
      { lat: 18.95, lng: 72.95, name: 'JNPT Mumbai' },
      { lat: 13.50, lng: 73.80 },
      { lat: 8.00, lng: 77.20 },
      { lat: 5.80, lng: 80.50, name: 'Dondra Head South' },
      { lat: 5.50, lng: 86.00 },
      { lat: 5.60, lng: 95.20, name: 'Acheh Strait Entry' },
      { lat: 3.10, lng: 100.50 },
      { lat: 1.29, lng: 103.85, name: 'Singapore Roads' }
    ],
    optimizedRoute: [
      { lat: 18.95, lng: 72.95, name: 'JNPT Mumbai' },
      { lat: 13.50, lng: 73.80 },
      { lat: 7.90, lng: 77.30 },
      { lat: 5.40, lng: 80.80, name: 'Optimized Equatorial Track' },
      { lat: 4.80, lng: 87.50 }, // rides favorable eastward equatorial countercurrent +1.4 kts
      { lat: 5.20, lng: 95.80 },
      { lat: 3.10, lng: 100.50 },
      { lat: 1.29, lng: 103.85, name: 'Singapore Roads' }
    ],
    recommendationPending: true
  },
  {
    id: 'vessel-02',
    name: 'MT PACIFIC VOYAGER',
    imo: '9784122',
    mmsi: '564889000',
    type: 'Tanker',
    status: 'IN TRANSIT',
    scheduleStatus: 'Warning',
    position: { lat: 15.60, lng: 63.80 },
    heading: 235,
    speedKts: 12.8,
    destination: 'Jebel Ali Port (Dubai)',
    origin: 'Port of Singapore',
    eta: 'Oct 06, 2026 19:00 UTC',
    etd: 'Sep 26, 2026 18:30 UTC',
    cargoDescription: 'Crude Oil (298,000 DWT)',
    cargoUtilizationPct: 96.0,
    specs: {
      lengthM: 333.0,
      beamM: 60.0,
      draftM: 21.5,
      deadweightTons: 318000,
      capacityTeuOrM3: '345,000 m³',
      fuelType: 'VLSFO',
      mainEngine: 'WinGD 7X82DF-1.0 (27,400 kW)',
      operatingSpeedKts: 14.0,
      builtYear: 2022,
      flag: 'Marshall Islands'
    },
    telemetry: {
      fuelRemainingMt: 2450,
      fuelConsumptionMtPerDay: 58.2,
      co2EmissionsTonsPerDay: 182.2,
      engineRpm: 66,
      engineLoadPct: 82,
      shaftPowerKw: 22800,
      waterDepthM: 3890,
      seaTemperatureC: 29.1,
      airTemperatureC: 31.4,
      windSpeedKts: 26.5, // strong headwind from Arabian depression
      windDirectionDeg: 45,
      waveHeightM: 3.6,
      currentSpeedKts: 0.8,
      currentDirectionDeg: 190
    },
    plannedRoute: [
      { lat: 1.29, lng: 103.85, name: 'Singapore' },
      { lat: 5.80, lng: 95.00 },
      { lat: 6.00, lng: 80.00 },
      { lat: 15.60, lng: 63.80 },
      { lat: 22.00, lng: 60.00, name: 'Gulf of Oman' },
      { lat: 25.01, lng: 55.06, name: 'Jebel Ali' }
    ],
    optimizedRoute: [
      { lat: 1.29, lng: 103.85, name: 'Singapore' },
      { lat: 5.80, lng: 95.00 },
      { lat: 6.00, lng: 80.00 },
      { lat: 13.80, lng: 62.10, name: 'South Diversion Track' }, // avoids Arabian Depression center
      { lat: 21.40, lng: 59.80 },
      { lat: 25.01, lng: 55.06, name: 'Jebel Ali' }
    ],
    recommendationPending: true
  },
  {
    id: 'vessel-03',
    name: 'MV HIMALAYAN PHOENIX',
    imo: '9651034',
    mmsi: '419001420',
    type: 'Bulk Carrier',
    status: 'IN TRANSIT',
    scheduleStatus: 'Critical',
    position: { lat: 11.20, lng: 84.10 },
    heading: 340,
    speedKts: 11.2,
    destination: 'Port of Colombo',
    origin: 'Port of Fremantle',
    eta: 'Oct 05, 2026 06:00 UTC',
    etd: 'Sep 24, 2026 12:00 UTC',
    cargoDescription: 'Iron Ore & Metallurgical Coal (178,000 MT)',
    cargoUtilizationPct: 94.0,
    specs: {
      lengthM: 292.0,
      beamM: 45.0,
      draftM: 18.2,
      deadweightTons: 182000,
      capacityTeuOrM3: '202,000 m³',
      fuelType: 'VLSFO',
      mainEngine: 'Hyundai-MAN B&W 6S70ME-C8.2',
      operatingSpeedKts: 13.5,
      builtYear: 2018,
      flag: 'Panama'
    },
    telemetry: {
      fuelRemainingMt: 1120,
      fuelConsumptionMtPerDay: 42.4,
      co2EmissionsTonsPerDay: 132.7,
      engineRpm: 68,
      engineLoadPct: 84,
      shaftPowerKw: 15400,
      waterDepthM: 3200,
      seaTemperatureC: 28.9,
      airTemperatureC: 29.5,
      windSpeedKts: 38.0, // direct outer band of Cyclone SHAKTI
      windDirectionDeg: 120,
      waveHeightM: 5.2,
      currentSpeedKts: 2.1,
      currentDirectionDeg: 310
    },
    plannedRoute: [
      { lat: -32.0, lng: 115.5 },
      { lat: -5.0, lng: 92.0 },
      { lat: 11.20, lng: 84.10 },
      { lat: 13.50, lng: 82.00 }, // original route crosses directly into Cyclone Shakti's path!
      { lat: 6.95, lng: 79.84, name: 'Colombo' }
    ],
    optimizedRoute: [
      { lat: 11.20, lng: 84.10 },
      { lat: 8.50, lng: 83.20, name: 'Emergency Cyclone Avoidance S-Turn' },
      { lat: 6.20, lng: 81.40 },
      { lat: 6.95, lng: 79.84, name: 'Colombo' }
    ],
    recommendationPending: true
  },
  {
    id: 'vessel-04',
    name: 'MV ARABIAN BREEZE',
    imo: '9920156',
    mmsi: '470213000',
    type: 'LNG',
    status: 'IN TRANSIT',
    scheduleStatus: 'On Schedule',
    position: { lat: 13.10, lng: 48.50 },
    heading: 84,
    speedKts: 19.5,
    destination: 'Jawaharlal Nehru Port (JNPT)',
    origin: 'Port of Ras Laffan',
    eta: 'Oct 03, 2026 21:00 UTC',
    etd: 'Sep 30, 2026 04:00 UTC',
    cargoDescription: 'Liquefied Natural Gas (174,000 m³)',
    cargoUtilizationPct: 91.2,
    specs: {
      lengthM: 299.0,
      beamM: 46.4,
      draftM: 12.0,
      deadweightTons: 95000,
      capacityTeuOrM3: '174,000 m³',
      fuelType: 'LNG',
      mainEngine: 'ME-GI Dual Fuel with Boil-off Re-liquefaction',
      operatingSpeedKts: 19.5,
      builtYear: 2023,
      flag: 'Bahamas'
    },
    telemetry: {
      fuelRemainingMt: 1650,
      fuelConsumptionMtPerDay: 36.8,
      co2EmissionsTonsPerDay: 99.4,
      engineRpm: 75,
      engineLoadPct: 70,
      shaftPowerKw: 24500,
      waterDepthM: 1850,
      seaTemperatureC: 27.5,
      airTemperatureC: 30.2,
      windSpeedKts: 12.0,
      windDirectionDeg: 195,
      waveHeightM: 1.4,
      currentSpeedKts: 0.6,
      currentDirectionDeg: 90
    },
    plannedRoute: [
      { lat: 12.5, lng: 44.5 },
      { lat: 13.10, lng: 48.50 },
      { lat: 14.50, lng: 56.00 },
      { lat: 17.20, lng: 66.00 },
      { lat: 18.95, lng: 72.95, name: 'JNPT' }
    ]
  },
  {
    id: 'vessel-05',
    name: 'MV INDUS GLORY',
    imo: '9542389',
    mmsi: '419000850',
    type: 'Cargo',
    status: 'IN TRANSIT',
    scheduleStatus: 'On Schedule',
    position: { lat: 3.80, lng: 97.40 },
    heading: 305,
    speedKts: 14.2,
    destination: 'Port of Colombo',
    origin: 'Port of Singapore',
    eta: 'Oct 04, 2026 09:15 UTC',
    etd: 'Oct 01, 2026 16:00 UTC',
    cargoDescription: 'Breakbulk & Steel Coils (28,500 MT)',
    cargoUtilizationPct: 76.5,
    specs: {
      lengthM: 185.0,
      beamM: 28.4,
      draftM: 10.2,
      deadweightTons: 38000,
      capacityTeuOrM3: '42,000 m³',
      fuelType: 'VLSFO',
      mainEngine: 'MAN B&W 6S46MC-C8',
      operatingSpeedKts: 14.5,
      builtYear: 2017,
      flag: 'India'
    },
    telemetry: {
      fuelRemainingMt: 680,
      fuelConsumptionMtPerDay: 22.4,
      co2EmissionsTonsPerDay: 70.1,
      engineRpm: 92,
      engineLoadPct: 68,
      shaftPowerKw: 7800,
      waterDepthM: 74,
      seaTemperatureC: 29.8,
      airTemperatureC: 30.5,
      windSpeedKts: 8.5,
      windDirectionDeg: 140,
      waveHeightM: 0.9,
      currentSpeedKts: 1.1,
      currentDirectionDeg: 300
    },
    plannedRoute: [
      { lat: 1.29, lng: 103.85 },
      { lat: 2.50, lng: 101.50 },
      { lat: 3.80, lng: 97.40 },
      { lat: 5.60, lng: 94.80 },
      { lat: 6.95, lng: 79.84, name: 'Colombo' }
    ]
  },
  {
    id: 'vessel-06',
    name: 'MV MONSOON SENTINEL',
    imo: '9841902',
    mmsi: '566992000',
    type: 'Container',
    status: 'AT ANCHOR',
    scheduleStatus: 'On Schedule',
    position: { lat: 1.24, lng: 103.95 },
    heading: 180,
    speedKts: 0.1,
    destination: 'Port of Singapore',
    origin: 'Port of Colombo',
    eta: 'Oct 01, 2026 12:00 UTC (Berthed)',
    etd: 'Oct 02, 2026 18:00 UTC',
    cargoDescription: 'Finished Consumer Goods (9,400 TEU)',
    cargoUtilizationPct: 92.4,
    specs: {
      lengthM: 300.0,
      beamM: 48.2,
      draftM: 14.5,
      deadweightTons: 118000,
      capacityTeuOrM3: '10,000 TEU',
      fuelType: 'Methanol',
      mainEngine: 'MAN B&W 8G95ME-C10.5-LGIM Dual Fuel',
      operatingSpeedKts: 18.0,
      builtYear: 2024,
      flag: 'Denmark'
    },
    telemetry: {
      fuelRemainingMt: 1240,
      fuelConsumptionMtPerDay: 4.2, // auxiliary boiler/hotel load
      co2EmissionsTonsPerDay: 5.8,
      engineRpm: 0,
      engineLoadPct: 8,
      shaftPowerKw: 850,
      waterDepthM: 32,
      seaTemperatureC: 29.5,
      airTemperatureC: 28.9,
      windSpeedKts: 6.0,
      windDirectionDeg: 120,
      waveHeightM: 0.4,
      currentSpeedKts: 0.4,
      currentDirectionDeg: 160
    },
    plannedRoute: [
      { lat: 6.95, lng: 79.84 },
      { lat: 1.24, lng: 103.95, name: 'Singapore Eastern Anchorage' }
    ]
  }
];

export const INITIAL_ALERTS: AlertItem[] = [
  {
    id: 'alert-01',
    category: 'Critical',
    title: 'Severe Cyclone Trajectory Intersection',
    description: 'MV HIMALAYAN PHOENIX (IMO 9651034) is on a collision course with outer gale-force core of Cyclone SHAKTI (68 kts winds, 5.2m swells). Immediate south diversion recommended.',
    vesselId: 'vessel-03',
    vesselName: 'MV HIMALAYAN PHOENIX',
    timestamp: '14 mins ago',
    acknowledged: false,
    actionRequired: 'Reroute via South Diversion Track S-14'
  },
  {
    id: 'alert-02',
    category: 'Warning',
    title: 'Fuel Burn Rate Deviation (+14.2%)',
    description: 'MT PACIFIC VOYAGER is experiencing elevated specific fuel oil consumption due to 26.5 kts sustained headwind and 3.6m seas in the central Arabian Sea.',
    vesselId: 'vessel-02',
    vesselName: 'MT PACIFIC VOYAGER',
    timestamp: '42 mins ago',
    acknowledged: false,
    actionRequired: 'Execute Quantum RPM Throttling from 66 to 61 RPM (-11.8 MT fuel)'
  },
  {
    id: 'alert-03',
    category: 'Information',
    title: 'Equatorial Countercurrent Opportunity',
    description: 'MV OCEAN STAR can harness +1.4 kts eastward equatorial current by shifting 0.8° South, reducing transit fuel consumption by 48.6 MT.',
    vesselId: 'vessel-01',
    vesselName: 'MV OCEAN STAR',
    timestamp: '1 hour ago',
    acknowledged: true,
    actionRequired: 'Accept Optimizer Recommendation'
  },
  {
    id: 'alert-04',
    category: 'Warning',
    title: 'Port Congestion Advisory: Colombo Berths',
    description: 'Container terminal average wait time increased to 8.5 hours. Recommended slow steaming for incoming vessels to absorb berth delay and save 28 MT VLSFO.',
    timestamp: '2 hours ago',
    acknowledged: false,
    actionRequired: 'Issue Fleet Slow-Steaming Advisory'
  }
];

export const INITIAL_COMMUNICATIONS: CommunicationMessage[] = [
  {
    id: 'msg-01',
    channel: 'Emergency',
    sender: 'MATSAY Fleet Command',
    recipient: 'MV HIMALAYAN PHOENIX (Master)',
    subject: 'URGENT: Weather Rerouting Order — Tropical Cyclone SHAKTI',
    body: 'Master, satellite altimetry and scatterometer data confirm Tropical Cyclone SHAKTI central pressure 972 hPa with 68 kts winds. You are instructed to alter course immediately to 160° towards Waypoint 08°30N 083°12E to maintain minimum 150 nm safety margin from cyclone core. Acknowledge immediately.',
    timestamp: '10 mins ago',
    status: 'DELIVERED',
    urgent: true
  },
  {
    id: 'msg-02',
    channel: 'Operations',
    sender: 'MATSAY Optimizer Service',
    recipient: 'MV OCEAN STAR (Chief Engineer / Master)',
    subject: 'Optimized Waypoint Transmission — Equatorial Track',
    body: 'Voyage optimization plan OP-2026-IO-492 has been generated with 8.6% expected bunker savings via eastward current piggybacking. New waypoint corridor uploaded to ECDIS interface.',
    timestamp: '45 mins ago',
    status: 'READ',
    urgent: false
  },
  {
    id: 'msg-03',
    channel: 'Fleet-wide',
    sender: 'Capt. James H. Mercer (Fleet Commander)',
    recipient: 'All Indian Ocean & Arabian Sea Vessels',
    subject: 'Monthly Decarbonization & CII Target Adherence Protocol',
    body: 'All vessels are reminded to report shaft power logs at 06:00 and 18:00 UTC. Ensure trim optimization is checked post-bunkering to sustain targeted CII Class B metrics.',
    timestamp: '3 hours ago',
    status: 'READ',
    urgent: false
  }
];
