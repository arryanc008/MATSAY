import React from 'react';
import {
  BarChart3,
  TrendingUp,
  Ship,
  Clock,
  Fuel,
  Compass,
  CheckCircle2,
  Calendar
} from 'lucide-react';
import { useMaritime } from '../context/MaritimeContext';

export const AnalyticsPage: React.FC = () => {
  const { vessels, setCurrentPath } = useMaritime();

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-[#063A6B] tracking-tight">
            Fleet Telemetry & Operational Analytics
          </h1>
          <p className="text-xs text-[#55738C] mt-0.5">
            Historical voyage fuel efficiency, port dwell duration, and schedule reliability metrics
          </p>
        </div>

        <button
          onClick={() => setCurrentPath('/command-center')}
          className="px-3 py-1.5 bg-white border border-[#B9DDF5] text-xs font-semibold text-[#063A6B] rounded-md hover:bg-[#EFF9FF] transition-colors"
        >
          Return to Command Center
        </button>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
        <div className="p-3 bg-white border border-[#B9DDF5] rounded-lg shadow-xs">
          <span className="text-[10px] uppercase font-bold text-[#55738C]">AVG SPEED OVER GROUND</span>
          <div className="text-xl font-extrabold font-mono text-[#063A6B] mt-0.5">15.8 kts</div>
          <div className="text-[10px] text-[#18A879] mt-1 font-semibold">Optimal SFOC envelope</div>
        </div>

        <div className="p-3 bg-white border border-[#B9DDF5] rounded-lg shadow-xs">
          <span className="text-[10px] uppercase font-bold text-[#55738C]">AVERAGE PORT WAIT TIME</span>
          <div className="text-xl font-extrabold font-mono text-[#063A6B] mt-0.5">5.4 hrs</div>
          <div className="text-[10px] text-[#55738C] mt-1">-1.8 hrs vs Q2 benchmark</div>
        </div>

        <div className="p-3 bg-white border border-[#B9DDF5] rounded-lg shadow-xs">
          <span className="text-[10px] uppercase font-bold text-[#55738C]">FLEET CII BENCHMARK</span>
          <div className="text-xl font-extrabold font-mono text-[#18A879] mt-0.5">4.82 g CO₂/t-nm</div>
          <div className="text-[10px] text-[#18A879] mt-1 font-semibold">Class B Compliant</div>
        </div>

        <div className="p-3 bg-white border border-[#B9DDF5] rounded-lg shadow-xs">
          <span className="text-[10px] uppercase font-bold text-[#55738C]">VOYAGE ADHERENCE RATE</span>
          <div className="text-xl font-extrabold font-mono text-[#0879D1] mt-0.5">96.4%</div>
          <div className="text-[10px] text-[#18A879] mt-1 font-semibold">+4.2% with Q-Opt</div>
        </div>
      </div>

      {/* Analytics Breakdown Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 text-xs">
        {/* Vessel Fuel Variance */}
        <div className="p-4 bg-white border border-[#B9DDF5] rounded-lg shadow-xs space-y-3">
          <span className="font-bold text-[#063A6B] block pb-2 border-b border-[#EFF9FF]">
            Vessel Daily Fuel Variance (Observed vs Predicted Baseline)
          </span>

          <div className="space-y-2">
            {vessels.slice(0, 5).map((v) => (
              <div key={v.id} className="space-y-1">
                <div className="flex justify-between font-bold text-[#063A6B]">
                  <span>{v.name} ({v.type})</span>
                  <span className="font-mono text-[#0879D1]">
                    {v.telemetry.fuelConsumptionMtPerDay} MT/day
                  </span>
                </div>
                <div className="w-full bg-[#EFF9FF] h-2 rounded-full overflow-hidden border border-[#B9DDF5]/40">
                  <div
                    className="bg-[#0879D1] h-full rounded-full"
                    style={{ width: `${Math.min(100, (v.telemetry.fuelConsumptionMtPerDay / 65) * 100)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Port Turnaround Times */}
        <div className="p-4 bg-white border border-[#B9DDF5] rounded-lg shadow-xs space-y-3">
          <span className="font-bold text-[#063A6B] block pb-2 border-b border-[#EFF9FF]">
            Major Indian Ocean Port Dwell & Queue Statistics
          </span>

          <div className="space-y-2.5">
            {[
              { port: 'Port of Singapore', wait: '4.2 hrs', berths: '14 berths active', status: 'Fluid' },
              { port: 'Port of Colombo', wait: '8.5 hrs', berths: '5 berths active', status: 'Congestion Warning' },
              { port: 'JNPT Mumbai', wait: '6.1 hrs', berths: '6 berths active', status: 'Moderate' },
              { port: 'Jebel Ali Port (Dubai)', wait: '3.8 hrs', berths: '9 berths active', status: 'Optimal' }
            ].map((p, idx) => (
              <div
                key={idx}
                className="p-2.5 rounded bg-[#EFF9FF]/50 border border-[#B9DDF5] flex items-center justify-between"
              >
                <div>
                  <div className="font-bold text-[#063A6B]">{p.port}</div>
                  <div className="text-[10px] text-[#55738C]">{p.berths}</div>
                </div>
                <div className="text-right">
                  <div className="font-mono font-bold text-[#063A6B]">{p.wait}</div>
                  <div className="text-[10px] text-[#0879D1] font-semibold">{p.status}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
