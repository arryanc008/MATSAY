import React, { useState } from 'react';
import {
  CloudSun,
  Wind,
  Waves,
  Compass,
  AlertTriangle,
  Clock,
  Layers,
  Ship,
  TrendingUp,
  ShieldAlert
} from 'lucide-react';
import { useMaritime } from '../context/MaritimeContext';
import { FleetGISMap } from '../components/map/FleetGISMap';

export const WeatherPage: React.FC = () => {
  const {
    weatherForecastStep,
    setWeatherForecastStep,
    storms,
    vessels,
    setCurrentPath,
    setMapFocusTarget
  } = useMaritime();

  const forecastSteps: Array<'Now' | '+6h' | '+12h' | '+24h' | '+48h'> = [
    'Now',
    '+6h',
    '+12h',
    '+24h',
    '+48h'
  ];

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-[#063A6B] tracking-tight">
            MetOcean & Maritime Environmental Intelligence
          </h1>
          <p className="text-xs text-[#55738C] mt-0.5">
            ECMWF high-resolution wave spectra, scatterometer wind vectors, and tropical storm trajectories
          </p>
        </div>

        {/* Time Step Controls */}
        <div className="flex items-center gap-1 bg-white border border-[#B9DDF5] p-1 rounded-md shadow-xs">
          <Clock className="w-3.5 h-3.5 text-[#55738C] ml-1.5 mr-1" />
          <span className="text-[10px] uppercase font-bold text-[#55738C] mr-1">Forecast:</span>
          {forecastSteps.map((step) => (
            <button
              key={step}
              onClick={() => setWeatherForecastStep(step)}
              className={`px-2.5 py-1 text-xs font-bold rounded transition-colors ${
                weatherForecastStep === step
                  ? 'bg-[#0879D1] text-white shadow-xs'
                  : 'text-[#063A6B] hover:bg-[#EFF9FF]'
              }`}
            >
              {step}
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid: GIS Map + Environmental Telemetry & Storm Warnings */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* Map with Weather Layers (7 cols) */}
        <div className="lg:col-span-7 space-y-3">
          <FleetGISMap heightClass="h-[540px]" />
          <div className="p-3 bg-white border border-[#B9DDF5] rounded-lg shadow-xs flex items-center justify-between text-xs">
            <span className="text-[#55738C]">
              Visualizing: Ocean Currents, Significant Wave Height, and Cyclone Proximity Radii
            </span>
            <span className="font-mono text-[#0879D1] font-bold">GRID: 0.1° ECMWF MARITIME</span>
          </div>
        </div>

        {/* Right Storm Systems & Impact On Fleet (5 cols) */}
        <div className="lg:col-span-5 space-y-3 text-xs">
          {/* Active Tropical Cyclones */}
          <div className="bg-white border border-[#B9DDF5] rounded-lg shadow-xs p-4 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-[#EFF9FF]">
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-[#E84A5A]" />
                <span className="font-bold text-[#063A6B]">Active Severe Meteorological Systems</span>
              </div>
              <span className="text-[10px] font-mono text-[#E84A5A] font-bold">
                {storms.length} Active Corridors
              </span>
            </div>

            <div className="space-y-2">
              {storms.length === 0 ? (
                <div className="p-4 bg-[#EFF9FF]/50 border border-[#B9DDF5] rounded-md text-center">
                  <div className="text-xs font-bold text-[#18A879] flex items-center justify-center gap-1.5">
                    <ShieldAlert className="w-4 h-4 text-[#18A879]" />
                    <span>NO ACTIVE TROPICAL CYCLONES IN SECTOR</span>
                  </div>
                  <p className="text-[11px] text-[#55738C] mt-1 leading-relaxed">
                    Verified via IMD / WMO oceanic bulletins and Open-Meteo marine diagnostics. Standard shipping corridors clear of cyclonic cores.
                  </p>
                </div>
              ) : (
                storms.map((st) => (
                  <div
                    key={st.id}
                    className="p-3 bg-[#EFF9FF]/60 border border-[#B9DDF5] rounded-md space-y-1.5"
                  >
                    <div className="flex items-center justify-between font-bold">
                      <span className="text-[#E84A5A] flex items-center gap-1.5">
                        <span>🌀</span>
                        <span>{st.name}</span>
                      </span>
                      <span className="text-[10px] text-[#063A6B] font-mono bg-white px-2 py-0.5 rounded border border-[#B9DDF5]">
                        {st.category}
                      </span>
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-[11px] font-mono pt-1">
                      <div>
                        <span className="text-[#55738C] text-[9px] block">MAX SUSTAINED WIND</span>
                        <span className="font-bold text-[#063A6B]">{st.maxWindKts} kts</span>
                      </div>
                      <div>
                        <span className="text-[#55738C] text-[9px] block">GALE RADIUS</span>
                        <span className="font-bold text-[#063A6B]">{st.radiusNm} nm</span>
                      </div>
                      <div>
                        <span className="text-[#55738C] text-[9px] block">TRAJECTORY</span>
                        <span className="font-bold text-[#063A6B]">{st.headingDeg}° @ {st.movementSpeedKts} kts</span>
                      </div>
                    </div>

                    <button
                      onClick={() =>
                        setMapFocusTarget({
                          lat: st.coordinates.lat,
                          lng: st.coordinates.lng,
                          zoom: 6
                        })
                      }
                      className="w-full mt-1 py-1 text-[11px] font-bold text-[#0879D1] bg-white border border-[#B9DDF5] rounded hover:bg-[#EFF9FF] transition-colors"
                    >
                      Focus Cyclone on GIS Map
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Fleet Weather Impact Summary */}
          <div className="bg-white border border-[#B9DDF5] rounded-lg shadow-xs p-4 space-y-3">
            <span className="font-bold text-[#063A6B] block pb-2 border-b border-[#EFF9FF]">
              Fleet Meteorological Risk Evaluation
            </span>

            <div className="space-y-2">
              <div className="p-2.5 rounded bg-white border border-[#E84A5A]/40 space-y-1">
                <div className="flex items-center justify-between font-bold text-[#063A6B]">
                  <span>MV HIMALAYAN PHOENIX</span>
                  <span className="text-[10px] text-[#E84A5A] font-bold">5.2m Swell Impact</span>
                </div>
                <p className="text-[11px] text-[#55738C] leading-relaxed">
                  Outer storm bands of Cyclone SHAKTI crossing intended track. Projected added power
                  requirement +48% if route unchanged.
                </p>
              </div>

              <div className="p-2.5 rounded bg-white border border-[#F3A712]/40 space-y-1">
                <div className="flex items-center justify-between font-bold text-[#063A6B]">
                  <span>MT PACIFIC VOYAGER</span>
                  <span className="text-[10px] text-[#F3A712] font-bold">26.5 kts Headwind</span>
                </div>
                <p className="text-[11px] text-[#55738C] leading-relaxed">
                  Adverse Arabian Sea wind causing +14.2% daily fuel burn over nominal calm water benchmark.
                </p>
              </div>

              <div className="p-2.5 rounded bg-white border border-[#18A879]/40 space-y-1">
                <div className="flex items-center justify-between font-bold text-[#063A6B]">
                  <span>MV OCEAN STAR</span>
                  <span className="text-[10px] text-[#18A879] font-bold">+1.4 kts Favorable Drift</span>
                </div>
                <p className="text-[11px] text-[#55738C] leading-relaxed">
                  Successfully locked into Equatorial Countercurrent stream; hull resistance reduced by
                  6.4%.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
