import React, { useState } from 'react';
import {
  Ship,
  Search,
  ArrowUpDown,
  Filter,
  ExternalLink,
  Navigation,
  Fuel,
  Compass,
  CheckCircle,
  AlertTriangle,
  X,
  Gauge,
  Calendar,
  Flag
} from 'lucide-react';
import { useMaritime } from '../context/MaritimeContext';
import { Vessel } from '../types/maritime';

export const VesselsPage: React.FC = () => {
  const { vessels, setActiveVesselId, setMapFocusTarget, setCurrentPath } = useMaritime();

  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [sortField, setSortField] = useState<keyof Vessel | 'fuelConsumption'>('name');
  const [sortAsc, setSortAsc] = useState(true);
  const [selectedVesselForProfile, setSelectedVesselForProfile] = useState<Vessel | null>(null);

  const filteredVessels = vessels
    .filter((v) => {
      if (typeFilter !== 'ALL' && v.type !== typeFilter) return false;
      if (statusFilter !== 'ALL' && v.status !== statusFilter) return false;
      if (search.trim()) {
        const q = search.toLowerCase();
        return (
          v.name.toLowerCase().includes(q) ||
          v.imo.includes(q) ||
          v.destination.toLowerCase().includes(q) ||
          v.origin.toLowerCase().includes(q)
        );
      }
      return true;
    })
    .sort((a, b) => {
      let valA: any = a[sortField as keyof Vessel];
      let valB: any = b[sortField as keyof Vessel];

      if (sortField === 'fuelConsumption') {
        valA = a.telemetry.fuelConsumptionMtPerDay;
        valB = b.telemetry.fuelConsumptionMtPerDay;
      }

      if (valA < valB) return sortAsc ? -1 : 1;
      if (valA > valB) return sortAsc ? 1 : -1;
      return 0;
    });

  const handleSort = (field: keyof Vessel | 'fuelConsumption') => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(true);
    }
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-[#063A6B] tracking-tight">
            Fleet Vessel Registry & Telemetry
          </h1>
          <p className="text-xs text-[#55738C] mt-0.5">
            Real-time AIS tracking, operational status, specifications, and propulsion telemetry
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setCurrentPath('/command-center')}
            className="px-3 py-1.5 bg-white border border-[#B9DDF5] text-xs font-semibold text-[#063A6B] rounded-md hover:bg-[#EFF9FF] transition-colors"
          >
            Command Center
          </button>
          <button
            onClick={() => setCurrentPath('/optimization')}
            className="px-3 py-1.5 bg-[#0879D1] text-white text-xs font-bold rounded-md hover:bg-[#062B52] transition-colors shadow-xs"
          >
            Run Multi-Objective Optimizer
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-3 bg-white border border-[#B9DDF5] rounded-lg shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 flex-1 min-w-[240px]">
          <div className="relative w-full max-w-sm">
            <Search className="w-3.5 h-3.5 text-[#55738C] absolute left-2.5 top-2.5" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by vessel name, IMO, port..."
              className="w-full pl-8 pr-3 py-1.5 border border-[#B9DDF5] rounded-md focus:outline-none focus:border-[#0879D1] text-[#063A6B] bg-[#EFF9FF]/40 text-xs"
            />
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] uppercase font-bold text-[#55738C]">Type:</span>
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="p-1.5 border border-[#B9DDF5] rounded bg-[#EFF9FF] text-[#063A6B] text-xs"
            >
              <option value="ALL">All Types</option>
              <option value="Container">Container</option>
              <option value="Tanker">Tanker</option>
              <option value="Bulk Carrier">Bulk Carrier</option>
              <option value="LNG">LNG</option>
              <option value="Cargo">General Cargo</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-[10px] uppercase font-bold text-[#55738C]">Status:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="p-1.5 border border-[#B9DDF5] rounded bg-[#EFF9FF] text-[#063A6B] text-xs"
            >
              <option value="ALL">All Statuses</option>
              <option value="IN TRANSIT">IN TRANSIT</option>
              <option value="AT ANCHOR">AT ANCHOR</option>
              <option value="MOORED">MOORED</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Table Container */}
      <div className="bg-white border border-[#B9DDF5] rounded-lg shadow-xs overflow-hidden">
        {/* Desktop & Tablet Table (md+) */}
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#EFF9FF] text-[#55738C] text-[10px] uppercase font-bold tracking-wider border-b border-[#B9DDF5]">
              <tr>
                <th
                  onClick={() => handleSort('name')}
                  className="py-3 px-3 cursor-pointer hover:text-[#0879D1]"
                >
                  <div className="flex items-center gap-1">
                    <span>Vessel Name</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-2">IMO</th>
                <th
                  onClick={() => handleSort('type')}
                  className="py-3 px-2 cursor-pointer hover:text-[#0879D1]"
                >
                  <div className="flex items-center gap-1">
                    <span>Type</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-2">Position (Lat, Lng)</th>
                <th className="py-3 px-2">Destination</th>
                <th className="py-3 px-2">ETA (UTC)</th>
                <th
                  onClick={() => handleSort('speedKts')}
                  className="py-3 px-2 cursor-pointer hover:text-[#0879D1]"
                >
                  <div className="flex items-center gap-1">
                    <span>Speed</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-2">Cargo Load</th>
                <th
                  onClick={() => handleSort('fuelConsumption')}
                  className="py-3 px-2 cursor-pointer hover:text-[#0879D1]"
                >
                  <div className="flex items-center gap-1">
                    <span>Burn (MT/d)</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-2">Schedule Status</th>
                <th className="py-3 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#EFF9FF]">
              {filteredVessels.map((v) => (
                <tr
                  key={v.id}
                  onClick={() => setSelectedVesselForProfile(v)}
                  className="hover:bg-[#EFF9FF]/70 cursor-pointer transition-colors"
                >
                  <td className="py-3 px-3 font-bold text-[#063A6B]">
                    <div className="flex items-center gap-2">
                      <Ship className="w-4 h-4 text-[#0879D1]" />
                      <span>{v.name}</span>
                    </div>
                  </td>
                  <td className="py-3 px-2 font-mono text-[#55738C]">{v.imo}</td>
                  <td className="py-3 px-2 text-[#55738C]">{v.type}</td>
                  <td className="py-3 px-2 font-mono text-[#063A6B]">
                    {v.position.lat.toFixed(2)}°, {v.position.lng.toFixed(2)}°
                  </td>
                  <td className="py-3 px-2 text-[#063A6B] font-medium">{v.destination}</td>
                  <td className="py-3 px-2 text-[#55738C] font-mono text-[11px]">{v.eta}</td>
                  <td className="py-3 px-2 font-mono font-bold text-[#063A6B]">{v.speedKts} kts</td>
                  <td className="py-3 px-2">
                    <span className="font-mono text-[#0879D1] font-bold">{v.cargoUtilizationPct}%</span>
                  </td>
                  <td className="py-3 px-2 font-mono font-bold text-[#063A6B]">
                    {v.telemetry.fuelConsumptionMtPerDay}
                  </td>
                  <td className="py-3 px-2">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                        v.scheduleStatus === 'Critical'
                          ? 'text-[#E84A5A] bg-[#E84A5A]/10 border border-[#E84A5A]/20'
                          : v.scheduleStatus === 'Warning'
                          ? 'text-[#F3A712] bg-[#F3A712]/10 border border-[#F3A712]/20'
                          : 'text-[#18A879] bg-[#18A879]/10 border border-[#18A879]/20'
                      }`}
                    >
                      {v.scheduleStatus}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setActiveVesselId(v.id);
                          setMapFocusTarget({ lat: v.position.lat, lng: v.position.lng, zoom: 8 });
                          setCurrentPath('/command-center');
                        }}
                        className="text-[11px] text-[#0879D1] hover:underline font-bold"
                      >
                        Chart
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedVesselForProfile(v);
                        }}
                        className="text-[11px] text-[#063A6B] hover:text-[#0879D1] font-semibold"
                      >
                        Specs
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Mobile Vessel Cards (md:hidden) */}
        <div className="md:hidden divide-y divide-[#EFF9FF] p-2 space-y-2">
          {filteredVessels.map((v) => (
            <div
              key={v.id}
              onClick={() => setSelectedVesselForProfile(v)}
              className="p-3 rounded-lg bg-white border border-[#B9DDF5] shadow-xs active:bg-[#EFF9FF] transition-colors"
            >
              <div className="flex items-start justify-between gap-2 mb-1.5">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-md bg-[#EFF9FF] border border-[#B9DDF5] flex items-center justify-center shrink-0">
                    <Ship className="w-4 h-4 text-[#0879D1]" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-[#063A6B] leading-tight">{v.name}</h3>
                    <span className="text-[10px] text-[#55738C] font-mono">
                      IMO {v.imo} {v.mmsi ? `· MMSI ${v.mmsi}` : ''}
                    </span>
                  </div>
                </div>
                <span
                  className={`text-[9px] font-bold px-1.5 py-0.5 rounded shrink-0 ${
                    v.scheduleStatus === 'Critical'
                      ? 'text-[#E84A5A] bg-[#E84A5A]/10 border border-[#E84A5A]/20'
                      : v.scheduleStatus === 'Warning'
                      ? 'text-[#F3A712] bg-[#F3A712]/10 border border-[#F3A712]/20'
                      : 'text-[#18A879] bg-[#18A879]/10 border border-[#18A879]/20'
                  }`}
                >
                  {v.scheduleStatus}
                </span>
              </div>

              {/* Route & Destination */}
              <div className="text-xs text-[#063A6B] font-medium mt-2 bg-[#EFF9FF]/70 p-2 rounded border border-[#B9DDF5]/40 flex items-center justify-between">
                <span className="truncate max-w-[130px]">{v.origin}</span>
                <span className="text-[#0879D1] font-bold px-1">→</span>
                <span className="truncate max-w-[130px] font-bold text-right">{v.destination}</span>
              </div>

              {/* Metrics grid */}
              <div className="grid grid-cols-3 gap-2 text-center text-xs mt-2 pt-1 border-t border-[#EFF9FF]">
                <div>
                  <span className="text-[9px] uppercase font-bold text-[#55738C] block">Speed</span>
                  <span className="font-mono font-bold text-[#063A6B]">{v.speedKts} kts</span>
                </div>
                <div>
                  <span className="text-[9px] uppercase font-bold text-[#55738C] block">Fuel Burn</span>
                  <span className="font-mono font-bold text-[#063A6B]">{v.telemetry.fuelConsumptionMtPerDay} MT/d</span>
                </div>
                <div>
                  <span className="text-[9px] uppercase font-bold text-[#55738C] block">Cargo</span>
                  <span className="font-mono font-bold text-[#0879D1]">{v.cargoUtilizationPct}%</span>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-2 mt-2.5 pt-2 border-t border-[#EFF9FF]">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setActiveVesselId(v.id);
                    setMapFocusTarget({ lat: v.position.lat, lng: v.position.lng, zoom: 8 });
                    setCurrentPath('/command-center');
                  }}
                  className="flex-1 py-1.5 text-xs font-semibold text-[#0879D1] bg-[#EFF9FF] rounded border border-[#B9DDF5] text-center"
                >
                  Locate on Chart
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedVesselForProfile(v);
                  }}
                  className="flex-1 py-1.5 text-xs font-semibold text-white bg-[#0879D1] rounded text-center shadow-xs"
                >
                  View Full Specs
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Comprehensive Vessel Profile Modal */}
      {selectedVesselForProfile && (
        <div className="fixed inset-0 z-50 bg-[#062B52]/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-[#B9DDF5] rounded-xl shadow-2xl max-w-2xl w-full overflow-hidden max-h-[90vh] flex flex-col">
            {/* Modal Header */}
            <div className="p-4 bg-gradient-to-r from-[#EFF9FF] to-white border-b border-[#B9DDF5] flex items-center justify-between">
              <div>
                <h3 className="text-base font-extrabold text-[#063A6B]">
                  {selectedVesselForProfile.name}
                </h3>
                <p className="text-xs text-[#55738C] font-mono">
                  IMO {selectedVesselForProfile.imo} · Flag: {selectedVesselForProfile.specs.flag} · Built: {selectedVesselForProfile.specs.builtYear}
                </p>
              </div>
              <button
                onClick={() => setSelectedVesselForProfile(null)}
                className="p-1 text-[#55738C] hover:text-[#063A6B] rounded"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto space-y-4 text-xs">
              {/* Engineering & Dimension Specifications */}
              <div className="space-y-2">
                <h4 className="text-[11px] uppercase font-bold text-[#55738C] tracking-wide">
                  Hull Dimensions & Naval Architecture
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  <div className="p-2.5 bg-[#EFF9FF] rounded border border-[#B9DDF5]/60">
                    <span className="text-[#55738C] text-[10px] block">LENGTH OVERALL (LOA)</span>
                    <span className="font-mono font-bold text-[#063A6B] text-xs">
                      {selectedVesselForProfile.specs.lengthM} meters
                    </span>
                  </div>
                  <div className="p-2.5 bg-[#EFF9FF] rounded border border-[#B9DDF5]/60">
                    <span className="text-[#55738C] text-[10px] block">BEAM (WIDTH)</span>
                    <span className="font-mono font-bold text-[#063A6B] text-xs">
                      {selectedVesselForProfile.specs.beamM} meters
                    </span>
                  </div>
                  <div className="p-2.5 bg-[#EFF9FF] rounded border border-[#B9DDF5]/60">
                    <span className="text-[#55738C] text-[10px] block">CURRENT DRAFT</span>
                    <span className="font-mono font-bold text-[#063A6B] text-xs">
                      {selectedVesselForProfile.specs.draftM} meters
                    </span>
                  </div>
                  <div className="p-2.5 bg-[#EFF9FF] rounded border border-[#B9DDF5]/60">
                    <span className="text-[#55738C] text-[10px] block">DEADWEIGHT (DWT)</span>
                    <span className="font-mono font-bold text-[#063A6B] text-xs">
                      {selectedVesselForProfile.specs.deadweightTons.toLocaleString()} MT
                    </span>
                  </div>
                </div>
              </div>

              {/* Machinery & Propulsion */}
              <div className="space-y-2 pt-2 border-t border-[#EFF9FF]">
                <h4 className="text-[11px] uppercase font-bold text-[#55738C] tracking-wide">
                  Main Propulsion & Fuel Systems
                </h4>
                <div className="p-3 bg-white border border-[#B9DDF5] rounded-md space-y-2">
                  <div className="flex justify-between">
                    <span className="text-[#55738C]">Main Engine:</span>
                    <span className="font-mono font-bold text-[#063A6B]">
                      {selectedVesselForProfile.specs.mainEngine}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#55738C]">Design Operating Speed:</span>
                    <span className="font-mono font-bold text-[#063A6B]">
                      {selectedVesselForProfile.specs.operatingSpeedKts} knots
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#55738C]">Bunker Fuel Type:</span>
                    <span className="font-mono font-bold text-[#0879D1]">
                      {selectedVesselForProfile.specs.fuelType} (Low Sulphur)
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#55738C]">Fuel Remaining Onboard:</span>
                    <span className="font-mono font-bold text-[#18A879]">
                      {selectedVesselForProfile.telemetry.fuelRemainingMt} MT
                    </span>
                  </div>
                </div>
              </div>

              {/* Operational Action Buttons */}
              <div className="flex items-center justify-end gap-2 pt-4 border-t border-[#EFF9FF]">
                <button
                  onClick={() => {
                    setActiveVesselId(selectedVesselForProfile.id);
                    setMapFocusTarget({
                      lat: selectedVesselForProfile.position.lat,
                      lng: selectedVesselForProfile.position.lng,
                      zoom: 8
                    });
                    setSelectedVesselForProfile(null);
                    setCurrentPath('/command-center');
                  }}
                  className="px-4 py-2 bg-[#0879D1] text-white font-bold rounded-md hover:bg-[#062B52] transition-colors shadow-xs"
                >
                  Locate on Command Map
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
