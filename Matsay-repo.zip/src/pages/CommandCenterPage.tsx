import React, { useState } from 'react';
import {
  Sparkles,
  Compass,
  ArrowRight,
  Ship,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Play,
  CheckCircle2,
  Eye
} from 'lucide-react';
import { useMaritime } from '../context/MaritimeContext';
import { KpiCardsRow } from '../components/command/KpiCardsRow';
import { FleetGISMap, MapStatusFilter } from '../components/map/FleetGISMap';
import { VesselDetailsPanel } from '../components/vessels/VesselDetailsPanel';
import { MatsayOpsPanel } from '../components/ops/MatsayOpsPanel';
import { HumanInTheLoopModal } from '../components/common/HumanInTheLoopModal';

export const CommandCenterPage: React.FC = () => {
  const {
    vessels,
    activeVesselId,
    setActiveVesselId,
    optimizationResult,
    isOptimizing,
    optimizationProgress,
    executeOptimization,
    setCurrentPath,
    setMapFocusTarget
  } = useMaritime();

  const [selectedRecommendation, setSelectedRecommendation] = useState<any | null>(null);
  const [mapStatusFilter, setMapStatusFilter] = useState<MapStatusFilter>('ALL');
  const [isActionRequiredExpanded, setIsActionRequiredExpanded] = useState<boolean>(true);

  const pendingRecs =
    optimizationResult?.recommendations.filter((r) => r.status === 'PENDING') || [];

  // Fleet Health counts computed from actual vessels state
  const criticalVessels = vessels.filter((v) => v.scheduleStatus === 'Critical');
  const warningVessels = vessels.filter((v) => v.scheduleStatus === 'Warning');
  const normalVessels = vessels.filter((v) => v.scheduleStatus === 'On Schedule');
  const offlineAisVessels = vessels.filter((v) => !v.liveAisAvailable);

  // Build prioritized Action Required operational exception items from real fleet state
  const actionRequiredItems: Array<{
    id: string;
    vessel: (typeof vessels)[number];
    severity: 'Critical' | 'Warning';
    issue: string;
    impact: string;
    dataTag: string;
    canOptimize: boolean;
  }> = [
    ...criticalVessels.map((v) => ({
      id: `act-crit-${v.id}`,
      vessel: v,
      severity: 'Critical' as const,
      issue:
        v.telemetry.waveHeightM >= 2.8
          ? 'Severe sea state & fuel efficiency degradation'
          : 'Fuel efficiency below target & schedule deviation',
      impact: `Potential saving: 8.6% (${(v.telemetry.fuelConsumptionMtPerDay * 0.086).toFixed(
        1
      )} MT/day)`,
      dataTag: 'CALCULATED' as const,
      canOptimize: true
    })),
    ...warningVessels.map((v) => ({
      id: `act-warn-${v.id}`,
      vessel: v,
      severity: 'Warning' as const,
      issue:
        v.telemetry.windSpeedKts >= 20
          ? 'Weather deterioration ahead along corridor'
          : 'Corridor congestion & bunker burn advisory',
      impact: `Wind ${v.telemetry.windSpeedKts} kn · Swell ${v.telemetry.waveHeightM}m`,
      dataTag: 'LIVE / PREDICTED',
      canOptimize: Boolean(v.recommendationPending)
    }))
  ];

  // Ensure at least 3 high-priority operational items are visible if fewer critical/warning exist
  if (actionRequiredItems.length < 3) {
    vessels
      .filter(
        (v) =>
          v.recommendationPending &&
          !actionRequiredItems.some((item) => item.vessel.id === v.id)
      )
      .slice(0, 3 - actionRequiredItems.length)
      .forEach((v) => {
        actionRequiredItems.push({
          id: `act-opt-${v.id}`,
          vessel: v,
          severity: 'Warning' as const,
          issue: 'Equatorial current optimization opportunity detected',
          impact: 'Potential saving: 8.4% bunker fuel',
          dataTag: 'OPTIMIZATION' as const,
          canOptimize: true
        });
      });
  }

  const handleSelectActionVessel = (vesselId: string, zoom = 8) => {
    const target = vessels.find((v) => v.id === vesselId);
    if (!target) return;
    setActiveVesselId(target.id);
    setMapFocusTarget({ lat: target.position.lat, lng: target.position.lng, zoom });
  };

  return (
    <div className="space-y-3.5">
      {/* Top Operational Command Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 bg-white border border-[#B9DDF5] rounded-lg px-3.5 py-2.5 shadow-xs">
        <div className="min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-lg sm:text-xl font-black text-[#063A6B] tracking-tight">
              MATSAY Fleet Command Center
            </h1>
            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-[#062B52] text-white">
              SITUATION → PROBLEM → RECOMMENDATION → ACTION
            </span>
          </div>
          <p className="text-[11px] text-[#55738C] mt-0.5 truncate">
            Real AIS Telemetry + Open-Meteo Marine Observation + Quantum-Inspired Route Optimization
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {pendingRecs.length > 0 && (
            <button
              type="button"
              onClick={() => setSelectedRecommendation(pendingRecs[0])}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-[#18A879] hover:bg-[#138560] text-white text-xs font-bold rounded-md transition-colors shadow-xs cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Review Directives ({pendingRecs.length})</span>
            </button>
          )}
          <button
            type="button"
            onClick={() => executeOptimization()}
            disabled={isOptimizing}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#0879D1] hover:bg-[#062B52] text-white text-xs font-bold rounded-md transition-colors shadow-xs disabled:opacity-60 cursor-pointer"
          >
            <Play className="w-3 h-3 fill-current" />
            <span>{isOptimizing ? 'Optimizing...' : 'Run Fleet Optimizer'}</span>
          </button>
          <button
            type="button"
            onClick={() => setCurrentPath('/optimization')}
            className="hidden sm:flex items-center gap-1 px-2.5 py-1.5 bg-[#F8FCFF] hover:bg-[#EFF9FF] text-[#063A6B] border border-[#B9DDF5] text-xs font-semibold rounded-md transition-colors cursor-pointer"
            title="Open Full Optimizer Studio"
          >
            <span>Optimizer Studio</span>
            <ArrowRight className="w-3.5 h-3.5 text-[#0879D1]" />
          </button>
        </div>
      </div>

      {/* Live Optimizer Progress Bar when triggered from Command Center */}
      {isOptimizing && optimizationProgress && (
        <div className="p-3 bg-white border border-[#0879D1] rounded-lg shadow-xs space-y-1.5">
          <div className="flex items-center justify-between text-xs font-bold text-[#063A6B]">
            <span>OPTIMIZATION ENGINE: {optimizationProgress.phase}</span>
            <span className="font-mono text-[#0879D1]">{optimizationProgress.progressPct}%</span>
          </div>
          <div className="w-full bg-[#EFF9FF] h-1.5 rounded-full overflow-hidden">
            <div
              className="bg-[#0879D1] h-full transition-all duration-300"
              style={{ width: `${optimizationProgress.progressPct}%` }}
            />
          </div>
          <p className="text-[11px] font-mono text-[#55738C]">{optimizationProgress.details}</p>
        </div>
      )}

      {/* Human-In-The-Loop Decision Modal */}
      {selectedRecommendation && (
        <div className="my-2">
          <HumanInTheLoopModal
            recommendation={selectedRecommendation}
            onClose={() => setSelectedRecommendation(null)}
          />
        </div>
      )}

      {/* 6 High-Value KPI Cards Row */}
      <KpiCardsRow
        onSelectRiskFilter={() =>
          setMapStatusFilter(mapStatusFilter === 'Risk' ? 'ALL' : 'Risk')
        }
      />

      {/* ACTION REQUIRED Section (Operational Exception Prioritization) */}
      <div className="bg-white border border-[#B9DDF5] rounded-lg shadow-xs overflow-hidden">
        <div
          onClick={() => setIsActionRequiredExpanded(!isActionRequiredExpanded)}
          className="px-3.5 py-2 bg-gradient-to-r from-[#FFF8F9] via-[#F8FCFF] to-white border-b border-[#EFF9FF] flex items-center justify-between cursor-pointer select-none"
        >
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-[#E84A5A]" />
            <span className="text-xs font-extrabold tracking-wider text-[#063A6B]">
              ACTION REQUIRED
            </span>
            <span className="bg-[#E84A5A] text-white text-[10px] font-mono font-bold px-1.5 py-0.2 rounded-full">
              {actionRequiredItems.length}
            </span>
            <span className="hidden sm:inline text-[11px] text-[#55738C]">
              — Operational exceptions requiring commander attention
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono text-[#55738C] hidden md:inline">
              Click any exception to locate & inspect
            </span>
            {isActionRequiredExpanded ? (
              <ChevronUp className="w-4 h-4 text-[#55738C]" />
            ) : (
              <ChevronDown className="w-4 h-4 text-[#55738C]" />
            )}
          </div>
        </div>

        {isActionRequiredExpanded && (
          <div className="p-2.5 grid grid-cols-1 md:grid-cols-3 gap-2.5">
            {actionRequiredItems.slice(0, 3).map((item) => {
              const isSelected = item.vessel.id === activeVesselId;
              const isCritical = item.severity === 'Critical';
              const matchingRec = optimizationResult?.recommendations.find(
                (r) => r.vesselId === item.vessel.id || r.vesselName === item.vessel.name
              );

              return (
                <div
                  key={item.id}
                  onClick={() => handleSelectActionVessel(item.vessel.id, 8)}
                  className={`p-2.5 rounded-md border transition-all cursor-pointer flex flex-col justify-between ${
                    isSelected
                      ? 'bg-[#EFF9FF] border-[#0879D1] shadow-xs'
                      : isCritical
                      ? 'bg-[#FFF9FA] border-[#E84A5A]/30 hover:border-[#E84A5A]'
                      : 'bg-[#FFFDF7] border-[#F3A712]/30 hover:border-[#F3A712]'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <span className="text-xs leading-none">
                          {isCritical ? '🔴' : '🟡'}
                        </span>
                        <span className="font-extrabold text-xs text-[#063A6B] truncate">
                          {item.vessel.name}
                        </span>
                        <span className="text-[10px] font-mono text-[#55738C] shrink-0">
                          IMO {item.vessel.imo}
                        </span>
                      </div>
                      <span className="text-[8px] font-mono font-bold px-1.5 py-0.2 rounded bg-white border border-[#B9DDF5] text-[#063A6B] shrink-0">
                        {item.dataTag}
                      </span>
                    </div>

                    <div className="text-xs font-semibold text-[#063A6B] leading-snug">
                      {item.issue}
                    </div>
                    <div
                      className={`text-[11px] font-mono font-bold mt-0.5 ${
                        isCritical ? 'text-[#E84A5A]' : 'text-[#B87700]'
                      }`}
                    >
                      {item.impact}
                    </div>
                  </div>

                  {/* Action Buttons: [VIEW] [LOCATE] [OPTIMIZE] */}
                  <div className="flex items-center gap-1.5 mt-2.5 pt-2 border-t border-[#B9DDF5]/40">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveVesselId(item.vessel.id);
                      }}
                      className="px-2 py-1 rounded text-[10px] font-bold bg-white border border-[#B9DDF5] text-[#063A6B] hover:bg-[#EFF9FF] flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      <Eye className="w-3 h-3 text-[#0879D1]" />
                      <span>VIEW</span>
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleSelectActionVessel(item.vessel.id, 8);
                      }}
                      className="px-2 py-1 rounded text-[10px] font-bold bg-white border border-[#B9DDF5] text-[#063A6B] hover:bg-[#EFF9FF] flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      <Compass className="w-3 h-3 text-[#0879D1]" />
                      <span>LOCATE</span>
                    </button>
                    {item.canOptimize && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setActiveVesselId(item.vessel.id);
                          if (matchingRec) {
                            setSelectedRecommendation(matchingRec);
                          } else {
                            setCurrentPath('/optimization');
                          }
                        }}
                        className="ml-auto px-2.5 py-1 rounded text-[10px] font-bold bg-[#0879D1] text-white hover:bg-[#062B52] flex items-center gap-1 transition-colors cursor-pointer"
                      >
                        <Sparkles className="w-3 h-3" />
                        <span>OPTIMIZE</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Central Map-First Workspace: Interactive Fleet Health + Main GIS Map + Right Vessel Detail Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3.5 items-start">
        {/* Main Interactive GIS Map Column (8 cols on desktop) */}
        <div className="lg:col-span-8 flex flex-col space-y-2">
          {/* Interactive FLEET HEALTH Bar */}
          <div className="bg-white border border-[#B9DDF5] rounded-lg px-3 py-2 shadow-xs flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-extrabold tracking-wider text-[#063A6B]">
                FLEET HEALTH
              </span>
              <span className="text-[10px] text-[#55738C] hidden sm:inline">
                (Click status to filter map)
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-1.5">
              <button
                type="button"
                onClick={() => setMapStatusFilter('ALL')}
                className={`px-2 py-1 rounded text-xs font-bold transition-colors cursor-pointer ${
                  mapStatusFilter === 'ALL'
                    ? 'bg-[#062B52] text-white'
                    : 'bg-[#F8FCFF] text-[#063A6B] border border-[#B9DDF5] hover:bg-[#EFF9FF]'
                }`}
              >
                All ({vessels.length})
              </button>

              <button
                type="button"
                onClick={() =>
                  setMapStatusFilter(mapStatusFilter === 'Normal' ? 'ALL' : 'Normal')
                }
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-bold border transition-colors cursor-pointer ${
                  mapStatusFilter === 'Normal'
                    ? 'bg-[#18A879] text-white border-[#18A879]'
                    : 'bg-white text-[#063A6B] border-[#B9DDF5] hover:bg-[#F2FBF7]'
                }`}
              >
                <span className="w-2 h-2 rounded-full bg-[#18A879] ring-1 ring-white" />
                <span className="font-mono">{normalVessels.length}</span>
                <span>Normal</span>
              </button>

              <button
                type="button"
                onClick={() =>
                  setMapStatusFilter(mapStatusFilter === 'Warning' ? 'ALL' : 'Warning')
                }
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-bold border transition-colors cursor-pointer ${
                  mapStatusFilter === 'Warning'
                    ? 'bg-[#F3A712] text-white border-[#F3A712]'
                    : 'bg-white text-[#063A6B] border-[#B9DDF5] hover:bg-[#FFFBF0]'
                }`}
              >
                <span className="w-2 h-2 rounded-full bg-[#F3A712] ring-1 ring-white" />
                <span className="font-mono">{warningVessels.length}</span>
                <span>Warning</span>
              </button>

              <button
                type="button"
                onClick={() =>
                  setMapStatusFilter(mapStatusFilter === 'Critical' ? 'ALL' : 'Critical')
                }
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-bold border transition-colors cursor-pointer ${
                  mapStatusFilter === 'Critical'
                    ? 'bg-[#E84A5A] text-white border-[#E84A5A]'
                    : 'bg-white text-[#063A6B] border-[#B9DDF5] hover:bg-[#FFF5F6]'
                }`}
              >
                <span className="w-2 h-2 rounded-full bg-[#E84A5A] ring-1 ring-white" />
                <span className="font-mono">{criticalVessels.length}</span>
                <span>Critical</span>
              </button>

              <button
                type="button"
                onClick={() =>
                  setMapStatusFilter(mapStatusFilter === 'Offline' ? 'ALL' : 'Offline')
                }
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-bold border transition-colors cursor-pointer ${
                  mapStatusFilter === 'Offline'
                    ? 'bg-[#55738C] text-white border-[#55738C]'
                    : 'bg-white text-[#55738C] border-[#B9DDF5] hover:bg-[#F8FCFF]'
                }`}
                title="Vessels awaiting live AIS transponder packet (using verified baseline)"
              >
                <span className="w-2 h-2 rounded-full bg-[#94A3B8]" />
                <span className="font-mono">{offlineAisVessels.length}</span>
                <span>Registry Baseline</span>
              </button>
            </div>
          </div>

          {/* Main Interactive GIS Map */}
          <div className="relative">
            <FleetGISMap
              heightClass="h-[380px] sm:h-[480px] lg:h-[580px]"
              statusFilter={mapStatusFilter}
              onStatusFilterChange={setMapStatusFilter}
            />
          </div>
        </div>

        {/* Right Vessel Detail Panel (4 cols on desktop) */}
        <div className="lg:col-span-4 flex flex-col space-y-3">
          <VesselDetailsPanel />
        </div>
      </div>

      {/* Bottom Section: Active Voyages Fleet Table & MATSAY OPS Console */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3.5 items-start pt-1">
        {/* Left: Active Voyages Fleet Table (7 cols) */}
        <div className="lg:col-span-7 bg-white border border-[#B9DDF5] rounded-lg shadow-xs p-3.5 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#EFF9FF]">
            <div className="flex items-center gap-2">
              <Ship className="w-4 h-4 text-[#0879D1]" />
              <span className="text-xs font-bold text-[#063A6B]">
                Active Fleet Deployment & Telemetry
              </span>
              <span className="text-[9px] font-mono font-bold px-1.5 py-0.2 rounded bg-[#18A879]/15 text-[#18A879]">
                LIVE + CALCULATED
              </span>
            </div>
            <button
              type="button"
              onClick={() => setCurrentPath('/vessels')}
              className="text-[11px] text-[#0879D1] hover:underline font-semibold flex items-center gap-1 cursor-pointer"
            >
              <span>View All {vessels.length} Vessels</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          {/* Desktop & Tablet Table (md+) */}
          <div className="hidden md:block overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#F8FCFF] text-[#55738C] text-[10px] uppercase font-bold tracking-wider border-b border-[#EFF9FF]">
                <tr>
                  <th className="py-2 px-2.5">Vessel</th>
                  <th className="py-2 px-2">Corridor</th>
                  <th className="py-2 px-2">Speed</th>
                  <th className="py-2 px-2">Fuel (MT/d)</th>
                  <th className="py-2 px-2">Risk Status</th>
                  <th className="py-2 px-2 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#EFF9FF]">
                {vessels.slice(0, 6).map((v) => {
                  const isSelected = v.id === activeVesselId;
                  return (
                    <tr
                      key={v.id}
                      onClick={() => setActiveVesselId(v.id)}
                      className={`hover:bg-[#EFF9FF]/70 cursor-pointer transition-colors ${
                        isSelected ? 'bg-[#EFF9FF] font-semibold' : ''
                      }`}
                    >
                      <td className="py-2.5 px-2.5 font-bold text-[#063A6B]">
                        <div className="flex items-center gap-2">
                          <span
                            className={`w-2 h-2 rounded-full shrink-0 ${
                              v.scheduleStatus === 'Critical'
                                ? 'bg-[#E84A5A]'
                                : v.scheduleStatus === 'Warning'
                                ? 'bg-[#F3A712]'
                                : 'bg-[#18A879]'
                            }`}
                          />
                          <div>
                            <div>{v.name}</div>
                            <div className="text-[10px] font-mono font-normal text-[#55738C]">
                              IMO {v.imo}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="py-2.5 px-2 text-[#063A6B]">
                        <div className="font-medium truncate max-w-[160px]">
                          {v.origin} → {v.destination}
                        </div>
                        <div className="text-[10px] font-mono text-[#55738C]">ETA: {v.eta}</div>
                      </td>
                      <td className="py-2.5 px-2 font-mono text-[#063A6B] tabular-nums">
                        {v.speedKts} kn
                      </td>
                      <td className="py-2.5 px-2 font-mono text-[#063A6B] tabular-nums">
                        {v.telemetry.fuelConsumptionMtPerDay}
                      </td>
                      <td className="py-2.5 px-2">
                        <span
                          className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                            v.scheduleStatus === 'Critical'
                              ? 'text-[#E84A5A] bg-[#E84A5A]/10'
                              : v.scheduleStatus === 'Warning'
                              ? 'text-[#B87700] bg-[#F3A712]/15'
                              : 'text-[#18A879] bg-[#18A879]/10'
                          }`}
                        >
                          {v.scheduleStatus}
                        </span>
                      </td>
                      <td className="py-2.5 px-2 text-right">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleSelectActionVessel(v.id, 8);
                          }}
                          className="text-[10px] text-[#0879D1] hover:underline font-bold cursor-pointer"
                        >
                          Locate
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Mobile Vessel Cards (< md) */}
          <div className="md:hidden space-y-2">
            {vessels.slice(0, 4).map((v) => {
              const isSelected = v.id === activeVesselId;
              return (
                <div
                  key={v.id}
                  onClick={() => handleSelectActionVessel(v.id, 8)}
                  className={`p-2.5 rounded-lg border text-xs transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#EFF9FF] border-[#0879D1]'
                      : 'bg-[#F8FCFF] border-[#B9DDF5]/80 hover:bg-[#EFF9FF]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-1.5 font-bold text-[#063A6B]">
                      <span
                        className={`w-2 h-2 rounded-full ${
                          v.scheduleStatus === 'Critical'
                            ? 'bg-[#E84A5A]'
                            : v.scheduleStatus === 'Warning'
                            ? 'bg-[#F3A712]'
                            : 'bg-[#18A879]'
                        }`}
                      />
                      <span>{v.name}</span>
                    </div>
                    <span
                      className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                        v.scheduleStatus === 'Critical'
                          ? 'text-[#E84A5A] bg-[#E84A5A]/10'
                          : v.scheduleStatus === 'Warning'
                          ? 'text-[#B87700] bg-[#F3A712]/15'
                          : 'text-[#18A879] bg-[#18A879]/10'
                      }`}
                    >
                      {v.scheduleStatus}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-[#55738C] mt-1">
                    <span className="truncate pr-2">
                      {v.origin} → {v.destination}
                    </span>
                    <span className="font-mono text-[#063A6B] font-semibold shrink-0">
                      {v.speedKts} kn · {v.telemetry.fuelConsumptionMtPerDay} MT/d
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Operational MATSAY OPS Console (5 cols) */}
        <div className="lg:col-span-5">
          <MatsayOpsPanel />
        </div>
      </div>

      {/* SIH Technology Prototype Data Provenance & Intelligence Architecture Bar */}
      <div className="bg-white border border-[#B9DDF5] rounded-lg p-3 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#0879D1] shrink-0" />
            <span className="font-bold text-[#063A6B]">
              MATSAY Data Provenance & Intelligence Pipeline:
            </span>
          </div>
          <div className="flex flex-wrap items-center gap-2 text-[10px] font-mono">
            <span className="px-2 py-0.5 rounded bg-[#18A879]/12 text-[#18A879] font-bold">
              LIVE: AISStream.io + Open-Meteo API
            </span>
            <span className="text-[#55738C]">→</span>
            <span className="px-2 py-0.5 rounded bg-[#0879D1]/12 text-[#0879D1] font-bold">
              CALCULATED: Admiralty SFOC & ETA Models
            </span>
            <span className="text-[#55738C]">→</span>
            <span className="px-2 py-0.5 rounded bg-[#7C3AED]/12 text-[#7C3AED] font-bold">
              OPTIMIZATION: Multi-Objective Pareto Routing
            </span>
            <span className="text-[#55738C]">→</span>
            <span className="px-2 py-0.5 rounded bg-[#55738C]/12 text-[#063A6B] font-bold">
              HISTORICAL: PostgreSQL Audit & Bunker Logs
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
