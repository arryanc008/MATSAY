import React, { useState } from 'react';
import {
  Sliders,
  Play,
  RotateCcw,
  Sparkles,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  Ship,
  DollarSign,
  Fuel,
  Leaf
} from 'lucide-react';
import { useMaritime } from '../context/MaritimeContext';

export const ScenariosPage: React.FC = () => {
  const { vessels, setCurrentPath } = useMaritime();

  const [fuelPriceDeltaPct, setFuelPriceDeltaPct] = useState<number>(20);
  const [cargoDemandDeltaPct, setCargoDemandDeltaPct] = useState<number>(0);
  const [speedRestrictionKts, setSpeedRestrictionKts] = useState<number>(14);
  const [activePreset, setActivePreset] = useState<string>('fuel_spike');

  const baseFuelMt = 642.4;
  const baseCostUsd = baseFuelMt * 645;
  const baseCo2Tons = baseFuelMt * 3.114;

  // Compute dynamic impact based on scenario sliders
  const adjustedFuelPrice = 645 * (1 + fuelPriceDeltaPct / 100);
  const scenarioFuelMt = Number((baseFuelMt * (1 + (cargoDemandDeltaPct * 0.4) / 100)).toFixed(1));
  const scenarioCostUsd = Math.round(scenarioFuelMt * adjustedFuelPrice);
  const scenarioCo2Tons = Number((scenarioFuelMt * 3.114).toFixed(1));

  const costDeltaPct = (((scenarioCostUsd - baseCostUsd) / baseCostUsd) * 100).toFixed(1);
  const fuelDeltaPct = (((scenarioFuelMt - baseFuelMt) / baseFuelMt) * 100).toFixed(1);

  const presets = [
    {
      id: 'fuel_spike',
      label: 'Bunker Price Spike (+20%)',
      desc: 'Simulates crude volatility with $774/MT VLSFO; triggers aggressive slow-steaming recommendation.',
      fuelDelta: 20,
      cargoDelta: 0
    },
    {
      id: 'cyclone_evacuation',
      label: 'Severe Cyclone Reroute',
      desc: 'Category 2 cyclone crossing Bay of Bengal; forces southern detour (+42 nm, -3.2m swells).',
      fuelDelta: 0,
      cargoDelta: 0
    },
    {
      id: 'cargo_surge',
      label: 'Peak Season Cargo Demand (+30%)',
      desc: 'All container slots at 100% capacity; evaluates chartering 2 supplemental feeder vessels.',
      fuelDelta: 0,
      cargoDelta: 30
    },
    {
      id: 'imo_strict_cap',
      label: 'Strict Carbon Cap (-15% CO₂)',
      desc: 'Enforces mandatory fleet-wide emission reduction; optimizes vessel speed plateau down to 14.5 kts.',
      fuelDelta: -5,
      cargoDelta: 0
    }
  ];

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-[#063A6B] tracking-tight">
            Admiralty What-If Scenario Simulator
          </h1>
          <p className="text-xs text-[#55738C] mt-0.5">
            Stress-test fleet resilience against fuel shocks, weather detours, strict carbon caps, and port congestion
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setCurrentPath('/optimization')}
            className="px-3 py-1.5 bg-[#0879D1] text-white text-xs font-bold rounded-md hover:bg-[#062B52] transition-colors shadow-xs"
          >
            Deploy Scenario to Optimizer
          </button>
        </div>
      </div>

      {/* Preset Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {presets.map((p) => (
          <button
            key={p.id}
            onClick={() => {
              setActivePreset(p.id);
              setFuelPriceDeltaPct(p.fuelDelta);
              setCargoDemandDeltaPct(p.cargoDelta);
            }}
            className={`p-3 rounded-lg border text-left text-xs transition-all ${
              activePreset === p.id
                ? 'bg-[#EFF9FF] border-[#0879D1] shadow-xs'
                : 'bg-white border-[#B9DDF5] hover:bg-[#F4FBFF]'
            }`}
          >
            <div className="font-extrabold text-[#063A6B]">{p.label}</div>
            <p className="text-[11px] text-[#55738C] mt-1 leading-relaxed">{p.desc}</p>
          </button>
        ))}
      </div>

      {/* Scenario Parameters & Delta Comparison */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* Sliders (5 cols) */}
        <div className="lg:col-span-5 bg-white border border-[#B9DDF5] rounded-lg shadow-xs p-4 space-y-4 text-xs">
          <div className="flex items-center justify-between pb-2 border-b border-[#EFF9FF]">
            <span className="font-bold text-[#063A6B]">Simulation Parameter Controls</span>
            <button
              onClick={() => {
                setFuelPriceDeltaPct(0);
                setCargoDemandDeltaPct(0);
              }}
              className="text-[11px] text-[#0879D1] font-bold hover:underline"
            >
              Reset Baseline
            </button>
          </div>

          <div>
            <div className="flex justify-between mb-1">
              <span className="font-bold text-[#063A6B]">Bunker Fuel Price Fluctuation</span>
              <span className="font-mono text-[#0879D1] font-bold">
                {fuelPriceDeltaPct > 0 ? `+${fuelPriceDeltaPct}%` : `${fuelPriceDeltaPct}%`} (${adjustedFuelPrice.toFixed(0)}/MT)
              </span>
            </div>
            <input
              type="range"
              min="-20"
              max="50"
              value={fuelPriceDeltaPct}
              onChange={(e) => setFuelPriceDeltaPct(Number(e.target.value))}
              className="w-full accent-[#0879D1]"
            />
          </div>

          <div>
            <div className="flex justify-between mb-1">
              <span className="font-bold text-[#063A6B]">Cargo Freight Demand Delta</span>
              <span className="font-mono text-[#0879D1] font-bold">
                {cargoDemandDeltaPct > 0 ? `+${cargoDemandDeltaPct}%` : `${cargoDemandDeltaPct}%`}
              </span>
            </div>
            <input
              type="range"
              min="-30"
              max="50"
              value={cargoDemandDeltaPct}
              onChange={(e) => setCargoDemandDeltaPct(Number(e.target.value))}
              className="w-full accent-[#0879D1]"
            />
          </div>
        </div>

        {/* Impact Results (7 cols) */}
        <div className="lg:col-span-7 bg-white border border-[#B9DDF5] rounded-lg shadow-xs p-4 space-y-3 text-xs">
          <span className="font-bold text-[#063A6B] block pb-2 border-b border-[#EFF9FF]">
            Projected Scenario Impact vs Operating Baseline
          </span>

          <div className="grid grid-cols-3 gap-3">
            <div className="p-3 bg-[#EFF9FF] rounded-md border border-[#B9DDF5]">
              <span className="text-[10px] uppercase font-bold text-[#55738C]">DAILY EXPENSE</span>
              <div className="text-base font-extrabold font-mono text-[#063A6B] mt-1">
                ${(scenarioCostUsd / 1000).toFixed(1)}k
              </div>
              <div
                className={`text-[10px] font-bold mt-1 ${
                  Number(costDeltaPct) > 0 ? 'text-[#E84A5A]' : 'text-[#18A879]'
                }`}
              >
                {Number(costDeltaPct) > 0 ? `+${costDeltaPct}%` : `${costDeltaPct}%`} delta
              </div>
            </div>

            <div className="p-3 bg-[#EFF9FF] rounded-md border border-[#B9DDF5]">
              <span className="text-[10px] uppercase font-bold text-[#55738C]">BUNKER CONSUMPTION</span>
              <div className="text-base font-extrabold font-mono text-[#063A6B] mt-1">
                {scenarioFuelMt} MT
              </div>
              <div className="text-[10px] text-[#55738C] mt-1 font-mono">
                {fuelDeltaPct}% volume
              </div>
            </div>

            <div className="p-3 bg-[#EFF9FF] rounded-md border border-[#B9DDF5]">
              <span className="text-[10px] uppercase font-bold text-[#55738C]">TOTAL CO₂ EMISSIONS</span>
              <div className="text-base font-extrabold font-mono text-[#063A6B] mt-1">
                {scenarioCo2Tons} t
              </div>
              <div className="text-[10px] text-[#55738C] mt-1">
                From {vessels.length} vessels
              </div>
            </div>
          </div>

          <div className="p-3 bg-white border border-[#B9DDF5] rounded-md space-y-1">
            <span className="font-bold text-[#063A6B] block">Admiralty Strategic Recommendation:</span>
            <p className="text-[11px] text-[#55738C] leading-relaxed">
              Under this scenario, fuel optimization yields maximum financial leverage. Slow-steaming container
              units from 18.5 kts to 16.8 kts offsets the $129/MT bunker surge, recovering $24,800/day with zero
              berth schedule penalties.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
