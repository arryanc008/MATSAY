import React, { useState } from 'react';
import {
  Bell,
  AlertTriangle,
  AlertOctagon,
  Info,
  CheckCircle,
  Compass,
  ArrowRight,
  Filter
} from 'lucide-react';
import { useMaritime } from '../context/MaritimeContext';

export const AlertsPage: React.FC = () => {
  const { alerts, acknowledgeAlert, setActiveVesselId, setMapFocusTarget, vessels, setCurrentPath } = useMaritime();

  const [activeCategory, setActiveCategory] = useState<'ALL' | 'Critical' | 'Warning' | 'Information' | 'Resolved'>('ALL');

  const filteredAlerts = alerts.filter((a) => {
    if (activeCategory === 'ALL') return true;
    return a.category === activeCategory;
  });

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-[#063A6B] tracking-tight">
            Operational Alert & Incident Center
          </h1>
          <p className="text-xs text-[#55738C] mt-0.5">
            Real-time navigational deviations, severe weather crossings, port wait advisory notices, and bunker anomalies
          </p>
        </div>

        {/* Filter categories */}
        <div className="flex items-center gap-1 bg-white border border-[#B9DDF5] p-1 rounded-md shadow-xs overflow-x-auto max-w-full">
          {(['ALL', 'Critical', 'Warning', 'Information', 'Resolved'] as const).map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-2.5 sm:px-3 py-1 text-xs font-bold rounded transition-colors whitespace-nowrap ${
                activeCategory === cat
                  ? 'bg-[#0879D1] text-white shadow-xs'
                  : 'text-[#063A6B] hover:bg-[#EFF9FF]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Alerts Feed */}
      <div className="space-y-3">
        {filteredAlerts.length === 0 ? (
          <div className="p-8 bg-white border border-[#B9DDF5] rounded-lg text-center text-[#55738C] text-xs">
            No active operational alerts in this category. All fleet vectors nominal.
          </div>
        ) : (
          filteredAlerts.map((alert) => {
            const isCritical = alert.category === 'Critical';
            const isWarning = alert.category === 'Warning';
            const isResolved = alert.category === 'Resolved';

            return (
              <div
                key={alert.id}
                className={`p-4 rounded-lg border transition-all ${
                  isCritical
                    ? 'bg-white border-[#E84A5A] shadow-xs'
                    : isWarning
                    ? 'bg-white border-[#F3A712] shadow-xs'
                    : isResolved
                    ? 'bg-[#EFF9FF]/40 border-[#B9DDF5]/60 opacity-80'
                    : 'bg-white border-[#0879D1]'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-[#EFF9FF]">
                  <div className="flex items-center gap-2">
                    {isCritical ? (
                      <AlertOctagon className="w-4 h-4 text-[#E84A5A] shrink-0" />
                    ) : isWarning ? (
                      <AlertTriangle className="w-4 h-4 text-[#F3A712] shrink-0" />
                    ) : isResolved ? (
                      <CheckCircle className="w-4 h-4 text-[#18A879] shrink-0" />
                    ) : (
                      <Info className="w-4 h-4 text-[#0879D1] shrink-0" />
                    )}
                    <span className="text-sm font-extrabold text-[#063A6B]">{alert.title}</span>
                    <span
                      className={`text-[9px] uppercase font-bold px-2 py-0.5 rounded ${
                        isCritical
                          ? 'bg-[#E84A5A]/10 text-[#E84A5A]'
                          : isWarning
                          ? 'bg-[#F3A712]/10 text-[#F3A712]'
                          : isResolved
                          ? 'bg-[#18A879]/10 text-[#18A879]'
                          : 'bg-[#0879D1]/10 text-[#0879D1]'
                      }`}
                    >
                      {alert.category}
                    </span>
                  </div>

                  <span className="text-[11px] font-mono text-[#55738C]">{alert.timestamp}</span>
                </div>

                <p className="text-xs text-[#55738C] mt-2 leading-relaxed">{alert.description}</p>

                {alert.actionRequired && (
                  <div className="mt-2.5 p-2 bg-[#EFF9FF] rounded border border-[#B9DDF5]/80 flex items-center justify-between text-xs">
                    <span className="font-semibold text-[#063A6B]">
                      Recommended Operational Protocol: {alert.actionRequired}
                    </span>
                  </div>
                )}

                <div className="flex flex-wrap items-center justify-end gap-2 mt-3 pt-2 border-t border-[#EFF9FF] text-xs">
                  {alert.vesselId && (
                    <button
                      onClick={() => {
                        const targetVessel = vessels.find((v) => v.id === alert.vesselId);
                        if (targetVessel) {
                          setActiveVesselId(targetVessel.id);
                          setMapFocusTarget({
                            lat: targetVessel.position.lat,
                            lng: targetVessel.position.lng,
                            zoom: 8
                          });
                          setCurrentPath('/command-center');
                        }
                      }}
                      className="px-3 py-1.5 text-xs font-semibold text-[#0879D1] hover:bg-[#EFF9FF] rounded flex items-center gap-1 transition-colors"
                    >
                      <Compass className="w-3.5 h-3.5" />
                      <span>Locate Vessel on Map</span>
                    </button>
                  )}

                  {!alert.acknowledged && (
                    <button
                      onClick={() => acknowledgeAlert(alert.id)}
                      className="px-3 py-1.5 text-xs font-bold bg-[#062B52] hover:bg-[#0A3D6B] text-white rounded transition-colors shadow-xs"
                    >
                      Acknowledge Incident
                    </button>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
