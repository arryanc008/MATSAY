import React, { useState } from 'react';
import {
  Radio,
  Send,
  Ship,
  AlertTriangle,
  CheckCheck,
  Check,
  ShieldAlert,
  Clock,
  MessageSquare
} from 'lucide-react';
import { useMaritime } from '../context/MaritimeContext';

export const CommunicationsPage: React.FC = () => {
  const { communications, sendCommunication, vessels } = useMaritime();

  const [activeChannel, setActiveChannel] = useState<'All' | 'Fleet-wide' | 'Vessel-specific' | 'Operations' | 'Weather' | 'Emergency'>('All');
  const [recipient, setRecipient] = useState('All Indian Ocean & Arabian Sea Vessels');
  const [channelType, setChannelType] = useState<'Fleet-wide' | 'Vessel-specific' | 'Operations' | 'Weather' | 'Emergency'>('Operations');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [isUrgent, setIsUrgent] = useState(false);

  const filteredMsgs = communications.filter((m) => {
    if (activeChannel === 'All') return true;
    return m.channel === activeChannel;
  });

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject.trim() || !body.trim()) return;

    sendCommunication({
      channel: channelType,
      sender: 'Capt. James H. Mercer (Fleet Commander)',
      recipient,
      subject,
      body,
      urgent: isUrgent
    });

    setSubject('');
    setBody('');
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-[#063A6B] tracking-tight">
            Admiralty Operational Dispatch & Communications
          </h1>
          <p className="text-xs text-[#55738C] mt-0.5">
            Operational coordination console · Satellite data link telemetry and Master navigational instructions
          </p>
        </div>

        <span className="text-[10px] font-mono text-[#55738C] bg-white border border-[#B9DDF5] px-2.5 py-1 rounded">
          * Operational Coordination Bridge (GMDSS compliance maintained via SOLAS equipment)
        </span>
      </div>

      {/* Main Grid: Message Composer on Left + Transmission Log on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* Compose Directive (5 cols) */}
        <div className="lg:col-span-5 bg-white border border-[#B9DDF5] rounded-lg shadow-xs p-4 space-y-3 text-xs">
          <div className="flex items-center gap-2 pb-2 border-b border-[#EFF9FF]">
            <Radio className="w-4 h-4 text-[#0879D1]" />
            <span className="font-bold text-[#063A6B]">Transmit Operational Directive</span>
          </div>

          <form onSubmit={handleSend} className="space-y-3">
            <div>
              <label className="text-[10px] uppercase font-bold text-[#55738C] block mb-1">
                Channel Classification
              </label>
              <select
                value={channelType}
                onChange={(e) => setChannelType(e.target.value as any)}
                className="w-full p-2 bg-[#EFF9FF] border border-[#B9DDF5] rounded font-semibold text-[#063A6B] text-xs"
              >
                <option value="Operations">Operations Advisory</option>
                <option value="Vessel-specific">Vessel-Specific Master Order</option>
                <option value="Weather">Severe Weather Alert</option>
                <option value="Emergency">Navigational Safety / Emergency</option>
                <option value="Fleet-wide">Fleet-Wide Broadcast</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] uppercase font-bold text-[#55738C] block mb-1">
                Recipient / Station
              </label>
              <select
                value={recipient}
                onChange={(e) => setRecipient(e.target.value)}
                className="w-full p-2 bg-[#EFF9FF] border border-[#B9DDF5] rounded font-semibold text-[#063A6B] text-xs"
              >
                <option value="All Indian Ocean & Arabian Sea Vessels">All Fleet Units (Broadcast)</option>
                {vessels.map((v) => (
                  <option key={v.id} value={`${v.name} (Master)`}>
                    {v.name} (Master / Chief Engineer)
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[10px] uppercase font-bold text-[#55738C] block mb-1">
                Directive Subject
              </label>
              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="e.g. Authorized RPM Throttle to absorb Colombo Berth Delay"
                required
                className="w-full p-2 border border-[#B9DDF5] rounded bg-[#EFF9FF]/40 text-xs text-[#063A6B]"
              />
            </div>

            <div>
              <label className="text-[10px] uppercase font-bold text-[#55738C] block mb-1">
                Transmission Body
              </label>
              <textarea
                value={body}
                onChange={(e) => setBody(e.target.value)}
                placeholder="Specify precise navigational instructions, target coordinates, speed limits, or bunkering schedules..."
                rows={4}
                required
                className="w-full p-2 border border-[#B9DDF5] rounded bg-[#EFF9FF]/40 text-xs text-[#063A6B]"
              />
            </div>

            <div className="flex items-center justify-between pt-1">
              <label className="flex items-center gap-2 cursor-pointer text-[#E84A5A] font-bold text-xs">
                <input
                  type="checkbox"
                  checked={isUrgent}
                  onChange={(e) => setIsUrgent(e.target.checked)}
                  className="rounded border-[#E84A5A] text-[#E84A5A] focus:ring-0"
                />
                <span>Flash Priority Emergency Transmission</span>
              </label>

              <button
                type="submit"
                className="px-4 py-2 bg-[#062B52] hover:bg-[#0A3D6B] text-white font-bold rounded text-xs transition-colors shadow-xs flex items-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Transmit Order</span>
              </button>
            </div>
          </form>
        </div>

        {/* Transmission Feed (7 cols) */}
        <div className="lg:col-span-7 bg-white border border-[#B9DDF5] rounded-lg shadow-xs p-4 space-y-3 text-xs">
          <div className="flex items-center justify-between pb-2 border-b border-[#EFF9FF]">
            <span className="font-bold text-[#063A6B]">Operational Dispatch Log</span>
            <div className="flex items-center gap-1">
              {(['All', 'Emergency', 'Operations', 'Weather'] as const).map((ch) => (
                <button
                  key={ch}
                  onClick={() => setActiveChannel(ch)}
                  className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    activeChannel === ch ? 'bg-[#0879D1] text-white' : 'text-[#55738C] hover:bg-[#EFF9FF]'
                  }`}
                >
                  {ch}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2.5 max-h-[520px] overflow-y-auto pr-1">
            {filteredMsgs.map((msg) => (
              <div
                key={msg.id}
                className={`p-3 rounded-md border space-y-1.5 ${
                  msg.urgent
                    ? 'bg-[#E84A5A]/5 border-[#E84A5A]'
                    : 'bg-[#EFF9FF]/40 border-[#B9DDF5]'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span
                      className={`text-[9px] font-bold uppercase px-1.5 py-0.5 rounded ${
                        msg.urgent ? 'bg-[#E84A5A] text-white' : 'bg-[#0879D1] text-white'
                      }`}
                    >
                      {msg.channel}
                    </span>
                    <span className="font-bold text-[#063A6B]">{msg.subject}</span>
                  </div>
                  <span className="text-[10px] text-[#55738C] font-mono">{msg.timestamp}</span>
                </div>

                <div className="text-[11px] text-[#55738C] flex items-center justify-between">
                  <span>To: <strong className="text-[#063A6B]">{msg.recipient}</strong></span>
                  <span className="flex items-center gap-1 text-[#18A879] font-mono text-[10px]">
                    <CheckCheck className="w-3.5 h-3.5" /> {msg.status}
                  </span>
                </div>

                <p className="text-[11px] text-[#063A6B] leading-relaxed pt-1 border-t border-[#B9DDF5]/40">
                  {msg.body}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
