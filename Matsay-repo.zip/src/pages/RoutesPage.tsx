import React, { useState } from 'react';
import {
  GitFork,
  Ship,
  MapPin,
  Compass,
  ArrowRight,
  TrendingDown,
  Wind,
  Waves,
  ShieldAlert,
  Sparkles,
  CheckCircle2,
  FileText
} from 'lucide-react';
import { useMaritime } from '../context/MaritimeContext';
import { FleetGISMap } from '../components/map/FleetGISMap';

export const RoutesPage: React.FC = () => {
  const { vessels, activeVessel, activeVesselId, setActiveVesselId, setCurrentPath, setMapFocusTarget } = useMaritime();

  const [selectedVesselId, setSelectedVesselId] = useState<string>(activeVesselId || vessels[0].id);
  const currentVessel = vessels.find((v) => v.id === selectedVesselId) || vessels[0];

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-[#063A6B] tracking-tight">
            Voyage Route Optimization & Explainability
          </h1>
          <p className="text-xs text-[#55738C] mt-0.5">
            Planned Baseline Path vs Quantum MetOcean Optimized Track · Hydrodynamic current piggybacking & gale avoidance
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setCurrentPath('/command-center')}
            className="px-3 py-1.5 bg-white border border-[#B9DDF5] text-xs font-semibold text-[#063A6B] rounded-md hover:bg-[#EFF9FF] transition-colors"
          >
            Command Center
          </button>
          <button
            onClick={() => setCurrentPath('/optimization')}
            className="px-3 py-1.5 bg-[#0879D1] text-white text-xs font-bold rounded-md hover:bg-[#062B52] transition-colors shadow-xs"
          >
            Full Fleet Optimizer
          </button>
        </div>
      </div>

      {/* Vessel Selector Bar */}
      <div className="p-3 bg-white border border-[#B9DDF5] rounded-lg shadow-xs flex items-center justify-between flex-wrap gap-2 text-xs">
        <div className="flex items-center gap-2">
          <Ship className="w-4 h-4 text-[#0879D1]" />
          <span className="font-bold text-[#063A6B]">Select Active Voyage Corridor:</span>
          <select
            value={selectedVesselId}
            onChange={(e) => {
              setSelectedVesselId(e.target.value);
              setActiveVesselId(e.target.value);
            }}
            className="p-1.5 bg-[#EFF9FF] border border-[#B9DDF5] rounded text-xs font-bold text-[#063A6B]"
          >
            {vessels.map((v) => (
              <option key={v.id} value={v.id}>
                {v.name} ({v.origin} → {v.destination})
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-3 text-xs font-mono">
          <span className="text-[#55738C]">Planned Distance: 1,840 nm</span>
          <span className="text-[#18A879] font-bold">Optimized Track: 1,798 nm (-42 nm)</span>
        </div>
      </div>

      {/* Main Grid: GIS Map preview + Route Comparison and Explainability */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* Map showing both routes (7 cols) */}
        <div className="lg:col-span-7 space-y-3">
          <FleetGISMap heightClass="h-[360px] sm:h-[460px] lg:h-[520px]" />
          <div className="p-3 bg-white border border-[#B9DDF5] rounded-lg shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs">
            <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4">
              <div className="flex items-center gap-1.5">
                <span className="w-5 h-0.5 bg-[#55738C] border-b border-dashed border-[#55738C]"></span>
                <span className="text-[#55738C] font-semibold">Planned Baseline Route (ECDIS Default)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-5 h-1 bg-[#18A879]"></span>
                <span className="text-[#18A879] font-bold">Quantum-Optimized Track (Current Assisted)</span>
              </div>
            </div>
            <button
              onClick={() =>
                setMapFocusTarget({
                  lat: currentVessel.position.lat,
                  lng: currentVessel.position.lng,
                  zoom: 7
                })
              }
              className="text-[#0879D1] font-bold hover:underline shrink-0"
            >
              Center on Vessel
            </button>
          </div>
        </div>

        {/* Comparison & Explainability Panel (5 cols) */}
        <div className="lg:col-span-5 space-y-3">
          {/* Comparison Card */}
          <div className="bg-white border border-[#B9DDF5] rounded-lg shadow-xs p-3 sm:p-4 space-y-3 text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-[#EFF9FF]">
              <span className="font-bold text-[#063A6B]">Route Performance Comparison</span>
              <span className="text-[10px] font-mono text-[#18A879] font-bold">NET GAIN: 8.6%</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-[#F4FBFF] rounded border border-[#B9DDF5]/80 space-y-1.5">
                <span className="text-[10px] uppercase font-bold text-[#55738C] block">
                  PLANNED ROUTE
                </span>
                <div className="text-sm font-bold font-mono text-[#063A6B]">1,840 nm</div>
                <div className="text-[11px] text-[#55738C]">ETA: Oct 04, 16:30 UTC</div>
                <div className="text-[11px] text-[#55738C]">Predicted Fuel: 248.5 MT</div>
                <div className="text-[11px] text-[#55738C]">Cost: $160,280</div>
                <div className="text-[11px] text-[#E84A5A] font-semibold">Wave exposure: 2.8m avg</div>
              </div>

              <div className="p-3 bg-[#EFF9FF] rounded border border-[#0879D1]/40 space-y-1.5">
                <span className="text-[10px] uppercase font-bold text-[#18A879] block">
                  OPTIMIZED ROUTE
                </span>
                <div className="text-sm font-bold font-mono text-[#063A6B]">1,798 nm (-42 nm)</div>
                <div className="text-[11px] text-[#18A879] font-semibold">ETA: Oct 04, 14:30 UTC (-2 hrs)</div>
                <div className="text-[11px] text-[#18A879] font-bold">Predicted Fuel: 227.1 MT (-8.6%)</div>
                <div className="text-[11px] text-[#18A879] font-bold">Cost: $146,479 (-$13,801)</div>
                <div className="text-[11px] text-[#18A879] font-semibold">Wave exposure: 1.6m avg</div>
              </div>
            </div>
          </div>

          {/* Explainability Engine */}
          <div className="bg-white border border-[#B9DDF5] rounded-lg shadow-xs p-4 space-y-3 text-xs">
            <div className="flex items-center gap-2 pb-2 border-b border-[#EFF9FF]">
              <Sparkles className="w-4 h-4 text-[#0879D1]" />
              <span className="font-bold text-[#063A6B]">
                Explainability: Why Was The Route Altered?
              </span>
            </div>

            <div className="space-y-2">
              <div className="p-2.5 rounded bg-[#EFF9FF] border border-[#B9DDF5]/60 flex items-start gap-2">
                <div className="w-5 h-5 rounded-full bg-[#0879D1] text-white flex items-center justify-center shrink-0 text-[10px] font-bold mt-0.5">
                  1
                </div>
                <div>
                  <div className="font-bold text-[#063A6B]">Equatorial Countercurrent Harnessing</div>
                  <p className="text-[11px] text-[#55738C] mt-0.5 leading-relaxed">
                    By shifting waypoints 0.8° South along 80°E, the hull rides +1.4 knots of eastward
                    current, reducing necessary shaft power by 4,200 kW.
                  </p>
                </div>
              </div>

              <div className="p-2.5 rounded bg-[#EFF9FF] border border-[#B9DDF5]/60 flex items-start gap-2">
                <div className="w-5 h-5 rounded-full bg-[#18A879] text-white flex items-center justify-center shrink-0 text-[10px] font-bold mt-0.5">
                  2
                </div>
                <div>
                  <div className="font-bold text-[#063A6B]">Headwind & Wave Energy Attenuation</div>
                  <p className="text-[11px] text-[#55738C] mt-0.5 leading-relaxed">
                    Avoids the northern Arabian Sea 26.5 kts headwind zone and 3.6m cross-swells, cutting
                    wave-added resistance from 14.8% down to 3.2%.
                  </p>
                </div>
              </div>

              <div className="p-2.5 rounded bg-[#EFF9FF] border border-[#B9DDF5]/60 flex items-start gap-2">
                <div className="w-5 h-5 rounded-full bg-[#062B52] text-white flex items-center justify-center shrink-0 text-[10px] font-bold mt-0.5">
                  3
                </div>
                <div>
                  <div className="font-bold text-[#063A6B]">Strait of Malacca TSS Alignment</div>
                  <p className="text-[11px] text-[#55738C] mt-0.5 leading-relaxed">
                    Routes directly into the Western approaches of the Traffic Separation Scheme at an optimal
                    14.0 kts approach speed, avoiding anchorage delays.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
