import React, { useState } from 'react';
import {
  Boxes,
  Ship,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  Calendar,
  Layers,
  MapPin
} from 'lucide-react';
import { useMaritime } from '../context/MaritimeContext';

export const CargoPage: React.FC = () => {
  const { vessels, ports, setCurrentPath } = useMaritime();

  const [originPort, setOriginPort] = useState('port-singapore');
  const [destPort, setDestPort] = useState('port-mumbai-jnpt');
  const [cargoType, setCargoType] = useState('Containerized TEU');
  const [cargoVolume, setCargoVolume] = useState('9,500 TEU');
  const [deadlineDays, setDeadlineDays] = useState(5);

  const matchedVessels = vessels.map((v) => {
    const isContainer = v.type === 'Container';
    const draftFit = v.specs.draftM <= 15.5;
    const speedScore = v.speedKts >= 16 ? 95 : 82;
    const available = v.status !== 'MAINTENANCE';

    const suitabilityScore = isContainer && draftFit && available ? 96 : 64;

    return {
      vessel: v,
      draftFit,
      suitabilityScore,
      recommendedSpeed: 17.8,
      estimatedEtaDays: 4.2
    };
  });

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-[#063A6B] tracking-tight">
            Cargo Demand & Fleet Allocation Matrix
          </h1>
          <p className="text-xs text-[#55738C] mt-0.5">
            Matching commercial freight demand with vessel deadweight, draft restrictions, and schedule windows
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setCurrentPath('/optimization')}
            className="px-3 py-1.5 bg-[#0879D1] text-white text-xs font-bold rounded-md hover:bg-[#062B52] transition-colors shadow-xs"
          >
            Run Allocation Optimizer
          </button>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* Cargo Requirement Input Form (4 cols) */}
        <div className="lg:col-span-4 bg-white border border-[#B9DDF5] rounded-lg shadow-xs p-4 space-y-3 text-xs">
          <div className="flex items-center gap-2 pb-2 border-b border-[#EFF9FF]">
            <Boxes className="w-4 h-4 text-[#0879D1]" />
            <span className="font-bold text-[#063A6B]">New Cargo Requirement</span>
          </div>

          <div>
            <label className="text-[10px] uppercase font-bold text-[#55738C] block mb-1">
              Origin Port
            </label>
            <select
              value={originPort}
              onChange={(e) => setOriginPort(e.target.value)}
              className="w-full p-2 bg-[#EFF9FF] border border-[#B9DDF5] rounded font-semibold text-[#063A6B] text-xs"
            >
              {ports.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.country})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[10px] uppercase font-bold text-[#55738C] block mb-1">
              Destination Port
            </label>
            <select
              value={destPort}
              onChange={(e) => setDestPort(e.target.value)}
              className="w-full p-2 bg-[#EFF9FF] border border-[#B9DDF5] rounded font-semibold text-[#063A6B] text-xs"
            >
              {ports.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.country})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[10px] uppercase font-bold text-[#55738C] block mb-1">
              Cargo Classification
            </label>
            <select
              value={cargoType}
              onChange={(e) => setCargoType(e.target.value)}
              className="w-full p-2 bg-[#EFF9FF] border border-[#B9DDF5] rounded text-xs text-[#063A6B]"
            >
              <option value="Containerized TEU">Containerized TEU (Finished Goods)</option>
              <option value="Bulk Minerals">Dry Bulk Minerals (Iron Ore / Coal)</option>
              <option value="Liquid Hydrocarbons">Liquid Hydrocarbons (Crude / DPP)</option>
              <option value="Cryogenic LNG">Cryogenic LNG</option>
            </select>
          </div>

          <div>
            <label className="text-[10px] uppercase font-bold text-[#55738C] block mb-1">
              Required Capacity / Volume
            </label>
            <input
              type="text"
              value={cargoVolume}
              onChange={(e) => setCargoVolume(e.target.value)}
              className="w-full p-2 border border-[#B9DDF5] rounded bg-[#EFF9FF] font-mono text-xs"
            />
          </div>

          <div>
            <div className="flex justify-between mb-1">
              <span className="font-bold text-[#063A6B]">Delivery Deadline</span>
              <span className="font-mono text-[#0879D1] font-bold">{deadlineDays} Days</span>
            </div>
            <input
              type="range"
              min="2"
              max="15"
              value={deadlineDays}
              onChange={(e) => setDeadlineDays(Number(e.target.value))}
              className="w-full accent-[#0879D1]"
            />
          </div>
        </div>

        {/* Fleet Allocation Matrix (8 cols) */}
        <div className="lg:col-span-8 bg-white border border-[#B9DDF5] rounded-lg shadow-xs p-4 space-y-3 text-xs">
          <div className="flex items-center justify-between pb-2 border-b border-[#EFF9FF]">
            <span className="font-bold text-[#063A6B]">Fleet Unit Suitability Matching</span>
            <span className="text-[10px] font-mono text-[#18A879] font-bold">
              TOP MATCH: MV OCEAN STAR (96% Match)
            </span>
          </div>

          <div className="space-y-2">
            {matchedVessels.map((item, idx) => (
              <div
                key={item.vessel.id}
                className={`p-3 rounded-md border flex items-center justify-between transition-colors ${
                  idx === 0
                    ? 'bg-[#EFF9FF] border-[#0879D1]'
                    : 'bg-white border-[#B9DDF5] hover:bg-[#F4FBFF]'
                }`}
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-[#063A6B] text-xs">
                      {item.vessel.name}
                    </span>
                    <span className="text-[10px] text-[#55738C] font-mono">
                      {item.vessel.type} · Capacity: {item.vessel.specs.capacityTeuOrM3}
                    </span>
                    {idx === 0 && (
                      <span className="text-[9px] font-bold text-white bg-[#18A879] px-1.5 py-0.2 rounded">
                        RECOMMENDED
                      </span>
                    )}
                  </div>
                  <div className="text-[11px] text-[#55738C] mt-1 flex items-center gap-3">
                    <span>Draft clearance: {item.draftFit ? 'Compliant (15.2m)' : 'Excess Draft'}</span>
                    <span>·</span>
                    <span>Transit ETA: {item.estimatedEtaDays} days</span>
                  </div>
                </div>

                <div className="text-right flex items-center gap-3">
                  <div>
                    <span className="text-[10px] text-[#55738C] block">MATCH SCORE</span>
                    <span
                      className={`text-sm font-extrabold font-mono ${
                        item.suitabilityScore > 80 ? 'text-[#18A879]' : 'text-[#55738C]'
                      }`}
                    >
                      {item.suitabilityScore}%
                    </span>
                  </div>
                  <button
                    onClick={() => setCurrentPath('/optimization')}
                    className="px-3 py-1.5 bg-[#0879D1] text-white font-bold rounded text-xs hover:bg-[#062B52] transition-colors"
                  >
                    Assign Vessel
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
