import React, { useState } from 'react';
import {
  Compass,
  Lock,
  Mail,
  Shield,
  KeyRound,
  ArrowRight,
  Ship,
  Waves,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { useMaritime } from '../context/MaritimeContext';

export const LoginPage: React.FC = () => {
  const { login } = useMaritime();
  const [email, setEmail] = useState('commander.mercer@matsay.maritime');
  const [password, setPassword] = useState('••••••••••••');
  const [rememberMe, setRememberMe] = useState(true);
  const [errorMessage, setErrorMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setIsLoading(true);

    setTimeout(() => {
      if (email.includes('@') && password.length >= 4) {
        const success = login(email, password);
        if (!success) {
          setErrorMessage('Invalid credentials or unauthorized sector access.');
        }
      } else {
        setErrorMessage('Please provide a valid maritime admiralty work email.');
      }
      setIsLoading(false);
    }, 500);
  };

  const handleQuickDemoAccess = () => {
    setEmail('commander.mercer@matsay.maritime');
    setPassword('Admiralty#2026');
    login('commander.mercer@matsay.maritime', 'Admiralty#2026');
  };

  return (
    <div className="min-h-screen w-full flex flex-col lg:flex-row bg-[#F4FBFF] text-[#063A6B]">
      {/* LEFT SIDE: Maritime Visual & Branding */}
      <div className="lg:w-7/12 relative bg-[#062B52] overflow-hidden flex flex-col justify-between p-8 sm:p-12 lg:p-16 text-white min-h-[380px] lg:min-h-screen">
        {/* Subtle decorative oceanic SVG wave background */}
        <div className="absolute inset-0 opacity-20 pointer-events-none">
          <svg className="w-full h-full object-cover" viewBox="0 0 1000 1000" preserveAspectRatio="none">
            <path
              d="M0,300 C150,200 350,400 500,320 C650,240 850,380 1000,280 L1000,1000 L0,1000 Z"
              fill="#0879D1"
            />
            <path
              d="M0,500 C200,450 400,600 600,520 C800,440 900,580 1000,500 L1000,1000 L0,1000 Z"
              fill="#0A3D6B"
              opacity="0.6"
            />
          </svg>
        </div>

        {/* Ambient Maritime Grid Lines */}
        <div
          className="absolute inset-0 opacity-10 pointer-events-none"
          style={{
            backgroundImage:
              'linear-gradient(to right, #B9DDF5 1px, transparent 1px), linear-gradient(to bottom, #B9DDF5 1px, transparent 1px)',
            backgroundSize: '40px 40px'
          }}
        />

        {/* Top Logo */}
        <div className="relative z-10 flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#0879D1] to-[#062B52] flex items-center justify-center shadow-lg border border-[#B9DDF5]/30">
            <Compass className="w-7 h-7 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-2xl font-black tracking-widest text-white">MATSAY</span>
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-[#0879D1]/60 text-[#DDF3FF] border border-[#B9DDF5]/20">
                Enterprise Fleet Core
              </span>
            </div>
            <p className="text-xs text-[#B9DDF5]/80 font-medium">Intelligent Maritime Fleet Command Center</p>
          </div>
        </div>

        {/* Middle Hero Typography */}
        <div className="relative z-10 my-8 lg:my-0 max-w-xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-[#0879D1]/30 border border-[#B9DDF5]/20 text-xs font-mono text-[#DDF3FF]">
            <Waves className="w-3.5 h-3.5 text-[#0879D1]" />
            <span>Multi-Objective Fleet Optimization · Real-Time AIS & MetOcean</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white leading-tight">
            Command the fleet.
            <br />
            <span className="text-[#B9DDF5]">Optimize every voyage.</span>
          </h1>

          <p className="text-sm sm:text-base text-[#DDF3FF]/90 leading-relaxed font-light">
            Unified admiralty command combining real-world vessel telemetry, non-linear hydrodynamic fuel
            prediction, and quantum-inspired routing algorithms to maximize schedule reliability and eliminate
            bunker waste.
          </p>

          <div className="grid grid-cols-3 gap-4 pt-4 border-t border-[#0A3D6B]">
            <div>
              <div className="text-xl sm:text-2xl font-black font-mono text-[#18A879]">-8.6%</div>
              <div className="text-[11px] text-[#B9DDF5]/80">Fleet Bunker Reduction</div>
            </div>
            <div>
              <div className="text-xl sm:text-2xl font-black font-mono text-white">142 ms</div>
              <div className="text-[11px] text-[#B9DDF5]/80">Q-PSO Search Convergence</div>
            </div>
            <div>
              <div className="text-xl sm:text-2xl font-black font-mono text-[#18A879]">96.2%</div>
              <div className="text-[11px] text-[#B9DDF5]/80">Schedule Reliability</div>
            </div>
          </div>
        </div>

        {/* Bottom Security Banner */}
        <div className="relative z-10 text-[11px] text-[#B9DDF5]/70 flex items-center justify-between border-t border-[#0A3D6B] pt-4">
          <span>Admiralty Maritime Operations · Sector V-North</span>
          <span className="font-mono">ECDIS / AIS Revision 2026.4</span>
        </div>
      </div>

      {/* RIGHT SIDE: Commander Sign-In Card */}
      <div className="lg:w-5/12 flex items-center justify-center p-6 sm:p-12 lg:p-16">
        <div className="w-full max-w-md bg-white border border-[#B9DDF5] rounded-xl shadow-lg p-6 sm:p-8 space-y-6">
          <div>
            <h2 className="text-2xl font-extrabold text-[#063A6B] tracking-tight">
              Welcome back, Commander
            </h2>
            <p className="text-xs text-[#55738C] mt-1">
              Sign in to access your fleet operations center and mission command.
            </p>
          </div>

          {errorMessage && (
            <div className="p-3 bg-[#E84A5A]/10 border border-[#E84A5A]/30 rounded-md text-xs text-[#E84A5A] flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase text-[#063A6B] mb-1.5">
                Work Email
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-[#55738C] absolute left-3 top-2.5" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="commander.name@matsay.maritime"
                  required
                  className="w-full pl-9 pr-3 py-2 text-xs border border-[#B9DDF5] rounded-md focus:outline-none focus:border-[#0879D1] text-[#063A6B] bg-[#EFF9FF]/40"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold uppercase text-[#063A6B]">Password</label>
                <button
                  type="button"
                  onClick={() => alert('Password reset dispatched to marine superintendent registry.')}
                  className="text-[11px] text-[#0879D1] hover:underline font-semibold"
                >
                  Forgot password?
                </button>
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-[#55738C] absolute left-3 top-2.5" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  required
                  className="w-full pl-9 pr-3 py-2 text-xs border border-[#B9DDF5] rounded-md focus:outline-none focus:border-[#0879D1] text-[#063A6B] bg-[#EFF9FF]/40 font-mono"
                />
              </div>
            </div>

            <div className="flex items-center justify-between text-xs pt-1">
              <label className="flex items-center gap-2 cursor-pointer text-[#55738C]">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="rounded border-[#B9DDF5] text-[#0879D1] focus:ring-0 w-3.5 h-3.5"
                />
                <span>Remember this device</span>
              </label>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-2.5 px-4 bg-[#062B52] hover:bg-[#0A3D6B] text-white rounded-md text-xs font-extrabold uppercase tracking-wider transition-colors shadow-md flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <span>{isLoading ? 'Verifying Admiralty Credentials...' : 'SIGN IN TO COMMAND CENTER'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {/* Quick Demo Access for immediate inspection */}
          <div className="p-3 bg-[#EFF9FF] rounded-md border border-[#B9DDF5] flex items-center justify-between">
            <div>
              <div className="text-[11px] font-bold text-[#063A6B]">Demo Commander Session</div>
              <div className="text-[10px] text-[#55738C]">Capt. James H. Mercer · Indian Ocean Sector</div>
            </div>
            <button
              onClick={handleQuickDemoAccess}
              className="px-2.5 py-1 text-[11px] font-bold bg-[#0879D1] text-white rounded hover:bg-[#062B52] transition-colors shadow-xs"
            >
              Instant Access
            </button>
          </div>

          {/* Security Indicators */}
          <div className="border-t border-[#B9DDF5]/60 pt-4 space-y-2">
            <div className="text-[10px] uppercase font-bold text-[#55738C] tracking-wide text-center">
              Secure maritime operations environment
            </div>
            <div className="flex items-center justify-around text-[10px] text-[#55738C]">
              <div className="flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-[#18A879]" />
                <span>Encrypted connection</span>
              </div>
              <div className="flex items-center gap-1">
                <Shield className="w-3 h-3 text-[#0879D1]" />
                <span>Authorized access</span>
              </div>
              <div className="flex items-center gap-1">
                <KeyRound className="w-3 h-3 text-[#062B52]" />
                <span>Data protected</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
