import React, { useState } from 'react';
import {
  Fuel,
  Ship,
  Gauge,
  TrendingDown,
  CloudSun,
  DollarSign,
  Leaf,
  Wind,
  Waves,
  Sliders
} from 'lucide-react';
import { useMaritime } from '../context/MaritimeContext';
import { calculateFuelPrediction } from '../services/fuelModel';

export const FuelPage: React.FC = () => {
  const { vessels, activeVessel, setCurrentPath } = useMaritime();

  const [selectedVesselId, setSelectedVesselId] = useState<string>(activeVessel?.id || vessels[0].id);
  const currentVessel = vessels.find((v) => v.id === selectedVesselId) || vessels[0];

  const [speedKts, setSpeedKts] = useState<number>(currentVessel.speedKts || 18.0);
  const [cargoLoadPct, setCargoLoadPct] = useState<number>(currentVessel.cargoUtilizationPct || 85);
  const [distanceNm, setDistanceNm] = useState<number>(1800);
  const [windSpeedKts, setWindSpeedKts] = useState<number>(currentVessel.telemetry.windSpeedKts || 14);
  const [waveHeightM, setWaveHeightM] = useState<number>(currentVessel.telemetry.waveHeightM || 1.8);
  const [currentSpeedKts, setCurrentSpeedKts] = useState<number>(1.2);
  const [fuelType, setFuelType] = useState<any>(currentVessel.specs.fuelType || 'VLSFO');

  const prediction = calculateFuelPrediction({
    vessel: currentVessel,
    speedKts,
    cargoLoadPct,
    distanceNm,
    windSpeedKts,
    windAngleRelDeg: 30,
    waveHeightM,
    currentSpeedKts,
    currentAngleRelDeg: 160,
    fuelType
  });

  // Calculate speed-fuel cubic curve data points
  const speedCurvePoints = [12, 14, 16, 18, 20, 22].map((s) => {
    const res = calculateFuelPrediction({
      vessel: currentVessel,
      speedKts: s,
      cargoLoadPct,
      distanceNm,
      windSpeedKts,
      windAngleRelDeg: 30,
      waveHeightM,
      currentSpeedKts,
      currentAngleRelDeg: 160,
      fuelType
    });
    return { speed: s, fuelPerDay: res.predictedFuelMtPerDay, cost: res.fuelCostUsd };
  });

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-[#063A6B] tracking-tight">
            Fuel Intelligence & Propulsion Physics
          </h1>
          <p className="text-xs text-[#55738C] mt-0.5">
            Admiralty hydrodynamic power modeling, weather resistance penalties, and voyage burn curves
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[10px] font-mono font-bold text-[#0879D1] bg-white border border-[#B9DDF5] px-2.5 py-1 rounded">
            STATUS: REAL-TIME PREDICTIVE TELEMETRY
          </span>
        </div>
      </div>

      {/* Main Grid: Parameters / Inputs on Left + Outputs & Curves on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* Input Parameters (4 cols) */}
        <div className="lg:col-span-4 bg-white border border-[#B9DDF5] rounded-lg shadow-xs p-4 space-y-3 text-xs">
          <div className="flex items-center justify-between pb-2 border-b border-[#EFF9FF]">
            <div className="flex items-center gap-2">
              <Sliders className="w-4 h-4 text-[#0879D1]" />
              <span className="font-bold text-[#063A6B]">Voyage & Engine Inputs</span>
            </div>
            <span className="text-[10px] text-[#55738C]">Hydrodynamic parameters</span>
          </div>

          <div>
            <label className="text-[10px] uppercase font-bold text-[#55738C] block mb-1">
              Select Fleet Vessel
            </label>
            <select
              value={selectedVesselId}
              onChange={(e) => setSelectedVesselId(e.target.value)}
              className="w-full p-1.5 bg-[#EFF9FF] border border-[#B9DDF5] rounded text-xs font-bold text-[#063A6B]"
            >
              {vessels.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.name} ({v.type})
                </option>
              ))}
            </select>
          </div>

          <div>
            <div className="flex justify-between mb-1">
              <span className="font-bold text-[#063A6B]">Steaming Speed (Knots)</span>
              <span className="font-mono text-[#0879D1] font-bold">{speedKts} kts</span>
            </div>
            <input
              type="range"
              min="10"
              max="24"
              step="0.5"
              value={speedKts}
              onChange={(e) => setSpeedKts(Number(e.target.value))}
              className="w-full accent-[#0879D1]"
            />
          </div>

          <div>
            <div className="flex justify-between mb-1">
              <span className="font-bold text-[#063A6B]">Cargo Load Capacity</span>
              <span className="font-mono text-[#0879D1] font-bold">{cargoLoadPct}%</span>
            </div>
            <input
              type="range"
              min="10"
              max="100"
              value={cargoLoadPct}
              onChange={(e) => setCargoLoadPct(Number(e.target.value))}
              className="w-full accent-[#0879D1]"
            />
          </div>

          <div>
            <div className="flex justify-between mb-1">
              <span className="font-bold text-[#063A6B]">Voyage Distance (Nautical Miles)</span>
              <span className="font-mono text-[#063A6B] font-bold">{distanceNm} nm</span>
            </div>
            <input
              type="range"
              min="200"
              max="6000"
              step="100"
              value={distanceNm}
              onChange={(e) => setDistanceNm(Number(e.target.value))}
              className="w-full accent-[#0879D1]"
            />
          </div>

          <div className="grid grid-cols-2 gap-2 pt-2 border-t border-[#EFF9FF]">
            <div>
              <span className="text-[10px] text-[#55738C] font-semibold block mb-1">Wind (kts)</span>
              <input
                type="number"
                value={windSpeedKts}
                onChange={(e) => setWindSpeedKts(Number(e.target.value))}
                className="w-full p-1.5 border border-[#B9DDF5] rounded bg-[#EFF9FF] font-mono text-xs"
              />
            </div>
            <div>
              <span className="text-[10px] text-[#55738C] font-semibold block mb-1">Waves (m)</span>
              <input
                type="number"
                step="0.2"
                value={waveHeightM}
                onChange={(e) => setWaveHeightM(Number(e.target.value))}
                className="w-full p-1.5 border border-[#B9DDF5] rounded bg-[#EFF9FF] font-mono text-xs"
              />
            </div>
          </div>
        </div>

        {/* Outputs & Curves (8 cols) */}
        <div className="lg:col-span-8 space-y-4">
          {/* Key Output Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="p-3 bg-white border border-[#B9DDF5] rounded-lg shadow-xs">
              <span className="text-[10px] uppercase font-bold text-[#55738C]">PREDICTED BURN RATE</span>
              <div className="text-xl font-extrabold font-mono text-[#063A6B] mt-0.5">
                {prediction.predictedFuelMtPerDay} <span className="text-xs font-normal">MT/day</span>
              </div>
              <div className="text-[10px] text-[#55738C] mt-1 font-mono">
                Total: {prediction.totalPredictedFuelMt} MT
              </div>
            </div>

            <div className="p-3 bg-white border border-[#B9DDF5] rounded-lg shadow-xs">
              <span className="text-[10px] uppercase font-bold text-[#55738C]">ESTIMATED FUEL COST</span>
              <div className="text-xl font-extrabold font-mono text-[#063A6B] mt-0.5">
                ${(prediction.fuelCostUsd / 1000).toFixed(1)}k
              </div>
              <div className="text-[10px] text-[#18A879] mt-1 font-semibold">
                At $645 / MT benchmark
              </div>
            </div>

            <div className="p-3 bg-white border border-[#B9DDF5] rounded-lg shadow-xs">
              <span className="text-[10px] uppercase font-bold text-[#55738C]">TOTAL CO₂ EMISSIONS</span>
              <div className="text-xl font-extrabold font-mono text-[#18A879] mt-0.5">
                {prediction.co2EmissionsTons} <span className="text-xs font-normal">t</span>
              </div>
              <div className="text-[10px] text-[#55738C] mt-1 font-mono">
                3.114 t CO₂/t VLSFO
              </div>
            </div>

            <div className="p-3 bg-white border border-[#B9DDF5] rounded-lg shadow-xs">
              <span className="text-[10px] uppercase font-bold text-[#55738C]">VOYAGE DURATION</span>
              <div className="text-xl font-extrabold font-mono text-[#0879D1] mt-0.5">
                {prediction.estimatedDurationHours.toFixed(1)} <span className="text-xs font-normal">hrs</span>
              </div>
              <div className="text-[10px] text-[#55738C] mt-1 font-mono">
                SOG: {prediction.speedOverGroundKts} kts
              </div>
            </div>
          </div>

          {/* Speed vs Fuel Cubic Curve Visualization */}
          <div className="p-4 bg-white border border-[#B9DDF5] rounded-lg shadow-xs space-y-3 text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-[#EFF9FF]">
              <div>
                <span className="font-bold text-[#063A6B]">
                  Speed-Power Cubic Curve & Consumption Plateau (P ∝ V³)
                </span>
                <p className="text-[10px] text-[#55738C]">
                  Demonstrates why slow steaming reduces bunker consumption non-linearly
                </p>
              </div>
              <span className="text-[10px] font-mono text-[#0879D1] bg-[#EFF9FF] px-2 py-0.5 rounded border border-[#B9DDF5]">
                Admiralty Coeff: {prediction.admiraltyCoefficient}
              </span>
            </div>

            {/* Custom Bar / Curve Chart */}
            <div className="grid grid-cols-6 gap-2 pt-2">
              {speedCurvePoints.map((pt) => {
                const isCurrent = Math.round(speedKts) === pt.speed;
                const maxFuel = 90;
                const heightPct = Math.min(100, Math.round((pt.fuelPerDay / maxFuel) * 100));

                return (
                  <div
                    key={pt.speed}
                    onClick={() => setSpeedKts(pt.speed)}
                    className={`flex flex-col items-center p-2 rounded cursor-pointer transition-colors ${
                      isCurrent ? 'bg-[#EFF9FF] border border-[#0879D1]' : 'hover:bg-[#F4FBFF]'
                    }`}
                  >
                    <div className="h-32 w-full flex items-end justify-center mb-2">
                      <div
                        className={`w-8 rounded-t transition-all ${
                          isCurrent ? 'bg-[#0879D1]' : 'bg-[#B9DDF5]'
                        }`}
                        style={{ height: `${heightPct}%` }}
                      />
                    </div>
                    <span className="font-mono font-bold text-[#063A6B] text-xs">{pt.speed} kts</span>
                    <span className="font-mono text-[10px] text-[#55738C] mt-0.5">{pt.fuelPerDay} MT/d</span>
                    <span className="font-mono text-[9px] text-[#18A879] mt-0.5">${(pt.cost / 1000).toFixed(0)}k</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Environmental Penalties Breakdown */}
          <div className="p-4 bg-white border border-[#B9DDF5] rounded-lg shadow-xs space-y-2 text-xs">
            <span className="font-bold text-[#063A6B] block">
              Hydrodynamic Resistance Breakdown
            </span>
            <div className="grid grid-cols-3 gap-3 pt-1">
              <div className="p-2.5 bg-[#EFF9FF] rounded border border-[#B9DDF5]/60">
                <span className="text-[#55738C] text-[10px] block">WEATHER RESISTANCE PENALTY</span>
                <span className="font-mono font-bold text-[#E84A5A] text-xs">
                  +{prediction.weatherFuelPenaltyPct}% extra power
                </span>
              </div>
              <div className="p-2.5 bg-[#EFF9FF] rounded border border-[#B9DDF5]/60">
                <span className="text-[#55738C] text-[10px] block">OCEAN CURRENT BENEFIT</span>
                <span className="font-mono font-bold text-[#18A879] text-xs">
                  +{prediction.currentBenefitKts} kts SOG gain
                </span>
              </div>
              <div className="p-2.5 bg-[#EFF9FF] rounded border border-[#B9DDF5]/60">
                <span className="text-[#55738C] text-[10px] block">SPECIFIC FUEL OIL CONSUMPTION</span>
                <span className="font-mono font-bold text-[#063A6B] text-xs">
                  {prediction.sfocGramsPerKwh} g / kWh
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
