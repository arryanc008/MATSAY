import React, { useState } from 'react';
import {
  Leaf,
  Ship,
  TrendingDown,
  DollarSign,
  Fuel,
  ShieldCheck,
  BarChart,
  Layers,
  ArrowRight
} from 'lucide-react';
import { useMaritime } from '../context/MaritimeContext';

export const SustainabilityPage: React.FC = () => {
  const { vessels, setCurrentPath } = useMaritime();

  const [selectedAltFuel, setSelectedAltFuel] = useState<'VLSFO' | 'LNG' | 'Methanol' | 'Ammonia' | 'Hydrogen'>('Methanol');

  const altFuelData = {
    VLSFO: {
      name: 'Very Low Sulphur Fuel Oil (0.50% S)',
      co2Factor: 3.114,
      costPerMt: 645,
      densityMjPerKg: 42.7,
      bunkerTonsRequired: 1000,
      totalCostUsd: 645000,
      totalCo2Tons: 3114,
      tankVolumeMultiplier: 1.0,
      maturity: 'Mature Legacy Standard'
    },
    LNG: {
      name: 'Liquefied Natural Gas (Methane)',
      co2Factor: 2.750,
      costPerMt: 580,
      densityMjPerKg: 49.2,
      bunkerTonsRequired: 868,
      totalCostUsd: 503440,
      totalCo2Tons: 2387,
      tankVolumeMultiplier: 1.8,
      maturity: 'Commercialized Transition Fuel'
    },
    Methanol: {
      name: 'E-Methanol / Bio-Methanol',
      co2Factor: 1.375,
      costPerMt: 710,
      densityMjPerKg: 19.9,
      bunkerTonsRequired: 2145,
      totalCostUsd: 1522950,
      totalCo2Tons: 2949, // Lifecycle Net zero when using captured CO2
      tankVolumeMultiplier: 2.2,
      maturity: 'Rapid Adoption (Dual-Fuel Engines)'
    },
    Ammonia: {
      name: 'Green Ammonia (NH₃)',
      co2Factor: 0.05,
      costPerMt: 950,
      densityMjPerKg: 18.6,
      bunkerTonsRequired: 2295,
      totalCostUsd: 2180250,
      totalCo2Tons: 114,
      tankVolumeMultiplier: 3.0,
      maturity: 'Pilots 2026+ (Toxicity safety mitigation)'
    },
    Hydrogen: {
      name: 'Liquid Cryogenic Hydrogen (LH₂)',
      co2Factor: 0.0,
      costPerMt: 2800,
      densityMjPerKg: 120.0,
      bunkerTonsRequired: 356,
      totalCostUsd: 996800,
      totalCo2Tons: 0,
      tankVolumeMultiplier: 4.5,
      maturity: 'R&D / Short-sea and coastal feeder only'
    }
  };

  const selectedFuel = altFuelData[selectedAltFuel];

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-[#063A6B] tracking-tight">
            Fleet Decarbonization & Alternative Fuels
          </h1>
          <p className="text-xs text-[#55738C] mt-0.5">
            IMO Carbon Intensity Indicator (CII), EU ETS allowances, and alternative fuel lifecycle trade-offs
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono font-bold text-[#18A879] bg-white border border-[#B9DDF5] px-2.5 py-1 rounded">
            IMO 2030 TARGET: -40% CARBON INTENSITY
          </span>
        </div>
      </div>

      {/* Top Decarbonization KPI Summary */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
        <div className="p-3 bg-white border border-[#B9DDF5] rounded-lg shadow-xs">
          <span className="text-[10px] uppercase font-bold text-[#55738C]">TOTAL FLEET CO₂ TODAY</span>
          <div className="text-xl font-extrabold font-mono text-[#063A6B] mt-0.5">2,018.6 t</div>
          <div className="text-[10px] text-[#18A879] mt-1 font-semibold">-174.2 t avoided with Q-Opt</div>
        </div>

        <div className="p-3 bg-white border border-[#B9DDF5] rounded-lg shadow-xs">
          <span className="text-[10px] uppercase font-bold text-[#55738C]">CII RATING BREAKDOWN</span>
          <div className="text-xl font-extrabold font-mono text-[#18A879] mt-0.5">CLASS A / B (88%)</div>
          <div className="text-[10px] text-[#55738C] mt-1">2 vessels in Class C Advisory</div>
        </div>

        <div className="p-3 bg-white border border-[#B9DDF5] rounded-lg shadow-xs">
          <span className="text-[10px] uppercase font-bold text-[#55738C]">EU ETS COMPLIANCE COST</span>
          <div className="text-xl font-extrabold font-mono text-[#063A6B] mt-0.5">$18,420 / day</div>
          <div className="text-[10px] text-[#55738C] mt-1">At €82 / EUA allowance metric</div>
        </div>

        <div className="p-3 bg-white border border-[#B9DDF5] rounded-lg shadow-xs">
          <span className="text-[10px] uppercase font-bold text-[#55738C]">ANNUAL FLEET FUEL SAVED</span>
          <div className="text-xl font-extrabold font-mono text-[#18A879] mt-0.5">17,450 MT</div>
          <div className="text-[10px] text-[#18A879] mt-1 font-semibold">~$11.2M bunker expenditure</div>
        </div>
      </div>

      {/* Alternative Fuel Matrix Comparator */}
      <div className="bg-white border border-[#B9DDF5] rounded-lg shadow-xs p-4 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-3 border-b border-[#EFF9FF] gap-2">
          <div>
            <h2 className="text-sm font-extrabold text-[#063A6B]">
              Alternative Maritime Fuel Scenario Simulator
            </h2>
            <p className="text-[11px] text-[#55738C]">
              Voyage normalized benchmark for 1,000 MT VLSFO equivalent energy duty cycle
            </p>
          </div>

          <div className="flex items-center gap-1 overflow-x-auto">
            {(['VLSFO', 'LNG', 'Methanol', 'Ammonia', 'Hydrogen'] as const).map((fuel) => (
              <button
                key={fuel}
                onClick={() => setSelectedAltFuel(fuel)}
                className={`px-3 py-1 text-xs font-bold rounded transition-colors ${
                  selectedAltFuel === fuel
                    ? 'bg-[#0879D1] text-white shadow-xs'
                    : 'bg-[#EFF9FF] text-[#063A6B] hover:bg-[#DDF3FF]'
                }`}
              >
                {fuel}
              </button>
            ))}
          </div>
        </div>

        {/* Selected Fuel Deep Dive */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 text-xs">
          <div className="p-3 bg-[#EFF9FF] rounded-md border border-[#B9DDF5] space-y-2">
            <span className="text-[10px] uppercase font-bold text-[#55738C]">Fuel Chemistry & Status</span>
            <div className="text-base font-extrabold text-[#063A6B]">{selectedFuel.name}</div>
            <div className="text-[11px] text-[#0879D1] font-bold">{selectedFuel.maturity}</div>
            <div className="text-[11px] text-[#55738C] pt-2 border-t border-[#B9DDF5]/40 font-mono">
              Energy Density: {selectedFuel.densityMjPerKg} MJ/kg
            </div>
          </div>

          <div className="p-3 bg-white rounded-md border border-[#B9DDF5] space-y-2 font-mono">
            <span className="text-[10px] uppercase font-bold text-[#55738C] font-sans">
              Voyage Bunker & Economics
            </span>
            <div className="flex justify-between">
              <span className="text-[#55738C]">Bunker Required:</span>
              <span className="font-bold text-[#063A6B]">{selectedFuel.bunkerTonsRequired} MT</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#55738C]">Benchmark Price:</span>
              <span className="font-bold text-[#063A6B]">${selectedFuel.costPerMt} / MT</span>
            </div>
            <div className="flex justify-between pt-1 border-t border-[#EFF9FF]">
              <span className="text-[#55738C]">Total Fuel Expense:</span>
              <span className="font-bold text-[#0879D1]">${selectedFuel.totalCostUsd.toLocaleString()}</span>
            </div>
          </div>

          <div className="p-3 bg-white rounded-md border border-[#B9DDF5] space-y-2 font-mono">
            <span className="text-[10px] uppercase font-bold text-[#55738C] font-sans">
              Decarbonization & Tankage
            </span>
            <div className="flex justify-between">
              <span className="text-[#55738C]">Direct CO₂ Factor:</span>
              <span className="font-bold text-[#18A879]">{selectedFuel.co2Factor} t CO₂/t</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#55738C]">Net Voyage GHG:</span>
              <span className="font-bold text-[#18A879]">{selectedFuel.totalCo2Tons} t CO₂</span>
            </div>
            <div className="flex justify-between pt-1 border-t border-[#EFF9FF]">
              <span className="text-[#55738C]">Tank Volume Space:</span>
              <span className="font-bold text-[#063A6B]">{selectedFuel.tankVolumeMultiplier}x VLSFO</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
