import React, { useState } from 'react';
import {
  Sparkles,
  Sliders,
  Play,
  RotateCcw,
  CheckCircle2,
  TrendingDown,
  ArrowRight,
  ShieldCheck,
  Zap,
  BarChart2,
  Compass,
  Ship,
  Clock,
  Layers,
  ChevronRight
} from 'lucide-react';
import { useMaritime } from '../context/MaritimeContext';
import { getAlgorithmBenchmarks } from '../services/optimizationEngine';
import { HumanInTheLoopModal } from '../components/common/HumanInTheLoopModal';
import { ParetoSolution } from '../types/maritime';

export const OptimizationPage: React.FC = () => {
  const {
    optimizationWeights,
    setOptimizationWeights,
    optimizationConstraints,
    setOptimizationConstraints,
    isOptimizing,
    optimizationProgress,
    optimizationResult,
    executeOptimization,
    setCurrentPath
  } = useMaritime();

  const [selectedSolutionId, setSelectedSolutionId] = useState<string>('sol-balanced');
  const [selectedRecForModal, setSelectedRecForModal] = useState<any | null>(null);

  const benchmarks = getAlgorithmBenchmarks();

  const activeSolution =
    optimizationResult?.paretoFront.find((s) => s.id === selectedSolutionId) ||
    optimizationResult?.paretoFront[1];

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-black text-[#063A6B] tracking-tight">
              MATSAY OPTIMIZER
            </h1>
            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-[#18A879]/10 text-[#18A879] border border-[#18A879]/20">
              Quantum-Inspired Core
            </span>
          </div>
          <p className="text-xs text-[#55738C] mt-0.5">
            Multi-objective fleet voyage optimization, weather avoidance, and speed-schedule equilibrium
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setCurrentPath('/command-center')}
            className="px-3 py-1.5 bg-white border border-[#B9DDF5] text-xs font-semibold text-[#063A6B] rounded-md hover:bg-[#EFF9FF] transition-colors"
          >
            Command Center
          </button>
          <button
            onClick={() => executeOptimization()}
            disabled={isOptimizing}
            className="flex items-center gap-1.5 px-4 py-1.5 bg-[#0879D1] hover:bg-[#062B52] text-white text-xs font-extrabold uppercase tracking-wider rounded-md transition-colors shadow-xs disabled:opacity-50"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>{isOptimizing ? 'SEARCHING CORRIDORS...' : 'RUN FLEET OPTIMIZATION'}</span>
          </button>
        </div>
      </div>

      {/* Human in the loop review modal */}
      {selectedRecForModal && (
        <HumanInTheLoopModal
          recommendation={selectedRecForModal}
          onClose={() => setSelectedRecForModal(null)}
        />
      )}

      {/* Technical Multi-Phase Progress Bar during execution */}
      {isOptimizing && optimizationProgress && (
        <div className="p-4 bg-white border border-[#B9DDF5] rounded-lg shadow-md space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-[#063A6B]">
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-[#0879D1] animate-bounce" />
              <span>OPTIMIZATION PHASE: {optimizationProgress.phase}</span>
            </div>
            <span className="font-mono text-[#0879D1]">{optimizationProgress.progressPct}%</span>
          </div>
          <div className="w-full bg-[#EFF9FF] h-2 rounded-full overflow-hidden border border-[#B9DDF5]">
            <div
              className="bg-[#0879D1] h-full transition-all duration-300 rounded-full"
              style={{ width: `${optimizationProgress.progressPct}%` }}
            />
          </div>
          <p className="text-[11px] text-[#55738C] font-mono">{optimizationProgress.details}</p>
        </div>
      )}

      {/* Top Configuration Grid: Objectives & Constraints */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* Objectives & Weights Sliders (7 cols) */}
        <div className="lg:col-span-7 bg-white border border-[#B9DDF5] rounded-lg shadow-xs p-4 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#EFF9FF]">
            <div className="flex items-center gap-2">
              <Sliders className="w-4 h-4 text-[#0879D1]" />
              <span className="text-xs font-bold text-[#063A6B]">Objective Priority Weights</span>
            </div>
            <span className="text-[10px] text-[#55738C]">Adjust trade-off balance</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div>
              <div className="flex justify-between mb-1">
                <span className="font-bold text-[#063A6B]">Minimize Bunker Fuel</span>
                <span className="font-mono text-[#0879D1] font-bold">{optimizationWeights.fuel}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={optimizationWeights.fuel}
                onChange={(e) =>
                  setOptimizationWeights({ ...optimizationWeights, fuel: Number(e.target.value) })
                }
                className="w-full accent-[#0879D1]"
              />
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="font-bold text-[#063A6B]">Minimize Voyage Cost</span>
                <span className="font-mono text-[#0879D1] font-bold">{optimizationWeights.cost}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={optimizationWeights.cost}
                onChange={(e) =>
                  setOptimizationWeights({ ...optimizationWeights, cost: Number(e.target.value) })
                }
                className="w-full accent-[#0879D1]"
              />
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="font-bold text-[#063A6B]">Minimize CO₂ Emissions</span>
                <span className="font-mono text-[#18A879] font-bold">{optimizationWeights.co2}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={optimizationWeights.co2}
                onChange={(e) =>
                  setOptimizationWeights({ ...optimizationWeights, co2: Number(e.target.value) })
                }
                className="w-full accent-[#18A879]"
              />
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="font-bold text-[#063A6B]">Minimize Delivery Time</span>
                <span className="font-mono text-[#0879D1] font-bold">{optimizationWeights.time}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={optimizationWeights.time}
                onChange={(e) =>
                  setOptimizationWeights({ ...optimizationWeights, time: Number(e.target.value) })
                }
                className="w-full accent-[#0879D1]"
              />
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="font-bold text-[#063A6B]">Maximize Schedule Reliability</span>
                <span className="font-mono text-[#0879D1] font-bold">{optimizationWeights.reliability}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={optimizationWeights.reliability}
                onChange={(e) =>
                  setOptimizationWeights({
                    ...optimizationWeights,
                    reliability: Number(e.target.value)
                  })
                }
                className="w-full accent-[#0879D1]"
              />
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="font-bold text-[#063A6B]">Maximize Fleet Utilization</span>
                <span className="font-mono text-[#0879D1] font-bold">{optimizationWeights.utilization}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={optimizationWeights.utilization}
                onChange={(e) =>
                  setOptimizationWeights({
                    ...optimizationWeights,
                    utilization: Number(e.target.value)
                  })
                }
                className="w-full accent-[#0879D1]"
              />
            </div>
          </div>
        </div>

        {/* Operational Constraints (5 cols) */}
        <div className="lg:col-span-5 bg-white border border-[#B9DDF5] rounded-lg shadow-xs p-4 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#EFF9FF]">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#18A879]" />
              <span className="text-xs font-bold text-[#063A6B]">Hard & Soft Constraints</span>
            </div>
            <span className="text-[10px] text-[#55738C]">Maritime regulations</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            <label className="flex items-center gap-2 cursor-pointer p-1.5 rounded hover:bg-[#EFF9FF]">
              <input
                type="checkbox"
                checked={optimizationConstraints.vesselCapacity}
                onChange={(e) =>
                  setOptimizationConstraints({
                    ...optimizationConstraints,
                    vesselCapacity: e.target.checked
                  })
                }
                className="rounded border-[#B9DDF5] text-[#0879D1] focus:ring-0"
              />
              <span className="text-[#063A6B]">Vessel Deadweight / Draft</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer p-1.5 rounded hover:bg-[#EFF9FF]">
              <input
                type="checkbox"
                checked={optimizationConstraints.deliveryDeadline}
                onChange={(e) =>
                  setOptimizationConstraints({
                    ...optimizationConstraints,
                    deliveryDeadline: e.target.checked
                  })
                }
                className="rounded border-[#B9DDF5] text-[#0879D1] focus:ring-0"
              />
              <span className="text-[#063A6B]">Strict Delivery ETA Window</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer p-1.5 rounded hover:bg-[#EFF9FF]">
              <input
                type="checkbox"
                checked={optimizationConstraints.routeRestrictions}
                onChange={(e) =>
                  setOptimizationConstraints({
                    ...optimizationConstraints,
                    routeRestrictions: e.target.checked
                  })
                }
                className="rounded border-[#B9DDF5] text-[#0879D1] focus:ring-0"
              />
              <span className="text-[#063A6B]">TSS & HRA Corridors</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer p-1.5 rounded hover:bg-[#EFF9FF]">
              <input
                type="checkbox"
                checked={optimizationConstraints.emissionLimits}
                onChange={(e) =>
                  setOptimizationConstraints({
                    ...optimizationConstraints,
                    emissionLimits: e.target.checked
                  })
                }
                className="rounded border-[#B9DDF5] text-[#0879D1] focus:ring-0"
              />
              <span className="text-[#063A6B]">ECA 0.10% Sulphur Limits</span>
            </label>
          </div>

          <div className="pt-2 border-t border-[#EFF9FF] text-xs">
            <div className="flex justify-between mb-1">
              <span className="text-[#55738C] font-semibold">Weather Risk Threshold (Beaufort scale)</span>
              <span className="font-mono font-bold text-[#063A6B]">Level {optimizationConstraints.weatherRiskThreshold} (Gale avoidance)</span>
            </div>
            <input
              type="range"
              min="1"
              max="5"
              value={optimizationConstraints.weatherRiskThreshold}
              onChange={(e) =>
                setOptimizationConstraints({
                  ...optimizationConstraints,
                  weatherRiskThreshold: Number(e.target.value)
                })
              }
              className="w-full accent-[#0879D1]"
            />
          </div>
        </div>
      </div>

      {/* Plan Comparison: CURRENT PLAN vs OPTIMIZED PLAN */}
      {optimizationResult && (
        <div className="bg-white border border-[#B9DDF5] rounded-lg shadow-xs p-4 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1 pb-3 border-b border-[#EFF9FF]">
            <div>
              <h2 className="text-sm font-extrabold text-[#063A6B]">
                CURRENT FLEET BASELINE vs QUANTUM-OPTIMIZED FLEET PLAN
              </h2>
              <p className="text-[11px] text-[#55738C]">
                Calculated across {optimizationResult.convergenceIterations} iterations in{' '}
                {optimizationResult.executionTimeMs} ms · Standard Error &lt; 10⁻⁵
              </p>
            </div>
            <span className="text-xs font-mono font-bold text-[#0879D1] bg-[#EFF9FF] px-2.5 py-1 rounded border border-[#B9DDF5]">
              RUN ID: {optimizationResult.runId}
            </span>
          </div>

          {/* Metric Deltas Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
            <div className="p-3 bg-[#EFF9FF] rounded-md border border-[#B9DDF5]">
              <span className="text-[10px] uppercase font-bold text-[#55738C]">Bunker Fuel</span>
              <div className="text-base font-extrabold font-mono text-[#063A6B] mt-0.5">
                {optimizationResult.optimizedPlan.totalFuelMt} MT
              </div>
              <div className="text-[11px] font-bold text-[#18A879] mt-0.5">
                {optimizationResult.delta.fuelPct}% ({optimizationResult.currentPlan.totalFuelMt} MT base)
              </div>
            </div>

            <div className="p-3 bg-[#EFF9FF] rounded-md border border-[#B9DDF5]">
              <span className="text-[10px] uppercase font-bold text-[#55738C]">Bunker Cost</span>
              <div className="text-base font-extrabold font-mono text-[#063A6B] mt-0.5">
                ${(optimizationResult.optimizedPlan.totalCostUsd / 1000).toFixed(1)}k
              </div>
              <div className="text-[11px] font-bold text-[#18A879] mt-0.5">
                {optimizationResult.delta.costPct}% saved
              </div>
            </div>

            <div className="p-3 bg-[#EFF9FF] rounded-md border border-[#B9DDF5]">
              <span className="text-[10px] uppercase font-bold text-[#55738C]">CO₂ Emissions</span>
              <div className="text-base font-extrabold font-mono text-[#063A6B] mt-0.5">
                {optimizationResult.optimizedPlan.totalCo2Tons} t
              </div>
              <div className="text-[11px] font-bold text-[#18A879] mt-0.5">
                {optimizationResult.delta.co2Pct}% reduction
              </div>
            </div>

            <div className="p-3 bg-[#EFF9FF] rounded-md border border-[#B9DDF5]">
              <span className="text-[10px] uppercase font-bold text-[#55738C]">Avg Transit Time</span>
              <div className="text-base font-extrabold font-mono text-[#063A6B] mt-0.5">
                {optimizationResult.optimizedPlan.averageEtaHours.toFixed(1)} hrs
              </div>
              <div className="text-[11px] text-[#55738C] mt-0.5 font-mono">
                {optimizationResult.delta.timePct > 0 ? '+' : ''}
                {optimizationResult.delta.timePct}% delta
              </div>
            </div>

            <div className="p-3 bg-[#EFF9FF] rounded-md border border-[#B9DDF5]">
              <span className="text-[10px] uppercase font-bold text-[#55738C]">Schedule Reliability</span>
              <div className="text-base font-extrabold font-mono text-[#18A879] mt-0.5">
                {optimizationResult.optimizedPlan.scheduleReliabilityPct}%
              </div>
              <div className="text-[11px] font-bold text-[#18A879] mt-0.5">
                +{optimizationResult.delta.reliabilityPct}% confidence
              </div>
            </div>

            <div className="p-3 bg-[#EFF9FF] rounded-md border border-[#B9DDF5]">
              <span className="text-[10px] uppercase font-bold text-[#55738C]">Fleet Utilization</span>
              <div className="text-base font-extrabold font-mono text-[#0879D1] mt-0.5">
                {optimizationResult.optimizedPlan.fleetUtilizationPct}%
              </div>
              <div className="text-[11px] font-bold text-[#0879D1] mt-0.5">
                +{optimizationResult.delta.utilizationPct}% cargo factor
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2D Pareto Front Interactive Selector & Benchmarks */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* Pareto Front Candidates (7 cols) */}
        <div className="lg:col-span-7 bg-white border border-[#B9DDF5] rounded-lg shadow-xs p-4 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#EFF9FF]">
            <div className="flex items-center gap-2">
              <Compass className="w-4 h-4 text-[#0879D1]" />
              <span className="text-xs font-bold text-[#063A6B]">
                Multi-Objective Pareto Optimal Solutions
              </span>
            </div>
            <span className="text-[10px] text-[#55738C]">Click candidate to activate</span>
          </div>

          <div className="space-y-2 text-xs">
            {optimizationResult?.paretoFront.map((sol) => {
              const isSelected = selectedSolutionId === sol.id;
              return (
                <div
                  key={sol.id}
                  onClick={() => setSelectedSolutionId(sol.id)}
                  className={`p-3 rounded-md border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-[#EFF9FF] border-[#0879D1] shadow-xs'
                      : 'bg-white border-[#B9DDF5] hover:bg-[#F4FBFF]'
                  }`}
                >
                  <div className="flex items-center justify-between font-bold">
                    <span className="text-[#063A6B]">{sol.label}</span>
                    <span className="text-[10px] font-mono text-[#0879D1] bg-white px-2 py-0.5 rounded border border-[#B9DDF5]">
                      Q-FITNESS: {sol.quantumFitnessScore}
                    </span>
                  </div>
                  <div className="grid grid-cols-4 gap-2 text-[11px] mt-2 font-mono">
                    <div>
                      <span className="text-[#55738C] block text-[9px]">FUEL</span>
                      <span className="font-bold text-[#063A6B]">{sol.fuelMt} MT</span>
                    </div>
                    <div>
                      <span className="text-[#55738C] block text-[9px]">COST</span>
                      <span className="font-bold text-[#063A6B]">${(sol.costUsd / 1000).toFixed(0)}k</span>
                    </div>
                    <div>
                      <span className="text-[#55738C] block text-[9px]">CO₂</span>
                      <span className="font-bold text-[#18A879]">{sol.co2Tons} t</span>
                    </div>
                    <div>
                      <span className="text-[#55738C] block text-[9px]">RELIABILITY</span>
                      <span className="font-bold text-[#0879D1]">{sol.scheduleReliabilityPct}%</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Algorithm Benchmarks Comparison (5 cols) */}
        <div className="lg:col-span-5 bg-white border border-[#B9DDF5] rounded-lg shadow-xs p-4 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#EFF9FF]">
            <div className="flex items-center gap-2">
              <BarChart2 className="w-4 h-4 text-[#0879D1]" />
              <span className="text-xs font-bold text-[#063A6B]">
                Optimization Algorithm Benchmarks
              </span>
            </div>
            <span className="text-[10px] text-[#55738C]">Empirical run data</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#EFF9FF] text-[#55738C] text-[9px] uppercase font-bold">
                <tr>
                  <th className="py-2 px-2">Algorithm</th>
                  <th className="py-2 px-1.5">Runtime</th>
                  <th className="py-2 px-1.5">Iterations</th>
                  <th className="py-2 px-1.5">Fuel Δ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#EFF9FF] text-[11px]">
                {benchmarks.map((b, i) => (
                  <tr key={i} className={i === 0 ? 'bg-[#EFF9FF]/40 font-bold' : ''}>
                    <td className="py-2.5 px-2 text-[#063A6B]">
                      {b.algorithm}
                      {i === 0 && <span className="text-[9px] text-[#18A879] block">Recommended</span>}
                    </td>
                    <td className="py-2.5 px-1.5 font-mono text-[#063A6B]">{b.runtimeMs} ms</td>
                    <td className="py-2.5 px-1.5 font-mono text-[#55738C]">{b.iterationsToConverge}</td>
                    <td className="py-2.5 px-1.5 font-mono text-[#18A879]">-{b.fuelReductionPct}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="text-[10px] text-[#55738C] leading-relaxed pt-1">
            * Quantum-Inspired PSO utilizes Q-bit rotation states for multi-dimensional search space
            exploration without premature convergence.
          </p>
        </div>
      </div>

      {/* Generated Actionable Recommendations (Human in the Loop) */}
      <div className="bg-white border border-[#B9DDF5] rounded-lg shadow-xs p-4 space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-[#EFF9FF]">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#18A879]" />
            <span className="text-xs font-bold text-[#063A6B]">
              Actionable Operational Directives ({optimizationResult?.recommendations.length || 0})
            </span>
          </div>
          <span className="text-[10px] text-[#55738C]">Commander review required prior to dispatch</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {optimizationResult?.recommendations.map((rec) => (
            <div
              key={rec.id}
              className="p-3 bg-[#EFF9FF]/60 border border-[#B9DDF5] rounded-md flex flex-col justify-between space-y-2 text-xs"
            >
              <div>
                <div className="flex items-center justify-between font-bold text-[#063A6B]">
                  <span>{rec.vesselName}</span>
                  <span
                    className={`text-[9px] px-1.5 py-0.5 rounded font-bold ${
                      rec.status === 'APPROVED'
                        ? 'bg-[#18A879]/20 text-[#18A879]'
                        : rec.status === 'REJECTED'
                        ? 'bg-[#E84A5A]/20 text-[#E84A5A]'
                        : 'bg-[#0879D1]/20 text-[#0879D1]'
                    }`}
                  >
                    {rec.status}
                  </span>
                </div>
                <p className="text-[11px] font-semibold text-[#063A6B] mt-1">{rec.action}</p>
                <p className="text-[10px] text-[#55738C] mt-1 leading-relaxed">{rec.reason}</p>

                <div className="mt-2 pt-2 border-t border-[#B9DDF5]/60 space-y-1 text-[10px] text-[#063A6B]">
                  <div className="font-bold text-[9px] uppercase tracking-wider text-[#55738C]">
                    Why This Route? (OPTIMIZATION)
                  </div>
                  <div className="flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3 text-[#18A879] shrink-0" />
                    <span>Lower headwind &amp; wave resistance</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3 text-[#18A879] shrink-0" />
                    <span>Captures favorable ocean current vector</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3 text-[#18A879] shrink-0" />
                    <span>Avoids restricted &amp; high-risk zones</span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[10px] font-mono font-bold text-[#18A879] mt-2 pt-1.5 border-t border-[#B9DDF5]/40">
                  <span>{rec.expectedImpact}</span>
                  <span className="text-[#0879D1]">Confidence: {rec.modelConfidencePct}%</span>
                </div>
              </div>

              <button
                onClick={() => setSelectedRecForModal(rec)}
                className="w-full py-1.5 px-2 bg-white hover:bg-[#0879D1] hover:text-white text-[#063A6B] border border-[#B9DDF5] rounded text-[11px] font-bold transition-colors shadow-xs"
              >
                Review & Authorize
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
