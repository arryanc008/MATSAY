import React, { useState } from 'react';
import {
  Filter,
  Layers,
  Ship,
  Compass,
  Search,
  Navigation,
  Sparkles,
  ArrowRight,
  ShieldAlert,
  Gauge
} from 'lucide-react';
import { useMaritime } from '../context/MaritimeContext';
import { FleetGISMap } from '../components/map/FleetGISMap';
import { Vessel, VesselType, RiskLevel } from '../types/maritime';

export const FleetMapPage: React.FC = () => {
  const {
    vessels,
    activeVessel,
    activeVesselId,
    setActiveVesselId,
    setMapFocusTarget,
    setCurrentPath
  } = useMaritime();

  const [filterType, setFilterType] = useState<string>('ALL');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [filterRisk, setFilterRisk] = useState<string>('ALL');

  const filteredVessels = vessels.filter((v) => {
    if (filterType !== 'ALL' && v.type !== filterType) return false;
    if (filterStatus !== 'ALL' && v.status !== filterStatus) return false;
    if (filterRisk !== 'ALL' && v.scheduleStatus !== filterRisk) return false;
    return true;
  });

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-[#063A6B] tracking-tight">
            Fleet GIS Map Operations
          </h1>
          <p className="text-xs text-[#55738C] mt-0.5">
            Full-theatre geospatial tracking with real-time AIS, nautical charting, and quantum routing corridors
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setCurrentPath('/command-center')}
            className="px-3 py-1.5 bg-white border border-[#B9DDF5] text-xs font-semibold text-[#063A6B] rounded-md hover:bg-[#EFF9FF] transition-colors"
          >
            Back to Command Center
          </button>
          <button
            onClick={() => setCurrentPath('/routes')}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#0879D1] text-white text-xs font-bold rounded-md hover:bg-[#062B52] transition-colors shadow-xs"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Route Optimization Studio</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Dedicated Large GIS Map + Filter / Vessel Selection Drawer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* Expanded GIS Map (9 cols) */}
        <div className="lg:col-span-9 relative">
          <FleetGISMap heightClass="h-[380px] sm:h-[480px] md:h-[580px] lg:h-[680px]" showLayerToggleOverlay={true} />
        </div>

        {/* Right Filtering & Vessel Quick Select Panel (3 cols) */}
        <div className="lg:col-span-3 bg-white border border-[#B9DDF5] rounded-lg shadow-xs p-4 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-[#EFF9FF]">
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-[#0879D1]" />
              <span className="text-xs font-bold text-[#063A6B]">Fleet Geographic Filters</span>
            </div>
            <span className="text-[10px] font-mono text-[#55738C]">
              {filteredVessels.length} / {vessels.length} Shown
            </span>
          </div>

          {/* Filter Selectors */}
          <div className="space-y-2.5 text-xs">
            <div>
              <label className="text-[10px] uppercase font-bold text-[#55738C] block mb-1">
                Vessel Classification
              </label>
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value)}
                className="w-full text-xs p-1.5 bg-[#EFF9FF] border border-[#B9DDF5] rounded text-[#063A6B] focus:outline-none"
              >
                <option value="ALL">All Classifications</option>
                <option value="Container">Container Carriers</option>
                <option value="Tanker">Crude & Product Tankers</option>
                <option value="Bulk Carrier">Bulk Carriers</option>
                <option value="LNG">LNG Carriers</option>
                <option value="Cargo">General Cargo</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] uppercase font-bold text-[#55738C] block mb-1">
                Operational Status
              </label>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="w-full text-xs p-1.5 bg-[#EFF9FF] border border-[#B9DDF5] rounded text-[#063A6B] focus:outline-none"
              >
                <option value="ALL">All States</option>
                <option value="IN TRANSIT">In Transit Underway</option>
                <option value="AT ANCHOR">At Anchorage</option>
                <option value="MOORED">Moored / Berthed</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] uppercase font-bold text-[#55738C] block mb-1">
                Schedule Risk Profile
              </label>
              <select
                value={filterRisk}
                onChange={(e) => setFilterRisk(e.target.value)}
                className="w-full text-xs p-1.5 bg-[#EFF9FF] border border-[#B9DDF5] rounded text-[#063A6B] focus:outline-none"
              >
                <option value="ALL">All Risk Levels</option>
                <option value="On Schedule">On Schedule (Nominal)</option>
                <option value="Warning">Warning (Advisory)</option>
                <option value="Critical">Critical (Severe Weather / Delay)</option>
              </select>
            </div>
          </div>

          {/* Quick Vessels List in viewport */}
          <div className="space-y-2 pt-2 border-t border-[#EFF9FF]">
            <span className="text-[10px] uppercase font-bold text-[#55738C] block">
              Fleet Units in Viewport
            </span>

            <div className="max-h-80 overflow-y-auto space-y-1.5 pr-1">
              {filteredVessels.map((v) => {
                const isSelected = v.id === activeVesselId;
                return (
                  <div
                    key={v.id}
                    onClick={() => {
                      setActiveVesselId(v.id);
                      setMapFocusTarget({ lat: v.position.lat, lng: v.position.lng, zoom: 8 });
                    }}
                    className={`p-2.5 rounded border text-xs cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-[#EFF9FF] border-[#0879D1] shadow-xs'
                        : 'bg-white border-[#B9DDF5] hover:bg-[#F4FBFF]'
                    }`}
                  >
                    <div className="flex items-center justify-between font-bold text-[#063A6B]">
                      <span>{v.name}</span>
                      <span className="text-[10px] font-mono text-[#0879D1]">{v.speedKts} kts</span>
                    </div>
                    <div className="text-[10px] text-[#55738C] flex items-center justify-between mt-1">
                      <span>{v.type} · IMO {v.imo}</span>
                      <span
                        className={`font-semibold ${
                          v.scheduleStatus === 'Critical'
                            ? 'text-[#E84A5A]'
                            : v.scheduleStatus === 'Warning'
                            ? 'text-[#F3A712]'
                            : 'text-[#18A879]'
                        }`}
                      >
                        {v.scheduleStatus}
                      </span>
                    </div>
                    <div className="text-[10px] text-[#063A6B]/80 font-mono mt-1 truncate">
                      → {v.destination}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
