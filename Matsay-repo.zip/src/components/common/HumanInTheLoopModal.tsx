import React, { useState } from 'react';
import {
  CheckCircle,
  XCircle,
  Edit3,
  ShieldCheck,
  AlertCircle,
  FileCheck2,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { useMaritime } from '../../context/MaritimeContext';

interface HumanInTheLoopProps {
  recommendation: {
    id: string;
    vesselId: string;
    vesselName: string;
    action: string;
    reason: string;
    expectedImpact: string;
    modelConfidencePct: number;
    status: 'PENDING' | 'APPROVED' | 'MODIFIED' | 'REJECTED';
  };
  onClose?: () => void;
}

export const HumanInTheLoopModal: React.FC<HumanInTheLoopProps> = ({ recommendation, onClose }) => {
  const { handleCommanderDecision, session } = useMaritime();
  const [isModifying, setIsModifying] = useState(false);
  const [modificationNotes, setModificationNotes] = useState('');
  const [actionDone, setActionDone] = useState<string | null>(null);

  const onApprove = () => {
    handleCommanderDecision(recommendation.id, 'APPROVED', 'Commander authorized directive without alteration.');
    setActionDone('APPROVED');
    setTimeout(() => onClose?.(), 1200);
  };

  const onReject = () => {
    handleCommanderDecision(
      recommendation.id,
      'REJECTED',
      modificationNotes || 'Rejected by Commander due to navigational / commercial discretion.'
    );
    setActionDone('REJECTED');
    setTimeout(() => onClose?.(), 1200);
  };

  const onConfirmModify = () => {
    handleCommanderDecision(
      recommendation.id,
      'MODIFIED',
      `Modified by Commander: ${modificationNotes}`
    );
    setActionDone('MODIFIED');
    setTimeout(() => onClose?.(), 1200);
  };

  return (
    <div className="bg-white border border-[#B9DDF5] rounded-lg shadow-md p-4 relative overflow-hidden">
      {/* Top Banner */}
      <div className="flex items-center justify-between pb-3 border-b border-[#EFF9FF] mb-3">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-md bg-[#EFF9FF] border border-[#B9DDF5] flex items-center justify-center text-[#0879D1]">
            <ShieldCheck className="w-4 h-4 text-[#0879D1]" />
          </div>
          <div>
            <div className="text-xs font-bold text-[#063A6B]">
              HUMAN-IN-THE-LOOP COMMAND GATE
            </div>
            <div className="text-[10px] text-[#55738C]">
              Autonomous steering prohibited. Commander sign-off required.
            </div>
          </div>
        </div>
        <div className="text-right">
          <span className="text-[10px] font-mono text-[#0879D1] bg-[#EFF9FF] px-2 py-0.5 rounded border border-[#B9DDF5]">
            CONFIDENCE: {recommendation.modelConfidencePct}%
          </span>
        </div>
      </div>

      {actionDone ? (
        <div className="p-4 bg-[#EFF9FF] rounded-md text-center space-y-1">
          <CheckCircle className="w-6 h-6 text-[#18A879] mx-auto" />
          <div className="text-xs font-bold text-[#063A6B]">Command Order {actionDone}</div>
          <p className="text-[11px] text-[#55738C]">
            Logged to Admiralty Audit Log and transmitted to {recommendation.vesselName} Master.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {/* Target Vessel & Action */}
          <div className="p-3 bg-[#F4FBFF] rounded-md border border-[#B9DDF5]/80">
            <div className="text-[10px] uppercase font-bold text-[#55738C]">Target Vessel</div>
            <div className="text-xs font-extrabold text-[#063A6B]">{recommendation.vesselName}</div>
            <div className="text-[11px] text-[#063A6B] font-semibold mt-1">
              Directive: {recommendation.action}
            </div>
          </div>

          {/* Rationale & Expected Impact */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            <div className="p-2.5 bg-white border border-[#B9DDF5] rounded">
              <span className="text-[10px] uppercase font-bold text-[#55738C]">Operational Rationale</span>
              <p className="text-[11px] text-[#063A6B] mt-0.5 leading-relaxed">{recommendation.reason}</p>
            </div>
            <div className="p-2.5 bg-white border border-[#B9DDF5] rounded">
              <span className="text-[10px] uppercase font-bold text-[#18A879]">Expected Impact</span>
              <p className="text-[11px] text-[#063A6B] mt-0.5 leading-relaxed font-mono">
                {recommendation.expectedImpact}
              </p>
            </div>
          </div>

          {/* Modification Text Input */}
          {isModifying && (
            <div className="space-y-1.5 pt-1">
              <label className="text-[10px] font-bold text-[#55738C] uppercase">
                Commander Modification Directives / Constraints
              </label>
              <textarea
                value={modificationNotes}
                onChange={(e) => setModificationNotes(e.target.value)}
                placeholder="Specify revised waypoints, maximum RPM limit, or conditional weather abort thresholds..."
                rows={2}
                className="w-full text-xs p-2 border border-[#B9DDF5] rounded focus:outline-none focus:border-[#0879D1] text-[#063A6B]"
              />
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-end gap-2 pt-2 border-t border-[#EFF9FF]">
            {isModifying ? (
              <>
                <button
                  onClick={() => setIsModifying(false)}
                  className="px-3 py-2 text-xs text-[#55738C] hover:bg-[#EFF9FF] rounded transition-colors text-center"
                >
                  Cancel
                </button>
                <button
                  onClick={onConfirmModify}
                  disabled={!modificationNotes.trim()}
                  className="px-4 py-2 text-xs font-bold bg-[#0879D1] text-white rounded hover:bg-[#062B52] disabled:opacity-50 transition-colors shadow-xs text-center"
                >
                  Authorize Modified Order
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={onReject}
                  className="px-3 py-2 text-xs font-semibold text-[#E84A5A] hover:bg-[#E84A5A]/10 border border-[#E84A5A]/30 rounded transition-colors text-center"
                >
                  Reject Directive
                </button>
                <button
                  onClick={() => setIsModifying(true)}
                  className="px-3 py-2 text-xs font-semibold text-[#063A6B] hover:bg-[#EFF9FF] border border-[#B9DDF5] rounded transition-colors flex items-center justify-center gap-1"
                >
                  <Edit3 className="w-3.5 h-3.5 text-[#55738C]" />
                  <span>Modify</span>
                </button>
                <button
                  onClick={onApprove}
                  className="px-4 py-2 text-xs font-bold bg-[#18A879] text-white hover:bg-[#138560] rounded transition-colors shadow-xs flex items-center justify-center gap-1.5"
                >
                  <CheckCircle className="w-3.5 h-3.5" />
                  <span>Approve & Transmit Order</span>
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
