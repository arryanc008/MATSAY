import React from 'react';
import {
  LayoutDashboard,
  MapPin,
  Ship,
  GitFork,
  Bot,
  Bell
} from 'lucide-react';
import { useMaritime } from '../../context/MaritimeContext';

export const BottomNav: React.FC = () => {
  const { currentPath, setCurrentPath, setIsMobileOpsOpen, alerts } = useMaritime();

  const unreadAlerts = alerts.filter((a) => !a.acknowledged && a.category === 'Critical').length;

  const items = [
    {
      id: 'command-center',
      label: 'Command',
      path: '/command-center',
      icon: LayoutDashboard
    },
    {
      id: 'map',
      label: 'GIS Map',
      path: '/map',
      icon: MapPin
    },
    {
      id: 'vessels',
      label: 'Fleet',
      path: '/vessels',
      icon: Ship
    },
    {
      id: 'routes',
      label: 'Routes',
      path: '/routes',
      icon: GitFork
    },
    {
      id: 'ops',
      label: 'AI Ops',
      path: '/ops',
      icon: Bot,
      isSpecial: true
    }
  ];

  return (
    <nav
      aria-label="Mobile Navigation"
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#062B52] border-t border-[#0A3D6B] shadow-2xl flex items-center justify-around px-1 h-14 select-none safe-bottom"
    >
      {items.map((item) => {
        const Icon = item.icon;
        const isActive = currentPath === item.path;

        return (
          <button
            key={item.id}
            onClick={() => {
              if (item.isSpecial) {
                // If on mobile, open mobile ops modal or go to /ops
                setCurrentPath(item.path);
              } else {
                setCurrentPath(item.path);
              }
            }}
            className={`flex-1 flex flex-col items-center justify-center py-1 px-1 rounded-md transition-all active:scale-95 ${
              isActive
                ? 'text-white'
                : 'text-[#B9DDF5]/70 hover:text-white'
            }`}
          >
            <div className="relative">
              <div
                className={`p-1 rounded-md transition-colors ${
                  isActive
                    ? item.isSpecial
                      ? 'bg-[#18A879] text-white shadow-xs'
                      : 'bg-[#0879D1] text-white shadow-xs'
                    : ''
                }`}
              >
                <Icon className="w-4 h-4" />
              </div>
              {item.id === 'alerts' && unreadAlerts > 0 && (
                <span className="absolute -top-1 -right-1 w-2 h-2 bg-[#E84A5A] rounded-full ring-2 ring-[#062B52]" />
              )}
            </div>
            <span
              className={`text-[9px] mt-0.5 tracking-tight font-medium ${
                isActive ? 'text-white font-bold' : 'text-[#B9DDF5]/70'
              }`}
            >
              {item.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
};
