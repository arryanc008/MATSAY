import React, { useState } from 'react';
import {
  Bot,
  X,
  Send,
  Sparkles,
  Ship,
  Fuel,
  AlertTriangle,
  ArrowRight
} from 'lucide-react';
import { useMaritime } from '../../context/MaritimeContext';

export const MobileOpsModal: React.FC = () => {
  const {
    isMobileOpsOpen,
    setIsMobileOpsOpen,
    vessels,
    setActiveVesselId,
    setMapFocusTarget,
    setCurrentPath
  } = useMaritime();

  const [inputQuery, setInputQuery] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [messages, setMessages] = useState<Array<{ id: string; sender: 'user' | 'ops'; text: string; timestamp: string }>>([
    {
      id: 'mob-init-1',
      sender: 'ops',
      text: 'MATSAY AI Assistant active. Monitoring real-time AIS, Admiralty physics, and quantum routing corridors across the fleet.',
      timestamp: 'Live'
    }
  ]);

  const quickQuestions = [
    'Show nearby vessels',
    'Which vessel is using the most fuel?',
    'Show active alerts',
    'Optimize my route',
    'Find the safest route'
  ];

  const handleSend = (text: string) => {
    if (!text.trim() || isProcessing) return;

    const userMsg = {
      id: `usr-${Date.now()}`,
      sender: 'user' as const,
      text,
      timestamp: new Date().toISOString().substring(11, 16) + ' UTC'
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputQuery('');
    setIsProcessing(true);

    setTimeout(() => {
      const q = text.toLowerCase();
      let reply = '';

      if (q.includes('fuel') || q.includes('most fuel')) {
        const topVessel = [...vessels].sort(
          (a, b) => b.telemetry.fuelConsumptionMtPerDay - a.telemetry.fuelConsumptionMtPerDay
        )[0];
        reply = `${topVessel.name} (IMO ${topVessel.imo}) has the highest current consumption at ${topVessel.telemetry.fuelConsumptionMtPerDay} MT/day ($${Math.round(topVessel.telemetry.fuelConsumptionMtPerDay * 645).toLocaleString()}/day). Recommended Q-Opt speed adjustment will reduce fuel burn by 14%.`;
      } else if (q.includes('alert') || q.includes('active alerts') || q.includes('delay')) {
        reply = `Critical Maritime Alert: MV HIMALAYAN PHOENIX (Bulk Carrier) outer-band cyclone advisory in Bay of Bengal with 5.2m swells. Emergency diversion S-Turn recommended.`;
      } else if (q.includes('optimize') || q.includes('route')) {
        reply = `Quantum Multi-Objective Pareto optimization complete: 3 vessel speed-reduction directives ready. Projected fleet bunker savings: -8.6% (-174 t CO2/day) with zero schedule penalties.`;
      } else if (q.includes('nearby') || q.includes('vessels')) {
        reply = `Fleet status: 24 active vessels tracked via real-time AISStream.io. 19 in transit, 5 anchored/berthed along Indian Ocean and Malacca corridors.`;
      } else {
        reply = `Admiralty Fleet Command response for "${text}": Telemetry synced. Vessel routing parameters are within optimal safety baselines across the sector.`;
      }

      setMessages((prev) => [
        ...prev,
        {
          id: `ops-${Date.now()}`,
          sender: 'ops' as const,
          text: reply,
          timestamp: new Date().toISOString().substring(11, 16) + ' UTC'
        }
      ]);
      setIsProcessing(false);
    }, 600);
  };

  return (
    <>
      {/* Floating AI Launcher Button on Mobile (visible only on md:hidden when modal is closed) */}
      {!isMobileOpsOpen && (
        <button
          onClick={() => setIsMobileOpsOpen(true)}
          className="md:hidden fixed bottom-18 right-4 z-40 w-12 h-12 rounded-full bg-gradient-to-r from-[#0879D1] to-[#062B52] text-white shadow-xl flex items-center justify-center border-2 border-white active:scale-95 transition-transform"
          aria-label="Open MATSAY AI Assistant"
        >
          <Bot className="w-6 h-6 animate-pulse" />
        </button>
      )}

      {/* Near-Full-Screen / Modal on Mobile */}
      {isMobileOpsOpen && (
        <div className="fixed inset-0 z-50 flex flex-col bg-white md:hidden animate-fade-in">
          {/* Modal Header */}
          <div className="px-4 py-3 bg-[#062B52] text-white flex items-center justify-between border-b border-[#0A3D6B] shrink-0">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-[#0879D1] flex items-center justify-center">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="text-sm font-bold tracking-tight">MATSAY AI Assistant</h3>
                <span className="text-[10px] text-[#B9DDF5]/80 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#18A879] animate-pulse" />
                  Quantum Fleet Intelligence Active
                </span>
              </div>
            </div>
            <button
              onClick={() => setIsMobileOpsOpen(false)}
              className="p-1.5 rounded-md text-[#B9DDF5]/80 hover:text-white hover:bg-[#0A3D6B] transition-colors"
              aria-label="Close AI Assistant"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Quick Suggestions Chips */}
          <div className="p-2.5 bg-[#EFF9FF] border-b border-[#B9DDF5] overflow-x-auto flex gap-1.5 shrink-0 no-scrollbar">
            {quickQuestions.map((q, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(q)}
                className="whitespace-nowrap px-2.5 py-1 rounded-full bg-white border border-[#B9DDF5] text-[11px] font-medium text-[#063A6B] hover:bg-[#DDF3FF] active:scale-95 transition-all shadow-xs"
              >
                {q}
              </button>
            ))}
          </div>

          {/* Conversation History */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-[#F4FBFF]">
            {messages.map((m) => (
              <div
                key={m.id}
                className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[85%] rounded-lg p-3 text-xs leading-relaxed shadow-xs ${
                    m.sender === 'user'
                      ? 'bg-[#0879D1] text-white font-medium rounded-tr-none'
                      : 'bg-white border border-[#B9DDF5] text-[#063A6B] rounded-tl-none'
                  }`}
                >
                  {m.text}
                </div>
                <span className="text-[9px] text-[#55738C] font-mono mt-1 px-1">
                  {m.timestamp}
                </span>
              </div>
            ))}
            {isProcessing && (
              <div className="flex items-center gap-1.5 text-xs text-[#55738C] p-2 bg-white rounded border border-[#B9DDF5] w-fit">
                <Sparkles className="w-3.5 h-3.5 text-[#0879D1] animate-spin" />
                <span>Analyzing fleet telemetry...</span>
              </div>
            )}
          </div>

          {/* Touch-Friendly Input Area (accessible above keyboard) */}
          <div className="p-3 bg-white border-t border-[#B9DDF5] shrink-0 flex items-center gap-2 safe-bottom">
            <input
              type="text"
              value={inputQuery}
              onChange={(e) => setInputQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleSend(inputQuery);
              }}
              placeholder="Ask MATSAY (e.g. Optimize fleet, show alerts)..."
              className="flex-1 px-3 py-2.5 text-xs bg-[#EFF9FF] border border-[#B9DDF5] rounded-md text-[#063A6B] placeholder-[#55738C] focus:outline-none focus:ring-1 focus:ring-[#0879D1]"
            />
            <button
              onClick={() => handleSend(inputQuery)}
              disabled={!inputQuery.trim() || isProcessing}
              className="p-2.5 bg-[#0879D1] hover:bg-[#062B52] disabled:opacity-40 text-white rounded-md transition-colors shadow-xs shrink-0"
              aria-label="Send message"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </>
  );
};
