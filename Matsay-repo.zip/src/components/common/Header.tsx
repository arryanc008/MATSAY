import React, { useState } from 'react';
import {
  Bell,
  ChevronDown,
  User,
  Sliders,
  LogOut,
  RefreshCw,
  Menu,
  Compass,
  Database
} from 'lucide-react';
import { useMaritime } from '../../context/MaritimeContext';

export const Header: React.FC = () => {
  const {
    session,
    logout,
    vessels,
    lastSyncTime,
    alerts,
    setCurrentPath,
    integrationStatus,
    refreshBackendData,
    setIsMobileMenuOpen
  } = useMaritime();

  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [isAlertsOpen, setIsAlertsOpen] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const unreadAlerts = alerts.filter((a) => !a.acknowledged);
  const criticalUnreadCount = unreadAlerts.filter((a) => a.category === 'Critical').length;

  const isAisLive =
    integrationStatus.ais.isConfigured && integrationStatus.ais.status === 'LIVE_STREAM_ACTIVE';
  const liveAisVesselCount = vessels.filter((v) => v.liveAisAvailable).length;

  const handleManualRefresh = async () => {
    setIsRefreshing(true);
    try {
      await refreshBackendData();
    } finally {
      setTimeout(() => setIsRefreshing(false), 400);
    }
  };

  return (
    <header className="h-14 bg-white border-b border-[#B9DDF5] px-3 sm:px-4 flex items-center justify-between shrink-0 z-20 shadow-xs select-none">
      {/* Left: Mobile Hamburger + Brand Identity & Live Telemetry Status Bar */}
      <div className="flex items-center gap-2 sm:gap-3 min-w-0">
        {/* Mobile Hamburger Button */}
        <button
          onClick={() => setIsMobileMenuOpen(true)}
          className="md:hidden p-2 -ml-1 text-[#063A6B] hover:bg-[#EFF9FF] rounded-md transition-colors"
          aria-label="Open operational navigation menu"
        >
          <Menu className="w-5 h-5 text-[#063A6B]" />
        </button>

        {/* Brand Identity in Header */}
        <div
          onClick={() => setCurrentPath('/command-center')}
          className="flex items-center gap-2 cursor-pointer pr-2 sm:border-r sm:border-[#B9DDF5]"
        >
          <div className="w-7 h-7 rounded bg-[#062B52] flex items-center justify-center text-white shrink-0 md:hidden">
            <Compass className="w-4 h-4 text-[#0879D1]" />
          </div>
          <div className="leading-tight">
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-xs sm:text-sm text-[#063A6B] tracking-wider">
                MATSAY
              </span>
              <span className="hidden xl:inline-block text-[9px] font-mono font-bold uppercase px-1.5 py-0.5 rounded bg-[#062B52] text-white">
                COMMAND
              </span>
            </div>
            <div className="hidden sm:block text-[10px] text-[#55738C] font-medium">
              Fleet Command Center
            </div>
          </div>
        </div>

        {/* Live Telemetry Status Indicators */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
          {/* 1. AIS Status Pill */}
          <div
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#F8FCFF] border border-[#B9DDF5] text-[11px]"
            title={
              isAisLive
                ? 'Connected to AISStream.io real-time maritime transponder stream'
                : 'AISStream.io standby — displaying verified fleet baseline positions'
            }
          >
            <span className="relative flex h-2 w-2 shrink-0">
              {isAisLive && (
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#18A879] opacity-75" />
              )}
              <span
                className={`relative inline-flex rounded-full h-2 w-2 ${
                  isAisLive ? 'bg-[#18A879]' : 'bg-[#F3A712]'
                }`}
              />
            </span>
            <span className="font-bold text-[#063A6B] whitespace-nowrap">
              {isAisLive ? 'AIS LIVE' : 'AIS STREAM'}
            </span>
            <span className="text-[#55738C] hidden md:inline">·</span>
            <span className="font-mono text-[10px] text-[#063A6B] font-semibold whitespace-nowrap hidden md:inline">
              {vessels.length} vessels
              {liveAisVesselCount > 0 ? ` (${liveAisVesselCount} live)` : ''}
            </span>
            <span className="text-[#55738C] hidden lg:inline">·</span>
            <span className="text-[10px] text-[#55738C] font-mono whitespace-nowrap hidden lg:inline">
              {isAisLive ? 'Updated <15s ago' : 'Verified Registry'}
            </span>
            <span
              className={`text-[9px] font-mono font-bold px-1 py-0.2 rounded ${
                isAisLive
                  ? 'bg-[#18A879]/15 text-[#18A879]'
                  : 'bg-[#0879D1]/15 text-[#0879D1]'
              }`}
            >
              {isAisLive ? 'LIVE' : 'REGISTRY'}
            </span>
          </div>

          {/* 2. Weather Status Pill */}
          <div
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#F8FCFF] border border-[#B9DDF5] text-[11px]"
            title="Real-time Marine & Atmospheric Observations via Open-Meteo API"
          >
            <span className="relative flex h-2 w-2 shrink-0">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#18A879] opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-[#18A879]" />
            </span>
            <span className="font-bold text-[#063A6B] whitespace-nowrap">WEATHER LIVE</span>
            <span className="text-[#55738C] hidden lg:inline">·</span>
            <span className="text-[10px] text-[#55738C] whitespace-nowrap hidden lg:inline">
              Open-Meteo
            </span>
            <span className="text-[9px] font-mono font-bold px-1 py-0.2 rounded bg-[#18A879]/15 text-[#18A879]">
              LIVE
            </span>
          </div>

          {/* 3. Cloud / PostgreSQL Status */}
          <div
            className="hidden xl:flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#F8FCFF] border border-[#B9DDF5] text-[11px]"
            title={`Database Status: ${integrationStatus.database.type} (${integrationStatus.database.status})`}
          >
            <Database className="w-3 h-3 text-[#0879D1] shrink-0" />
            <span className="font-semibold text-[#063A6B] whitespace-nowrap">PostgreSQL</span>
            <span
              className={`text-[9px] font-mono font-bold px-1 py-0.2 rounded ${
                integrationStatus.database.status === 'CONNECTED'
                  ? 'bg-[#18A879]/15 text-[#18A879]'
                  : 'bg-[#F3A712]/15 text-[#F3A712]'
              }`}
            >
              {integrationStatus.database.status}
            </span>
          </div>
        </div>
      </div>

      {/* Right: Sync Timestamp, Operational Alerts & Commander Profile */}
      <div className="flex items-center gap-2 sm:gap-3 shrink-0">
        {/* Sync Timestamp + Manual Refresh */}
        <button
          onClick={handleManualRefresh}
          className="flex items-center gap-1.5 text-[10px] text-[#55738C] font-mono px-2 py-1 rounded hover:bg-[#EFF9FF] hover:text-[#0879D1] border border-transparent hover:border-[#B9DDF5] transition-all"
          title="Synchronize fleet telemetry, Open-Meteo weather, and PostgreSQL state"
        >
          <RefreshCw
            className={`w-3.5 h-3.5 text-[#0879D1] transition-transform duration-500 ${
              isRefreshing ? 'rotate-180' : ''
            }`}
          />
          <span className="hidden md:inline">Sync: {lastSyncTime}</span>
        </button>

        {/* Operational Alerts Bell */}
        <div className="relative">
          <button
            onClick={() => setIsAlertsOpen(!isAlertsOpen)}
            className="p-1.5 rounded-md hover:bg-[#EFF9FF] text-[#063A6B] relative transition-colors border border-transparent hover:border-[#B9DDF5]"
            title="Operational Exceptions & Alerts"
            aria-label="View Operational Alerts"
          >
            <Bell className="w-4 h-4" />
            {unreadAlerts.length > 0 && (
              <span
                className={`absolute -top-0.5 -right-0.5 min-w-[16px] h-4 px-1 rounded-full text-[9px] font-bold text-white flex items-center justify-center ring-2 ring-white ${
                  criticalUnreadCount > 0 ? 'bg-[#E84A5A]' : 'bg-[#F3A712]'
                }`}
              >
                {unreadAlerts.length}
              </span>
            )}
          </button>

          {isAlertsOpen && (
            <div className="absolute right-0 mt-2 w-[calc(100vw-2rem)] sm:w-80 max-w-sm bg-white border border-[#B9DDF5] rounded-md shadow-xl py-2 z-50">
              <div className="px-3 py-1.5 border-b border-[#EFF9FF] flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-bold text-[#063A6B]">Operational Alerts</span>
                  <span className="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded bg-[#E84A5A]/10 text-[#E84A5A]">
                    {unreadAlerts.length} Unread
                  </span>
                </div>
                <button
                  onClick={() => {
                    setIsAlertsOpen(false);
                    setCurrentPath('/alerts');
                  }}
                  className="text-[11px] text-[#0879D1] hover:underline font-semibold"
                >
                  View All ({alerts.length})
                </button>
              </div>
              <div className="max-h-64 overflow-y-auto divide-y divide-[#EFF9FF]">
                {alerts.slice(0, 4).map((alert) => (
                  <div
                    key={alert.id}
                    onClick={() => {
                      setIsAlertsOpen(false);
                      setCurrentPath('/alerts');
                    }}
                    className="p-2.5 hover:bg-[#EFF9FF]/60 transition-colors cursor-pointer"
                  >
                    <div className="flex items-center justify-between text-[11px] mb-1">
                      <span
                        className={`font-bold truncate pr-2 ${
                          alert.category === 'Critical'
                            ? 'text-[#E84A5A]'
                            : alert.category === 'Warning'
                            ? 'text-[#F3A712]'
                            : 'text-[#0879D1]'
                        }`}
                      >
                        {alert.category === 'Critical' ? '🔴 ' : alert.category === 'Warning' ? '🟡 ' : '🔵 '}
                        {alert.title}
                      </span>
                      <span className="text-[9px] text-[#55738C] font-mono shrink-0">
                        {alert.timestamp}
                      </span>
                    </div>
                    <p className="text-[11px] text-[#55738C] line-clamp-2 leading-relaxed">
                      {alert.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Commander Profile Dropdown */}
        <div className="relative pl-1 sm:border-l sm:border-[#B9DDF5]">
          <button
            onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
            className="flex items-center gap-1.5 sm:gap-2 pl-1 pr-1.5 py-1 rounded-md hover:bg-[#EFF9FF] transition-colors"
          >
            <div className="w-7 h-7 rounded-full bg-[#062B52] border border-[#B9DDF5] flex items-center justify-center text-xs font-bold text-white shrink-0">
              JM
            </div>
            <div className="text-left hidden sm:block">
              <div className="text-xs font-bold text-[#063A6B] leading-none truncate max-w-[120px]">
                {session.user?.name || 'Fleet Commander'}
              </div>
              <div className="text-[9px] text-[#55738C] font-medium leading-tight">
                Fleet Commander
              </div>
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-[#55738C] shrink-0" />
          </button>

          {isProfileMenuOpen && (
            <div className="absolute right-0 mt-2 w-56 max-w-[85vw] bg-white border border-[#B9DDF5] rounded-md shadow-lg py-1.5 z-50">
              <div className="px-3 py-2 border-b border-[#EFF9FF]">
                <div className="text-xs font-bold text-[#063A6B] truncate">{session.user?.name}</div>
                <div className="text-[10px] text-[#55738C] truncate">{session.user?.email}</div>
                <div className="text-[9px] font-mono text-[#0879D1] mt-1 font-semibold">
                  CLEARANCE: LEVEL 5
                </div>
              </div>
              <button
                onClick={() => {
                  setIsProfileMenuOpen(false);
                  setCurrentPath('/analytics');
                }}
                className="w-full text-left px-3 py-2 text-xs text-[#063A6B] hover:bg-[#EFF9FF] flex items-center gap-2"
              >
                <User className="w-3.5 h-3.5 text-[#55738C]" />
                <span>Commander Profile</span>
              </button>
              <button
                onClick={() => {
                  setIsProfileMenuOpen(false);
                  setCurrentPath('/optimization');
                }}
                className="w-full text-left px-3 py-2 text-xs text-[#063A6B] hover:bg-[#EFF9FF] flex items-center gap-2"
              >
                <Sliders className="w-3.5 h-3.5 text-[#55738C]" />
                <span>Optimization Preferences</span>
              </button>
              <div className="border-t border-[#EFF9FF] my-1" />
              <button
                onClick={() => {
                  setIsProfileMenuOpen(false);
                  logout();
                }}
                className="w-full text-left px-3 py-2 text-xs text-[#E84A5A] hover:bg-[#EFF9FF] flex items-center gap-2 font-medium"
              >
                <LogOut className="w-3.5 h-3.5 text-[#E84A5A]" />
                <span>Sign Out of Command Center</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
