import React from 'react';
import {
  LayoutDashboard,
  MapPin,
  Ship,
  Sparkles,
  GitFork,
  Boxes,
  Fuel,
  CloudSun,
  Leaf,
  Bell,
  Radio,
  Sliders,
  BarChart3,
  Bot,
  LogOut,
  Compass,
  X
} from 'lucide-react';
import { useMaritime } from '../../context/MaritimeContext';

interface NavItem {
  id: string;
  label: string;
  path: string;
  icon: React.ElementType;
  badge?: number;
}

interface NavGroup {
  title: string;
  items: NavItem[];
}

export const Sidebar: React.FC = () => {
  const {
    currentPath,
    setCurrentPath,
    session,
    logout,
    alerts,
    isMobileMenuOpen,
    setIsMobileMenuOpen
  } = useMaritime();

  const unreadAlerts = alerts.filter((a) => !a.acknowledged).length;

  const navGroups: NavGroup[] = [
    {
      title: 'OPERATIONS',
      items: [
        { id: 'command-center', label: 'Command Center', path: '/command-center', icon: LayoutDashboard },
        { id: 'map', label: 'Fleet Map', path: '/map', icon: MapPin },
        { id: 'vessels', label: 'Vessels', path: '/vessels', icon: Ship },
        { id: 'routes', label: 'Routes', path: '/routes', icon: GitFork }
      ]
    },
    {
      title: 'INTELLIGENCE',
      items: [
        { id: 'optimization', label: 'Optimization', path: '/optimization', icon: Sparkles },
        { id: 'fuel', label: 'Fuel Intelligence', path: '/fuel', icon: Fuel },
        { id: 'weather', label: 'Weather & Ocean', path: '/weather', icon: CloudSun },
        { id: 'analytics', label: 'Analytics', path: '/analytics', icon: BarChart3 }
      ]
    },
    {
      title: 'MANAGEMENT',
      items: [
        { id: 'cargo', label: 'Cargo & Allocation', path: '/cargo', icon: Boxes },
        {
          id: 'alerts',
          label: 'Alerts',
          path: '/alerts',
          icon: Bell,
          badge: unreadAlerts > 0 ? unreadAlerts : undefined
        },
        { id: 'communications', label: 'Communications', path: '/communications', icon: Radio },
        { id: 'scenarios', label: 'Scenarios', path: '/scenarios', icon: Sliders }
      ]
    },
    {
      title: 'SYSTEM',
      items: [
        { id: 'sustainability', label: 'Sustainability', path: '/sustainability', icon: Leaf },
        { id: 'ops', label: 'MATSAY Ops', path: '/ops', icon: Bot }
      ]
    }
  ];

  const handleNavClick = (path: string) => {
    setCurrentPath(path);
    setIsMobileMenuOpen(false);
  };

  const sidebarContent = (
    <div className="flex flex-col h-full bg-[#062B52] text-white border-r border-[#0A3D6B] select-none">
      {/* Brand Header */}
      <div className="p-3.5 border-b border-[#0A3D6B] flex items-center justify-between gap-3">
        <div
          onClick={() => handleNavClick('/command-center')}
          className="flex items-center gap-2.5 overflow-hidden cursor-pointer"
        >
          <div className="w-9 h-9 rounded-lg bg-[#0879D1] flex items-center justify-center shadow-sm border border-[#B9DDF5]/20 shrink-0">
            <Compass className="w-5 h-5 text-white" />
          </div>
          <div className="truncate md:max-lg:hidden">
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-base tracking-wider text-white">MATSAY</span>
              <span className="text-[9px] uppercase tracking-wider font-mono font-semibold text-[#DDF3FF] bg-[#0A3D6B] border border-[#B9DDF5]/20 px-1.5 py-0.2 rounded">
                ADMIRALTY
              </span>
            </div>
            <p className="text-[10px] text-[#B9DDF5]/80 leading-tight truncate">
              Fleet Command Center
            </p>
          </div>
        </div>

        {/* Mobile Close Button */}
        <button
          onClick={() => setIsMobileMenuOpen(false)}
          className="md:hidden p-1.5 text-[#B9DDF5]/80 hover:text-white hover:bg-[#0A3D6B] rounded transition-colors"
          aria-label="Close navigation menu"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Grouped Navigation Links */}
      <div className="flex-1 overflow-y-auto py-2 px-2 space-y-3 custom-scrollbar">
        {navGroups.map((group) => (
          <div key={group.title} className="space-y-0.5">
            <div className="px-2.5 py-1 text-[10px] font-bold tracking-wider text-[#B9DDF5]/50 md:max-lg:hidden">
              {group.title}
            </div>
            {group.items.map((item) => {
              const Icon = item.icon;
              const isActive = currentPath === item.path;

              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.path)}
                  title={`${group.title} — ${item.label}`}
                  className={`relative w-full flex items-center justify-between px-2.5 py-1.5 rounded-md text-xs font-medium transition-all ${
                    isActive
                      ? 'bg-[#0879D1] text-white font-semibold shadow-xs'
                      : 'text-[#DDF3FF]/80 hover:bg-[#0A3D6B] hover:text-white'
                  } md:max-lg:justify-center md:max-lg:px-2 md:max-lg:py-2.5`}
                >
                  <div className="flex items-center gap-2.5 md:max-lg:gap-0">
                    <Icon
                      className={`w-4 h-4 shrink-0 ${
                        isActive ? 'text-white' : 'text-[#B9DDF5]/70'
                      }`}
                    />
                    <span className="truncate md:max-lg:hidden">{item.label}</span>
                  </div>
                  {item.badge !== undefined && (
                    <span className="bg-[#E84A5A] text-white text-[10px] font-mono font-bold px-1.5 py-0.2 rounded-full md:max-lg:absolute md:max-lg:top-1 md:max-lg:right-1">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        ))}
      </div>

      {/* Footer / Commander Profile */}
      <div className="p-2.5 border-t border-[#0A3D6B] bg-[#052242]">
        <div className="flex items-center justify-between gap-2 p-2 rounded-md bg-[#0A3D6B]/50 border border-[#B9DDF5]/10 md:max-lg:p-1 md:max-lg:justify-center">
          <div className="flex items-center gap-2 overflow-hidden md:max-lg:hidden">
            <div className="w-7 h-7 rounded-full bg-[#0879D1] flex items-center justify-center text-xs font-bold text-white shrink-0">
              JM
            </div>
            <div className="truncate">
              <div className="text-xs font-semibold text-white truncate">
                {session.user?.name || 'Commander'}
              </div>
              <div className="text-[10px] text-[#B9DDF5]/70 truncate">
                {session.user?.rank || 'Fleet Commander'}
              </div>
            </div>
          </div>
          <button
            onClick={() => {
              logout();
              setIsMobileMenuOpen(false);
            }}
            title="Sign out of command session"
            className="p-1.5 text-[#B9DDF5]/70 hover:text-[#E84A5A] hover:bg-[#062B52] rounded transition-colors"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop & Tablet Sidebar (Always mounted on md and above) */}
      <aside className="hidden md:flex flex-col h-screen shrink-0 md:w-16 lg:w-60 z-30 transition-all duration-200">
        {sidebarContent}
      </aside>

      {/* Mobile Drawer (Slide-in off-canvas on < md) */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-50 md:hidden flex">
          <div
            onClick={() => setIsMobileMenuOpen(false)}
            className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity animate-fade-in"
          />
          <div className="relative w-72 max-w-[85vw] h-full shadow-2xl z-50 animate-slide-right">
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
};
