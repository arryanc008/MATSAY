import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import {
  Layers,
  Search,
  Compass,
  Filter,
  Navigation,
  Sparkles
} from 'lucide-react';
import { useMaritime, MapLayersState } from '../../context/MaritimeContext';
import { Vessel, Port } from '../../types/maritime';

export type MapStatusFilter =
  | 'ALL'
  | 'Normal'
  | 'Warning'
  | 'Critical'
  | 'Risk'
  | 'Anchored'
  | 'Offline';

interface FleetGISMapProps {
  heightClass?: string;
  showLayerToggleOverlay?: boolean;
  statusFilter?: MapStatusFilter;
  onStatusFilterChange?: (filter: MapStatusFilter) => void;
}

export const FleetGISMap: React.FC<FleetGISMapProps> = ({
  heightClass = 'h-[540px]',
  showLayerToggleOverlay = true,
  statusFilter: externalFilter,
  onStatusFilterChange
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);
  const routesLayerRef = useRef<L.LayerGroup | null>(null);
  const zonesLayerRef = useRef<L.LayerGroup | null>(null);
  const weatherLayerRef = useRef<L.LayerGroup | null>(null);
  const portsLayerRef = useRef<L.LayerGroup | null>(null);
  const seamarksLayerRef = useRef<L.TileLayer | null>(null);

  const {
    vessels,
    activeVessel,
    activeVesselId,
    setActiveVesselId,
    ports,
    restrictedZones,
    storms,
    mapLayers,
    toggleMapLayer,
    mapFocusTarget,
    weatherForecastStep,
    setCurrentPath
  } = useMaritime();

  const [internalFilter, setInternalFilter] = useState<MapStatusFilter>('ALL');
  const activeFilter = externalFilter !== undefined ? externalFilter : internalFilter;

  const setFilter = (next: MapStatusFilter) => {
    if (onStatusFilterChange) {
      onStatusFilterChange(next);
    } else {
      setInternalFilter(next);
    }
  };

  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<
    Array<{ type: 'vessel' | 'port'; item: Vessel | Port }>
  >([]);
  const [isLayerDrawerOpen, setIsLayerDrawerOpen] = useState(false);

  // Filter vessels according to active status/risk filter
  const filteredVessels = vessels.filter((v) => {
    if (activeFilter === 'ALL') return true;
    const isAnchoredOrBerthed = v.status !== 'IN TRANSIT' || v.speedKts < 0.8;
    if (activeFilter === 'Anchored') return isAnchoredOrBerthed;
    if (activeFilter === 'Critical') return v.scheduleStatus === 'Critical';
    if (activeFilter === 'Warning') return v.scheduleStatus === 'Warning';
    if (activeFilter === 'Risk')
      return v.scheduleStatus === 'Critical' || v.scheduleStatus === 'Warning';
    if (activeFilter === 'Normal')
      return v.scheduleStatus === 'On Schedule' && !isAnchoredOrBerthed;
    if (activeFilter === 'Offline') return !v.liveAisAvailable;
    return true;
  });

  // Initialize Leaflet Map with OpenStreetMap Standard Tiles
  useEffect(() => {
    if (!mapContainerRef.current) return;
    if (mapInstanceRef.current) return;

    const map = L.map(mapContainerRef.current, {
      center: [10.5, 78.0],
      zoom: 5,
      minZoom: 3,
      maxZoom: 18,
      zoomControl: false,
      attributionControl: true
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution:
        '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a>'
    }).addTo(map);

    const seamarkTileLayer = L.tileLayer(
      'https://tiles.openseamap.org/seamark/{z}/{x}/{y}.png',
      {
        maxZoom: 18,
        opacity: 0.85
      }
    );
    seamarksLayerRef.current = seamarkTileLayer;
    seamarkTileLayer.addTo(map);

    L.control.zoom({ position: 'bottomleft' }).addTo(map);

    zonesLayerRef.current = L.layerGroup().addTo(map);
    routesLayerRef.current = L.layerGroup().addTo(map);
    weatherLayerRef.current = L.layerGroup().addTo(map);
    portsLayerRef.current = L.layerGroup().addTo(map);
    markersLayerRef.current = L.layerGroup().addTo(map);

    mapInstanceRef.current = map;

    setTimeout(() => {
      map.invalidateSize();
    }, 150);

    const handleResize = () => {
      map.invalidateSize();
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // Handle external focus target
  useEffect(() => {
    if (!mapInstanceRef.current || !mapFocusTarget) return;
    mapInstanceRef.current.flyTo(
      [mapFocusTarget.lat, mapFocusTarget.lng],
      mapFocusTarget.zoom || 7,
      { duration: 1.1 }
    );
  }, [mapFocusTarget]);

  // Search filtering by Vessel Name, IMO, MMSI, Destination, or Port
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      return;
    }
    const q = searchQuery.toLowerCase();
    const matchedVessels = vessels
      .filter(
        (v) =>
          v.name.toLowerCase().includes(q) ||
          v.imo.toLowerCase().includes(q) ||
          (v.mmsi && v.mmsi.toLowerCase().includes(q)) ||
          v.destination.toLowerCase().includes(q)
      )
      .map((v) => ({ type: 'vessel' as const, item: v }));

    const matchedPorts = ports
      .filter((p) => p.name.toLowerCase().includes(q) || p.code.toLowerCase().includes(q))
      .map((p) => ({ type: 'port' as const, item: p }));

    setSearchResults([...matchedVessels, ...matchedPorts].slice(0, 6));
  }, [searchQuery, vessels, ports]);

  // Toggle OpenSeaMap Seamarks layer
  useEffect(() => {
    if (!seamarksLayerRef.current || !mapInstanceRef.current) return;
    if (mapLayers.trafficDensity) {
      if (!mapInstanceRef.current.hasLayer(seamarksLayerRef.current)) {
        mapInstanceRef.current.addLayer(seamarksLayerRef.current);
      }
    } else {
      if (mapInstanceRef.current.hasLayer(seamarksLayerRef.current)) {
        mapInstanceRef.current.removeLayer(seamarksLayerRef.current);
      }
    }
  }, [mapLayers.trafficDensity]);

  // Render Restricted Zones Layer
  useEffect(() => {
    if (!zonesLayerRef.current) return;
    zonesLayerRef.current.clearLayers();

    if (!mapLayers.restrictedZones) return;

    restrictedZones.forEach((zone) => {
      const latlngs = zone.coordinates.map((c) => [c.lat, c.lng] as [number, number]);
      const isHRA = zone.type === 'Piracy High Risk Area';
      const color = isHRA ? '#E84A5A' : '#F3A712';

      const polygon = L.polygon(latlngs, {
        color: color,
        weight: 1.5,
        dashArray: '4, 4',
        fillColor: color,
        fillOpacity: 0.12
      });

      polygon.bindTooltip(
        `<div class="text-[11px] font-bold text-[#063A6B]">${zone.name}</div>
         <div class="text-[10px] text-[#55738C]">${zone.type} · ${zone.severity}</div>
         <div class="text-[9px] text-[#063A6B]/80 mt-1">${zone.notes}</div>`,
        { sticky: true }
      );

      polygon.addTo(zonesLayerRef.current!);
    });
  }, [mapLayers.restrictedZones, restrictedZones]);

  // Render Storms & Weather Overlays
  useEffect(() => {
    if (!weatherLayerRef.current) return;
    weatherLayerRef.current.clearLayers();

    if (mapLayers.storms) {
      storms.forEach((storm) => {
        const circle = L.circle([storm.coordinates.lat, storm.coordinates.lng], {
          radius: storm.radiusNm * 1852,
          color: '#E84A5A',
          weight: 2,
          dashArray: '6, 6',
          fillColor: '#E84A5A',
          fillOpacity: 0.15
        });

        const stormIcon = L.divIcon({
          className: 'storm-center-marker',
          html: `<div class="relative flex items-center justify-center w-8 h-8">
            <span class="pulse-ring bg-[#E84A5A]"></span>
            <div class="w-7 h-7 rounded-full bg-[#E84A5A] text-white flex items-center justify-center shadow-lg border border-white font-bold text-[10px]">
              🌀
            </div>
          </div>`,
          iconSize: [32, 32],
          iconAnchor: [16, 16]
        });

        const marker = L.marker([storm.coordinates.lat, storm.coordinates.lng], {
          icon: stormIcon
        });
        marker.bindTooltip(
          `<div class="text-xs font-extrabold text-[#E84A5A]">${storm.name}</div>
           <div class="text-[10px] text-[#063A6B] font-semibold">${storm.category} · Winds ${storm.maxWindKts} kts</div>
           <div class="text-[9px] text-[#55738C]">Movement: ${storm.headingDeg}° @ ${storm.movementSpeedKts} kts</div>`,
          { permanent: false, sticky: true }
        );

        circle.addTo(weatherLayerRef.current!);
        marker.addTo(weatherLayerRef.current!);
      });
    }

    if (mapLayers.oceanCurrents) {
      const currentStreamCoords: [number, number][] = [
        [4.8, 76.0],
        [4.9, 80.0],
        [5.0, 85.0],
        [5.1, 90.0],
        [5.2, 94.0]
      ];
      const currentPolyline = L.polyline(currentStreamCoords, {
        color: '#0879D1',
        weight: 3,
        opacity: 0.6,
        dashArray: '10, 8'
      });
      currentPolyline.bindTooltip(
        '<div class="text-xs font-bold text-[#0879D1]">Southwest Monsoon Current / Equatorial Stream</div><div class="text-[10px] text-[#55738C]">Eastward +1.4 kts favorable current (LIVE / PREDICTED)</div>',
        { sticky: true }
      );
      currentPolyline.addTo(weatherLayerRef.current!);
    }
  }, [mapLayers.storms, mapLayers.oceanCurrents, storms, weatherForecastStep]);

  // Render Ports Layer
  useEffect(() => {
    if (!portsLayerRef.current) return;
    portsLayerRef.current.clearLayers();

    if (!mapLayers.ports) return;

    ports.forEach((port) => {
      const portIcon = L.divIcon({
        className: 'port-marker-node',
        html: `<div class="w-6 h-6 rounded bg-[#063A6B] text-white flex items-center justify-center border border-white shadow-sm hover:scale-110 transition-transform">
          <svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
            <circle cx="12" cy="5" r="3"></circle>
            <line x1="12" y1="22" x2="12" y2="8"></line>
            <path d="M5 12H2a10 10 0 0 0 20 0h-3"></path>
          </svg>
        </div>`,
        iconSize: [24, 24],
        iconAnchor: [12, 12]
      });

      const marker = L.marker([port.coordinates.lat, port.coordinates.lng], { icon: portIcon });
      marker.bindTooltip(
        `<div class="text-xs font-bold text-[#063A6B]">${port.name} (${port.code})</div>
         <div class="text-[10px] text-[#55738C]">${port.country} · Berths: ${port.berthsAvailable} available</div>
         <div class="text-[10px] text-[#0879D1] font-semibold">Avg wait time: ${port.averageWaitHours} hrs</div>`,
        { sticky: true }
      );

      marker.addTo(portsLayerRef.current!);
    });
  }, [mapLayers.ports, ports]);

  // Render Routes (Planned vs Optimized)
  useEffect(() => {
    if (!routesLayerRef.current) return;
    routesLayerRef.current.clearLayers();

    filteredVessels.forEach((v) => {
      const isSelected = v.id === activeVesselId;

      // Planned route (Blue dashed)
      if (mapLayers.plannedRoutes && v.plannedRoute && v.plannedRoute.length > 1) {
        const plannedCoords = v.plannedRoute.map((w) => [w.lat, w.lng] as [number, number]);
        const plannedLine = L.polyline(plannedCoords, {
          color: isSelected ? '#0879D1' : '#64748B',
          weight: isSelected ? 3.5 : 1.8,
          dashArray: '6, 6',
          opacity: isSelected ? 0.95 : 0.45
        });

        plannedLine.bindTooltip(
          `<div class="text-xs font-bold text-[#063A6B]">${v.name} — Planned Baseline Route</div>
           <div class="text-[10px] text-[#55738C]">Origin: ${v.origin} → Dest: ${v.destination}</div>`,
          { sticky: true }
        );
        plannedLine.addTo(routesLayerRef.current!);
      }

      // Quantum-Optimized route (Purple #7C3AED solid for clear distinction)
      if (mapLayers.optimizedRoutes && v.optimizedRoute && v.optimizedRoute.length > 1) {
        const optCoords = v.optimizedRoute.map((w) => [w.lat, w.lng] as [number, number]);
        const optLine = L.polyline(optCoords, {
          color: '#7C3AED',
          weight: isSelected ? 4 : 2.5,
          opacity: isSelected ? 1 : 0.7
        });

        optLine.bindTooltip(
          `<div class="text-xs font-bold text-[#7C3AED]">${v.name} — Optimized Route (OPTIMIZATION)</div>
           <div class="text-[10px] text-[#063A6B] font-semibold">Favorable current & weather avoidance track</div>
           <div class="text-[9px] text-[#18A879] font-bold">Projected -8.6% fuel consumption · ETA ${v.eta}</div>`,
          { sticky: true }
        );
        optLine.addTo(routesLayerRef.current!);
      }
    });
  }, [mapLayers.plannedRoutes, mapLayers.optimizedRoutes, filteredVessels, activeVesselId]);

  // Render Vessels Markers
  useEffect(() => {
    if (!markersLayerRef.current) return;
    markersLayerRef.current.clearLayers();

    if (!mapLayers.fleet) return;

    filteredVessels.forEach((v) => {
      const isSelected = v.id === activeVesselId;
      const isAnchored = v.status !== 'IN TRANSIT' || v.speedKts < 0.8;

      // Status color code:
      // 🔴 Critical: #E84A5A
      // 🟡 Warning: #F3A712
      // 🔵 Anchored / Berthed: #0879D1
      // 🟢 Normal / Active: #18A879
      const statusColor =
        v.scheduleStatus === 'Critical'
          ? '#E84A5A'
          : v.scheduleStatus === 'Warning'
          ? '#F3A712'
          : isAnchored
          ? '#0879D1'
          : '#18A879';

      const headingSvg = `
        <div class="relative flex items-center justify-center cursor-pointer select-none" style="transform: rotate(${v.heading}deg);">
          ${
            isSelected
              ? `<div class="absolute w-10 h-10 rounded-full border-2 border-[#0879D1] animate-ping opacity-70"></div>`
              : ''
          }
          <div class="w-7 h-7 rounded-full bg-white shadow-md border-2 flex items-center justify-center transition-all ${
            isSelected
              ? 'border-[#0879D1] scale-125 z-50 ring-2 ring-[#0879D1]/40'
              : 'border-[#062B52]'
          }">
            <svg class="w-4 h-4" viewBox="0 0 24 24" fill="${statusColor}" stroke="#062B52" stroke-width="1.5">
              <path d="M12 2 L19 21 L12 17 L5 21 Z" />
            </svg>
          </div>
        </div>
      `;

      const vesselIcon = L.divIcon({
        className: 'vessel-icon-marker',
        html: headingSvg,
        iconSize: [28, 28],
        iconAnchor: [14, 14]
      });

      const marker = L.marker([v.position.lat, v.position.lng], { icon: vesselIcon });

      marker.on('click', () => {
        setActiveVesselId(v.id);
        mapInstanceRef.current?.panTo([v.position.lat, v.position.lng]);
      });

      marker.bindTooltip(
        `<div class="text-xs font-bold text-[#063A6B]">${v.name}</div>
         <div class="text-[10px] text-[#55738C]">${v.type} · IMO ${v.imo}${
          v.mmsi ? ` · MMSI ${v.mmsi}` : ''
        }</div>
         <div class="text-[10px] font-mono text-[#063A6B] mt-0.5">${v.speedKts} kn · Hdg ${
          v.heading
        }° · ${v.position.lat.toFixed(3)}°N, ${v.position.lng.toFixed(3)}°E</div>
         <div class="text-[10px] text-[#0879D1] font-semibold">Dest: ${v.destination} · ETA: ${
          v.eta
        }</div>
         <div class="text-[9px] font-bold mt-0.5 ${
           v.scheduleStatus === 'Critical'
             ? 'text-[#E84A5A]'
             : v.scheduleStatus === 'Warning'
             ? 'text-[#F3A712]'
             : isAnchored
             ? 'text-[#0879D1]'
             : 'text-[#18A879]'
         }">Risk Status: ${
          v.scheduleStatus === 'Critical'
            ? 'Critical Risk'
            : v.scheduleStatus === 'Warning'
            ? 'Warning Advisory'
            : isAnchored
            ? 'Anchored / Berthed'
            : 'Normal / Active'
        } (${v.liveAisAvailable ? 'LIVE AIS' : 'VERIFIED REGISTRY'})</div>`,
        { sticky: true }
      );

      marker.addTo(markersLayerRef.current!);
    });
  }, [mapLayers.fleet, filteredVessels, activeVesselId, setActiveVesselId]);

  const filterButtons: Array<{ id: MapStatusFilter; label: string; dotColor?: string }> = [
    { id: 'ALL', label: `All (${vessels.length})` },
    {
      id: 'Normal',
      label: 'Normal',
      dotColor: 'bg-[#18A879]'
    },
    {
      id: 'Warning',
      label: 'Warning',
      dotColor: 'bg-[#F3A712]'
    },
    {
      id: 'Critical',
      label: 'Critical',
      dotColor: 'bg-[#E84A5A]'
    },
    {
      id: 'Anchored',
      label: 'Anchored',
      dotColor: 'bg-[#0879D1]'
    }
  ];

  return (
    <div
      className={`relative w-full ${heightClass} bg-[#062B52] rounded-lg overflow-hidden border border-[#B9DDF5] shadow-xs`}
    >
      {/* Leaflet Map Div */}
      <div ref={mapContainerRef} className="w-full h-full" />

      {/* Top-Left: Map Search Bar (Vessel, IMO, MMSI, Port) + Quick Status Filter */}
      <div className="absolute top-2.5 left-2.5 z-[1000] flex flex-col gap-1.5 w-[calc(100%-130px)] sm:w-auto max-w-xl">
        <div className="flex flex-wrap items-center gap-1.5">
          {/* Search Input */}
          <div className="relative w-full sm:w-64 md:w-72">
            <div className="flex items-center bg-white/95 backdrop-blur-xs border border-[#B9DDF5] rounded-md shadow-md px-2.5 py-1.5 gap-2">
              <Search className="w-3.5 h-3.5 text-[#55738C] shrink-0" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search vessel, IMO, MMSI, port..."
                className="w-full text-xs text-[#063A6B] placeholder-[#55738C]/70 focus:outline-none bg-transparent"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="text-xs text-[#55738C] hover:text-[#063A6B] px-1"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Autocomplete dropdown */}
            {searchResults.length > 0 && (
              <div className="absolute left-0 mt-1 w-full bg-white border border-[#B9DDF5] rounded-md shadow-lg overflow-hidden z-[1002] max-h-60 overflow-y-auto">
                {searchResults.map((res, i) => {
                  const isV = res.type === 'vessel';
                  const v = res.item as Vessel;
                  const p = res.item as Port;

                  return (
                    <button
                      key={i}
                      onClick={() => {
                        if (isV) {
                          setActiveVesselId(v.id);
                          mapInstanceRef.current?.flyTo([v.position.lat, v.position.lng], 8);
                        } else {
                          mapInstanceRef.current?.flyTo([p.coordinates.lat, p.coordinates.lng], 9);
                        }
                        setSearchQuery('');
                        setSearchResults([]);
                      }}
                      className="w-full px-3 py-2 text-left hover:bg-[#EFF9FF] border-b border-[#EFF9FF] last:border-none flex items-center justify-between text-xs transition-colors"
                    >
                      <div className="truncate pr-2">
                        <div className="font-bold text-[#063A6B] truncate">
                          {isV ? v.name : p.name}
                        </div>
                        <div className="text-[10px] text-[#55738C] font-mono truncate">
                          {isV
                            ? `IMO ${v.imo}${v.mmsi ? ` · MMSI ${v.mmsi}` : ''} → ${v.destination}`
                            : `${p.code} · ${p.country}`}
                        </div>
                      </div>
                      <span className="text-[9px] uppercase px-1.5 py-0.5 rounded bg-[#EFF9FF] text-[#0879D1] font-mono font-bold shrink-0">
                        {isV ? 'VESSEL' : 'PORT'}
                      </span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Direct Map Vessel Status & Risk Filter Bar */}
          <div className="hidden md:flex items-center bg-white/95 backdrop-blur-xs border border-[#B9DDF5] rounded-md shadow-md p-0.5 gap-0.5">
            {filterButtons.map((btn) => {
              const isAct = activeFilter === btn.id;
              return (
                <button
                  key={btn.id}
                  type="button"
                  onClick={() => setFilter(btn.id)}
                  className={`flex items-center gap-1 px-2 py-1 rounded text-[11px] font-semibold transition-colors cursor-pointer ${
                    isAct
                      ? 'bg-[#062B52] text-white'
                      : 'text-[#063A6B] hover:bg-[#EFF9FF]'
                  }`}
                >
                  {btn.dotColor && (
                    <span className={`w-2 h-2 rounded-full ${btn.dotColor}`} />
                  )}
                  <span>{btn.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Top-Right: Map Layer Drawer Toggle */}
      {showLayerToggleOverlay && (
        <div className="absolute top-2.5 right-2.5 z-[1000] flex items-center gap-1.5">
          <div
            className="w-7 h-7 sm:w-8 sm:h-8 rounded-md bg-white/95 backdrop-blur-xs border border-[#B9DDF5] shadow-md flex items-center justify-center text-[#063A6B]"
            title="Nautical Chart Orientation: True North"
          >
            <Compass className="w-4 h-4 text-[#0879D1]" />
          </div>

          <button
            onClick={() => setIsLayerDrawerOpen(!isLayerDrawerOpen)}
            className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-md text-xs font-semibold shadow-md transition-colors border cursor-pointer ${
              isLayerDrawerOpen
                ? 'bg-[#0879D1] text-white border-[#0879D1]'
                : 'bg-white/95 backdrop-blur-xs text-[#063A6B] border-[#B9DDF5] hover:bg-[#EFF9FF]'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Layers</span>
          </button>
        </div>
      )}

      {/* Map Layers Control Drawer */}
      {isLayerDrawerOpen && (
        <div className="absolute top-12 right-2.5 z-[1001] w-64 max-w-[85vw] bg-white/98 backdrop-blur-sm border border-[#B9DDF5] rounded-md shadow-xl p-3 animate-fade-in">
          <div className="flex items-center justify-between pb-2 border-b border-[#B9DDF5]/40 mb-2">
            <span className="text-xs font-bold text-[#063A6B]">Maritime Map Layers</span>
            <span className="text-[10px] text-[#55738C] font-mono">GIS Controls</span>
          </div>

          <div className="space-y-1.5 max-h-64 sm:max-h-72 overflow-y-auto pr-1">
            {[
              { id: 'fleet', label: 'Fleet Vessels', count: filteredVessels.length },
              { id: 'plannedRoutes', label: 'Baseline Route Layer' },
              { id: 'optimizedRoutes', label: 'Optimized Route Layer', highlight: true },
              { id: 'ports', label: 'Port Nodes Layer', count: ports.length },
              { id: 'oceanCurrents', label: 'Weather & Ocean Currents' },
              { id: 'storms', label: 'Severe Weather / Cyclones', count: storms.length, alert: true },
              {
                id: 'restrictedZones',
                label: 'Restricted & HRA Zones',
                count: restrictedZones.length
              },
              { id: 'trafficDensity', label: 'OpenSeaMap Nautical Seamarks' }
            ].map((layer) => {
              const key = layer.id as keyof MapLayersState;
              const isChecked = mapLayers[key];

              return (
                <label
                  key={layer.id}
                  className="flex items-center justify-between text-xs py-1 px-1.5 rounded hover:bg-[#EFF9FF] cursor-pointer"
                >
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={isChecked}
                      onChange={() => toggleMapLayer(key)}
                      className="rounded border-[#B9DDF5] text-[#0879D1] focus:ring-0 w-3.5 h-3.5 cursor-pointer"
                    />
                    <span
                      className={`${
                        layer.highlight
                          ? 'font-bold text-[#7C3AED]'
                          : layer.alert
                          ? 'font-bold text-[#E84A5A]'
                          : 'text-[#063A6B]'
                      }`}
                    >
                      {layer.label}
                    </span>
                  </div>
                  {layer.count !== undefined && (
                    <span className="text-[10px] text-[#55738C] font-mono">({layer.count})</span>
                  )}
                </label>
              );
            })}
          </div>
        </div>
      )}

      {/* Selected Vessel Active HUD Overlay (Bottom-Left above zoom controls on sm+) */}
      {activeVessel && (
        <div className="hidden sm:flex absolute bottom-2.5 left-12 z-[1000] bg-white/95 backdrop-blur-xs border border-[#B9DDF5] rounded-md px-3 py-1.5 shadow-md items-center gap-3 text-xs max-w-md">
          <div className="flex items-center gap-1.5 min-w-0">
            <span
              className={`w-2.5 h-2.5 rounded-full shrink-0 ${
                activeVessel.scheduleStatus === 'Critical'
                  ? 'bg-[#E84A5A]'
                  : activeVessel.scheduleStatus === 'Warning'
                  ? 'bg-[#F3A712]'
                  : 'bg-[#18A879]'
              }`}
            />
            <span className="font-extrabold text-[#063A6B] truncate">{activeVessel.name}</span>
          </div>
          <span className="text-[#B9DDF5]">|</span>
          <div className="text-[11px] text-[#55738C] truncate">
            Dest: <span className="font-semibold text-[#063A6B]">{activeVessel.destination}</span>
          </div>
          <span className="text-[#B9DDF5] hidden md:inline">|</span>
          <div className="text-[11px] font-mono text-[#063A6B] hidden md:block whitespace-nowrap">
            ETA: {activeVessel.eta}
          </div>
          <button
            type="button"
            onClick={() => setCurrentPath('/optimization')}
            className="ml-1 px-2 py-0.5 rounded bg-[#0879D1] hover:bg-[#062B52] text-white text-[10px] font-bold flex items-center gap-1 shrink-0 transition-colors cursor-pointer"
          >
            <Sparkles className="w-2.5 h-2.5" />
            <span>Optimize</span>
          </button>
        </div>
      )}

      {/* Compact Map Legend Overlay in bottom-right */}
      <div className="absolute bottom-2.5 right-2.5 z-[1000] bg-white/95 backdrop-blur-xs border border-[#B9DDF5] rounded-md px-2.5 py-1.5 text-[10px] hidden sm:flex flex-wrap items-center gap-2.5 shadow-md">
        <div className="flex items-center gap-1">
          <span className="w-2.5 h-2.5 rounded-full bg-[#18A879]" />
          <span className="text-[#063A6B] font-medium">Normal</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="w-2.5 h-2.5 rounded-full bg-[#F3A712]" />
          <span className="text-[#063A6B] font-medium">Warning</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="w-2.5 h-2.5 rounded-full bg-[#E84A5A]" />
          <span className="text-[#063A6B] font-medium">Critical</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="w-2.5 h-2.5 rounded-full bg-[#0879D1]" />
          <span className="text-[#063A6B] font-medium">Anchored</span>
        </div>
        <div className="flex items-center gap-1 pl-1.5 border-l border-[#B9DDF5]">
          <span className="w-3.5 h-0.5 bg-[#7C3AED]" />
          <span className="text-[#063A6B] font-medium">Optimized Route</span>
        </div>
      </div>
    </div>
  );
};
