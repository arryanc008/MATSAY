import React, { useState } from 'react';
import {
  Ship,
  Compass,
  Sparkles,
  ArrowRight,
  ExternalLink,
  CheckCircle2
} from 'lucide-react';
import { useMaritime } from '../../context/MaritimeContext';
import { Coordinates } from '../../types/maritime';

interface VesselDetailsPanelProps {
  onOpenSpecsModal?: () => void;
}

function calculateRouteDistanceNm(waypoints: Coordinates[]): number {
  if (!waypoints || waypoints.length < 2) return 0;
  let totalNm = 0;
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  for (let i = 0; i < waypoints.length - 1; i++) {
    const p1 = waypoints[i];
    const p2 = waypoints[i + 1];
    const R_nm = 3440.065; // Earth radius in nautical miles
    const dLat = toRad(p2.lat - p1.lat);
    const dLng = toRad(p2.lng - p1.lng);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(toRad(p1.lat)) *
        Math.cos(toRad(p2.lat)) *
        Math.sin(dLng / 2) *
        Math.sin(dLng / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    totalNm += R_nm * c;
  }
  return Math.round(totalNm);
}

export const VesselDetailsPanel: React.FC<VesselDetailsPanelProps> = () => {
  const { activeVessel, setCurrentPath, setMapFocusTarget, optimizationResult } = useMaritime();
  const [activeTab, setActiveTab] = useState<
    'Overview' | 'Route' | 'Fuel' | 'Cargo' | 'Weather' | 'History'
  >('Overview');

  if (!activeVessel) {
    return (
      <div className="w-full bg-white border border-[#B9DDF5] rounded-lg p-6 flex flex-col items-center justify-center text-center text-[#55738C] shadow-xs">
        <Ship className="w-10 h-10 text-[#B9DDF5] mb-2" />
        <p className="text-xs font-semibold text-[#063A6B]">No vessel selected</p>
        <p className="text-[11px] text-[#55738C]">
          Click any vessel marker on the map or Action Required list to inspect telemetry
        </p>
      </div>
    );
  }

  const v = activeVessel;
  const isAnchored = v.status !== 'IN TRANSIT' || v.speedKts < 0.8;

  // Match any recommendation for this vessel from the optimization engine
  const vesselRec = optimizationResult?.recommendations.find(
    (r) => r.vesselId === v.id || r.vesselName === v.name
  );

  // Calculate route distances from actual coordinates
  const plannedDistanceNm = calculateRouteDistanceNm(v.plannedRoute) || 1240;
  const optimizedDistanceNm =
    v.optimizedRoute && v.optimizedRoute.length > 1
      ? calculateRouteDistanceNm(v.optimizedRoute)
      : Math.round(plannedDistanceNm * 0.966);
  const distanceDeltaNm = plannedDistanceNm - optimizedDistanceNm;
  const fuelSavedPct = optimizationResult
    ? Math.abs(optimizationResult.delta.fuelPct).toFixed(1)
    : '8.6';

  return (
    <div className="w-full bg-white border border-[#B9DDF5] rounded-lg shadow-xs flex flex-col overflow-hidden shrink-0">
      {/* Top Vessel Header */}
      <div className="p-3.5 border-b border-[#B9DDF5] bg-gradient-to-r from-[#F4FBFF] to-white">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h2 className="text-base font-extrabold text-[#063A6B] tracking-tight truncate">
                {v.name}
              </h2>
              {v.recommendationPending && (
                <span className="text-[9px] font-mono font-bold text-[#7C3AED] bg-[#7C3AED]/10 border border-[#7C3AED]/20 px-1.5 py-0.5 rounded shrink-0">
                  OPTIMIZATION READY
                </span>
              )}
            </div>
            <div className="text-[11px] text-[#55738C] font-mono mt-0.5 space-y-0.5">
              <div>IMO {v.imo}</div>
              <div>MMSI {v.mmsi || v.imo}</div>
            </div>
          </div>

          <div className="text-right shrink-0">
            <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-bold bg-[#F8FCFF] border border-[#B9DDF5]">
              <span
                className={`w-2 h-2 rounded-full ${
                  v.scheduleStatus === 'Critical'
                    ? 'bg-[#E84A5A]'
                    : v.scheduleStatus === 'Warning'
                    ? 'bg-[#F3A712]'
                    : isAnchored
                    ? 'bg-[#0879D1]'
                    : 'bg-[#18A879]'
                }`}
              />
              <span className="text-[#063A6B]">
                {v.scheduleStatus === 'Critical'
                  ? 'CRITICAL'
                  : v.scheduleStatus === 'Warning'
                  ? 'WARNING'
                  : 'ACTIVE'}
              </span>
            </div>
            <div className="text-[10px] text-[#55738C] font-medium mt-1">
              {v.type} · {isAnchored ? 'At Anchor / Berthed' : v.status}
            </div>
          </div>
        </div>

        {/* Primary Action Buttons */}
        <div className="flex items-center gap-2 mt-3">
          <button
            type="button"
            onClick={() =>
              setMapFocusTarget({ lat: v.position.lat, lng: v.position.lng, zoom: 8 })
            }
            className="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2.5 text-xs font-bold bg-white border border-[#B9DDF5] text-[#063A6B] rounded-md hover:bg-[#EFF9FF] transition-colors cursor-pointer"
          >
            <Compass className="w-3.5 h-3.5 text-[#0879D1]" />
            <span>LOCATE ON MAP</span>
          </button>
          <button
            type="button"
            onClick={() => setCurrentPath('/optimization')}
            className="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2.5 text-xs font-bold bg-[#0879D1] text-white rounded-md hover:bg-[#062B52] transition-colors shadow-xs cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>OPTIMIZE VESSEL</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex border-b border-[#B9DDF5] bg-[#F8FCFF] text-xs px-2 overflow-x-auto no-scrollbar">
        {(['Overview', 'Route', 'Fuel', 'Cargo', 'Weather', 'History'] as const).map((tab) => (
          <button
            key={tab}
            type="button"
            onClick={() => setActiveTab(tab)}
            className={`py-2 px-2.5 font-semibold transition-colors border-b-2 whitespace-nowrap cursor-pointer ${
              activeTab === tab
                ? 'border-[#0879D1] text-[#0879D1] bg-white'
                : 'border-transparent text-[#55738C] hover:text-[#063A6B]'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Tab Content Body */}
      <div className="p-3.5 space-y-3 overflow-y-auto max-h-[470px]">
        {activeTab === 'Overview' && (
          <div className="space-y-3 text-xs">
            {/* 1. VOYAGE */}
            <div className="pb-2.5 border-b border-[#EFF9FF]">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] font-bold tracking-wider text-[#55738C]">VOYAGE</span>
                <span className="text-[9px] font-mono font-bold px-1.5 py-0.2 rounded bg-[#0879D1]/12 text-[#0879D1]">
                  CALCULATED
                </span>
              </div>
              <div className="flex items-center gap-1.5 font-bold text-[#063A6B] text-xs">
                <span className="truncate">{v.origin}</span>
                <ArrowRight className="w-3.5 h-3.5 text-[#0879D1] shrink-0" />
                <span className="truncate">{v.destination}</span>
              </div>
              <div className="text-[11px] font-mono text-[#55738C] mt-1">
                ETA: <span className="font-semibold text-[#063A6B]">{v.eta}</span>
              </div>
            </div>

            {/* 2. LIVE STATUS */}
            <div className="pb-2.5 border-b border-[#EFF9FF]">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[10px] font-bold tracking-wider text-[#55738C]">
                  LIVE STATUS
                </span>
                <span
                  className={`text-[9px] font-mono font-bold px-1.5 py-0.2 rounded ${
                    v.liveAisAvailable
                      ? 'bg-[#18A879]/15 text-[#18A879]'
                      : 'bg-[#0879D1]/12 text-[#0879D1]'
                  }`}
                >
                  {v.liveAisAvailable ? 'LIVE' : 'REGISTRY'}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-y-2 gap-x-3">
                <div>
                  <div className="text-[10px] text-[#55738C]">Position</div>
                  <div className="font-mono font-bold text-[#063A6B] tabular-nums">
                    {v.position.lat.toFixed(4)}°N, {v.position.lng.toFixed(4)}°E
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-[#55738C]">Speed / Heading</div>
                  <div className="font-mono font-bold text-[#063A6B] tabular-nums">
                    {v.speedKts} kn · {v.heading}°
                  </div>
                </div>
                <div className="col-span-2">
                  <div className="text-[10px] text-[#55738C]">AIS Transponder Status</div>
                  <div className="font-mono text-[11px] text-[#063A6B] font-medium">
                    {v.liveAisAvailable
                      ? `Updated ${
                          v.lastAisUpdate
                            ? v.lastAisUpdate.substring(11, 19) + ' UTC'
                            : '<15 sec ago'
                        } (AISStream.io)`
                      : 'Verified Registry Position · Awaiting live AIS packet'}
                  </div>
                </div>
              </div>
            </div>

            {/* 3. FUEL */}
            <div className="pb-2.5 border-b border-[#EFF9FF]">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] font-bold tracking-wider text-[#55738C]">FUEL</span>
                <span className="text-[9px] font-mono font-bold px-1.5 py-0.2 rounded bg-[#0879D1]/12 text-[#0879D1]">
                  CALCULATED
                </span>
              </div>
              <div className="flex items-baseline justify-between">
                <div className="font-mono font-extrabold text-sm text-[#063A6B] tabular-nums">
                  {v.telemetry.fuelConsumptionMtPerDay} MT/day
                </div>
                <div className="font-mono text-[11px] text-[#55738C] tabular-nums">
                  {v.telemetry.fuelRemainingMt} MT remaining
                </div>
              </div>
            </div>

            {/* 4. RISK */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] font-bold tracking-wider text-[#55738C]">RISK</span>
                <span className="text-[9px] font-mono font-bold px-1.5 py-0.2 rounded bg-[#0879D1]/12 text-[#0879D1]">
                  CALCULATED
                </span>
              </div>
              <div
                className={`p-2 rounded-md border flex items-center justify-between ${
                  v.scheduleStatus === 'Critical'
                    ? 'bg-[#FFF5F6] border-[#E84A5A]/30 text-[#E84A5A]'
                    : v.scheduleStatus === 'Warning'
                    ? 'bg-[#FFFBF0] border-[#F3A712]/30 text-[#B87700]'
                    : 'bg-[#F2FBF7] border-[#18A879]/30 text-[#18A879]'
                }`}
              >
                <div className="font-bold text-xs flex items-center gap-1.5">
                  <span>
                    {v.scheduleStatus === 'Critical'
                      ? '🔴 High operational risk — action required'
                      : v.scheduleStatus === 'Warning'
                      ? '🟡 Moderate weather / schedule risk'
                      : '🟢 Low operational risk'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'Route' && (
          <div className="space-y-3 text-xs">
            {/* OPTIMIZED ROUTE EXPLAINABILITY PANEL */}
            <div className="p-3 bg-[#F8FCFF] rounded-md border border-[#B9DDF5] space-y-2.5">
              <div className="flex items-center justify-between border-b border-[#EFF9FF] pb-1.5">
                <span className="font-extrabold text-[#063A6B] tracking-wide">
                  OPTIMIZED ROUTE ANALYSIS
                </span>
                <span className="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded bg-[#7C3AED]/12 text-[#7C3AED]">
                  OPTIMIZATION
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 font-mono text-[11px]">
                <div className="p-2 bg-white rounded border border-[#EFF9FF]">
                  <div className="text-[10px] text-[#55738C] font-sans">Current route</div>
                  <div className="font-bold text-[#063A6B] tabular-nums">
                    {plannedDistanceNm.toLocaleString()} NM
                  </div>
                </div>
                <div className="p-2 bg-white rounded border border-[#EFF9FF]">
                  <div className="text-[10px] text-[#55738C] font-sans">Optimized route</div>
                  <div className="font-bold text-[#7C3AED] tabular-nums">
                    {optimizedDistanceNm.toLocaleString()} NM
                  </div>
                </div>
                <div className="p-2 bg-white rounded border border-[#EFF9FF]">
                  <div className="text-[10px] text-[#55738C] font-sans">Distance delta</div>
                  <div className="font-bold text-[#18A879] tabular-nums">
                    {distanceDeltaNm >= 0
                      ? `${distanceDeltaNm} NM saved`
                      : `+${Math.abs(distanceDeltaNm)} NM current bypass`}
                  </div>
                </div>
                <div className="p-2 bg-white rounded border border-[#EFF9FF]">
                  <div className="text-[10px] text-[#55738C] font-sans">Fuel saved</div>
                  <div className="font-bold text-[#18A879] tabular-nums">-{fuelSavedPct}%</div>
                </div>
              </div>

              {/* WHY THIS ROUTE? Explainability Checklist */}
              <div className="pt-1">
                <div className="text-[10px] font-bold tracking-wider text-[#55738C] mb-1.5">
                  WHY THIS ROUTE?
                </div>
                <div className="space-y-1 text-[11px] text-[#063A6B]">
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#18A879] shrink-0" />
                    <span>
                      Captures +{v.telemetry.currentSpeedKts} kn favorable ocean current vector
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#18A879] shrink-0" />
                    <span>
                      Lower wave resistance ({v.telemetry.waveHeightM}m significant wave height)
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#18A879] shrink-0" />
                    <span>Avoids restricted & high-risk maritime zones</span>
                  </div>
                  {vesselRec && (
                    <div className="flex items-center justify-between pt-1.5 mt-1.5 border-t border-[#EFF9FF] font-mono text-[10px]">
                      <span className="text-[#55738C]">Engine Confidence Score:</span>
                      <span className="font-bold text-[#0879D1]">
                        {vesselRec.modelConfidencePct}% (CALCULATED)
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Waypoints List */}
            <div className="border border-[#B9DDF5] rounded-md divide-y divide-[#EFF9FF]">
              {v.plannedRoute.map((wp, idx) => (
                <div key={idx} className="p-2 flex items-center justify-between text-[11px]">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-[#EFF9FF] border border-[#B9DDF5] text-[10px] font-mono flex items-center justify-center font-bold text-[#0879D1]">
                      {idx + 1}
                    </span>
                    <span className="font-medium text-[#063A6B]">
                      {wp.name || `Waypoint ${idx + 1}`}
                    </span>
                  </div>
                  <span className="font-mono text-[#55738C] tabular-nums">
                    {wp.lat.toFixed(2)}°N, {wp.lng.toFixed(2)}°E
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'Fuel' && (
          <div className="space-y-3 text-xs">
            <div className="p-3 bg-white border border-[#B9DDF5] rounded-md">
              <div className="flex items-center justify-between">
                <span className="text-[10px] uppercase font-bold text-[#55738C]">
                  Specific Fuel Consumption
                </span>
                <span className="text-[9px] font-mono font-bold px-1.5 py-0.2 rounded bg-[#0879D1]/12 text-[#0879D1]">
                  CALCULATED
                </span>
              </div>
              <div className="text-xl font-bold font-mono text-[#063A6B] mt-1 tabular-nums">
                {v.telemetry.fuelConsumptionMtPerDay}{' '}
                <span className="text-xs font-normal text-[#55738C]">MT/day</span>
              </div>
              <div className="text-[11px] text-[#18A879] font-medium mt-1">
                Admiralty Cubic Propulsion Model · SFOC 178 g/kWh
              </div>
            </div>
            <div className="p-3 bg-white border border-[#B9DDF5] rounded-md space-y-2">
              <div className="flex justify-between text-[11px]">
                <span className="text-[#55738C]">Bunker Remaining:</span>
                <span className="font-mono font-bold text-[#063A6B] tabular-nums">
                  {v.telemetry.fuelRemainingMt} MT
                </span>
              </div>
              <div className="flex justify-between text-[11px]">
                <span className="text-[#55738C]">Fuel Grade:</span>
                <span className="font-mono font-bold text-[#0879D1]">
                  {v.specs.fuelType} (Low Sulphur)
                </span>
              </div>
              <div className="flex justify-between text-[11px]">
                <span className="text-[#55738C]">Estimated Daily Bunker Cost:</span>
                <span className="font-mono font-bold text-[#063A6B] tabular-nums">
                  ${(v.telemetry.fuelConsumptionMtPerDay * 645).toLocaleString()} / day
                </span>
              </div>
              <div className="flex justify-between text-[11px] pt-1 border-t border-[#EFF9FF]">
                <span className="text-[#55738C]">CO₂ Output (IMO CII):</span>
                <span className="font-mono font-bold text-[#18A879] tabular-nums">
                  {v.telemetry.co2EmissionsTonsPerDay} t/day
                </span>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'Cargo' && (
          <div className="space-y-3 text-xs">
            <div className="p-3 bg-white border border-[#B9DDF5] rounded-md">
              <div className="flex items-center justify-between">
                <span className="text-[10px] uppercase font-bold text-[#55738C]">
                  Manifest Summary
                </span>
                <span className="text-[9px] font-mono font-bold px-1.5 py-0.2 rounded bg-[#0879D1]/12 text-[#0879D1]">
                  CALCULATED
                </span>
              </div>
              <div className="font-bold text-[#063A6B] mt-1">{v.cargoDescription}</div>
              <div className="text-[11px] text-[#55738C] mt-1 font-mono">
                Deadweight Capacity: {v.specs.deadweightTons.toLocaleString()} DWT
              </div>
            </div>
            <div className="p-3 bg-white border border-[#B9DDF5] rounded-md space-y-2">
              <div className="flex justify-between text-[11px]">
                <span className="text-[#55738C]">Draft (Current / Max):</span>
                <span className="font-mono font-bold text-[#063A6B] tabular-nums">
                  {v.specs.draftM}m / 15.5m
                </span>
              </div>
              <div className="flex justify-between text-[11px]">
                <span className="text-[#55738C]">Cargo Utilization:</span>
                <span className="font-mono font-bold text-[#0879D1] tabular-nums">
                  {v.cargoUtilizationPct}%
                </span>
              </div>
              <div className="w-full bg-[#EFF9FF] h-1.5 rounded-full overflow-hidden border border-[#B9DDF5]/40">
                <div
                  className="bg-[#0879D1] h-full rounded-full"
                  style={{ width: `${v.cargoUtilizationPct}%` }}
                />
              </div>
            </div>
          </div>
        )}

        {activeTab === 'Weather' && (
          <div className="space-y-3 text-xs">
            <div className="p-3 bg-white border border-[#B9DDF5] rounded-md space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] uppercase font-bold text-[#55738C]">
                  Open-Meteo Marine Observation
                </span>
                <span className="text-[9px] font-mono font-bold px-1.5 py-0.2 rounded bg-[#18A879]/15 text-[#18A879]">
                  LIVE / PREDICTED
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2 font-mono text-[11px]">
                <div className="p-2 bg-[#F8FCFF] border border-[#EFF9FF] rounded">
                  <div className="text-[#55738C] text-[10px] font-sans">Wind Vector</div>
                  <div className="font-bold text-[#063A6B] tabular-nums">
                    {v.telemetry.windSpeedKts} kn @ {v.telemetry.windDirectionDeg}°
                  </div>
                </div>
                <div className="p-2 bg-[#F8FCFF] border border-[#EFF9FF] rounded">
                  <div className="text-[#55738C] text-[10px] font-sans">Significant Wave</div>
                  <div className="font-bold text-[#063A6B] tabular-nums">
                    {v.telemetry.waveHeightM} m swell
                  </div>
                </div>
                <div className="p-2 bg-[#F8FCFF] border border-[#EFF9FF] rounded">
                  <div className="text-[#55738C] text-[10px] font-sans">Ocean Current</div>
                  <div className="font-bold text-[#0879D1] tabular-nums">
                    {v.telemetry.currentSpeedKts} kn drift
                  </div>
                </div>
                <div className="p-2 bg-[#F8FCFF] border border-[#EFF9FF] rounded">
                  <div className="text-[#55738C] text-[10px] font-sans">Sea Surface Temp</div>
                  <div className="font-bold text-[#063A6B] tabular-nums">
                    {v.telemetry.seaTemperatureC}°C
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'History' && (
          <div className="space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase font-bold text-[#55738C]">
                Recent Port Calls & Bunker Log
              </span>
              <span className="text-[9px] font-mono font-bold px-1.5 py-0.2 rounded bg-[#55738C]/15 text-[#55738C]">
                HISTORICAL
              </span>
            </div>
            <div className="border border-[#B9DDF5] rounded-md divide-y divide-[#EFF9FF]">
              <div className="p-2.5">
                <div className="font-bold text-[#063A6B]">{v.origin}</div>
                <div className="text-[10px] text-[#55738C]">
                  Last Departure Port · {v.cargoUtilizationPct}% Cargo Load Verified
                </div>
              </div>
              <div className="p-2.5">
                <div className="font-bold text-[#063A6B]">Bunker & SFOC Audit</div>
                <div className="text-[10px] text-[#55738C]">
                  Historical Fuel Usage: {v.telemetry.fuelConsumptionMtPerDay} MT/day baseline
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer Quick Navigation Links */}
      <div className="p-3 border-t border-[#B9DDF5] bg-[#F8FCFF] flex items-center justify-between text-xs">
        <button
          type="button"
          onClick={() => setCurrentPath('/vessels')}
          className="text-[#0879D1] font-semibold hover:underline flex items-center gap-1 cursor-pointer"
        >
          <span>Full Vessel Registry</span>
          <ArrowRight className="w-3 h-3" />
        </button>
        <button
          type="button"
          onClick={() => setCurrentPath('/routes')}
          className="text-[#063A6B] font-semibold hover:text-[#0879D1] flex items-center gap-1 cursor-pointer"
        >
          <span>Voyage Corridors</span>
          <ExternalLink className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
};
