import React from 'react';
import {
  Ship,
  Navigation,
  AlertTriangle,
  Fuel,
  DollarSign,
  BarChart,
  ArrowDownRight,
  ArrowUpRight
} from 'lucide-react';
import { useMaritime } from '../../context/MaritimeContext';

interface KpiCardsRowProps {
  onSelectRiskFilter?: () => void;
}

export const KpiCardsRow: React.FC<KpiCardsRowProps> = ({ onSelectRiskFilter }) => {
  const { vessels, setCurrentPath } = useMaritime();

  const totalFleetCapacity = Math.max(vessels.length + 4, 28);
  const activeVesselsCount = vessels.length;
  const deployedPct = ((activeVesselsCount / totalFleetCapacity) * 100).toFixed(1);

  const inTransitCount = vessels.filter((v) => v.status === 'IN TRANSIT').length;
  const berthedOrAnchoredCount = vessels.length - inTransitCount;

  const criticalCount = vessels.filter((v) => v.scheduleStatus === 'Critical').length;
  const warningCount = vessels.filter((v) => v.scheduleStatus === 'Warning').length;
  const atRiskCount = criticalCount + warningCount;

  const totalFuelBurnNum = vessels.reduce(
    (sum, v) => sum + v.telemetry.fuelConsumptionMtPerDay,
    0
  );
  const totalFuelBurn = totalFuelBurnNum.toLocaleString('en-US', {
    minimumFractionDigits: 1,
    maximumFractionDigits: 1
  });

  const totalFuelCost = Math.round(totalFuelBurnNum * 645);
  const potentialFuelSavingDollars = ((totalFuelCost * 0.086) / 1000).toFixed(1);

  const avgUtilization =
    vessels.length > 0
      ? (
          vessels.reduce((sum, v) => sum + v.cargoUtilizationPct, 0) / vessels.length
        ).toFixed(1)
      : '94.2';

  const cards = [
    {
      id: 'active-vessels',
      label: 'ACTIVE VESSELS',
      value: `${activeVesselsCount} / ${totalFleetCapacity}`,
      subtext: `${deployedPct}% deployed`,
      dataTag: 'LIVE' as const,
      trend: 'positive' as const,
      icon: Ship,
      accent: 'text-[#0879D1]',
      onClick: () => setCurrentPath('/vessels')
    },
    {
      id: 'in-transit',
      label: 'IN TRANSIT',
      value: `${inTransitCount}`,
      subtext: `+${berthedOrAnchoredCount} berthed/anchored`,
      dataTag: 'LIVE' as const,
      trend: 'positive' as const,
      icon: Navigation,
      accent: 'text-[#063A6B]',
      onClick: () => setCurrentPath('/routes')
    },
    {
      id: 'vessels-at-risk',
      label: 'VESSELS AT RISK',
      value: `${atRiskCount}`,
      subtext: `${criticalCount} critical · ${warningCount} warning`,
      dataTag: 'LIVE' as const,
      trend: atRiskCount > 0 ? ('warning' as const) : ('positive' as const),
      icon: AlertTriangle,
      accent: criticalCount > 0 ? 'text-[#E84A5A]' : 'text-[#F3A712]',
      isRiskCard: atRiskCount > 0,
      onClick: () => {
        if (onSelectRiskFilter) {
          onSelectRiskFilter();
        } else {
          setCurrentPath('/alerts');
        }
      }
    },
    {
      id: 'fuel-consumption',
      label: 'FUEL CONSUMPTION',
      value: `${totalFuelBurn} MT`,
      subtext: '-8.6% with optimization',
      dataTag: 'CALCULATED' as const,
      trend: 'positive' as const,
      icon: Fuel,
      accent: 'text-[#0879D1]',
      onClick: () => setCurrentPath('/fuel')
    },
    {
      id: 'daily-fuel-cost',
      label: 'DAILY FUEL COST',
      value: `$${(totalFuelCost / 1000).toLocaleString('en-US', {
        minimumFractionDigits: 1,
        maximumFractionDigits: 1
      })}k`,
      subtext: `Potential saving: $${potentialFuelSavingDollars}k`,
      dataTag: 'CALCULATED' as const,
      trend: 'positive' as const,
      icon: DollarSign,
      accent: 'text-[#063A6B]',
      onClick: () => setCurrentPath('/fuel')
    },
    {
      id: 'fleet-utilization',
      label: 'FLEET UTILIZATION',
      value: `${avgUtilization}%`,
      subtext: '+3.1% cargo load',
      dataTag: 'CALCULATED' as const,
      trend: 'positive' as const,
      icon: BarChart,
      accent: 'text-[#18A879]',
      onClick: () => setCurrentPath('/cargo')
    }
  ];

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
      {cards.map((card) => {
        const Icon = card.icon;
        return (
          <button
            key={card.id}
            type="button"
            onClick={card.onClick}
            className={`text-left p-2.5 sm:p-3 bg-white border rounded-lg shadow-xs flex flex-col justify-between transition-all hover:shadow-sm group cursor-pointer ${
              card.isRiskCard
                ? 'border-[#E84A5A]/40 hover:border-[#E84A5A] bg-gradient-to-b from-[#FFF8F9] to-white'
                : 'border-[#B9DDF5] hover:border-[#0879D1]'
            }`}
          >
            <div className="flex items-center justify-between gap-1 mb-1">
              <span className="text-[10px] font-bold tracking-wider text-[#55738C] truncate">
                {card.label}
              </span>
              <div className="flex items-center gap-1 shrink-0">
                <span
                  className={`text-[8px] font-mono font-bold px-1 py-0.2 rounded ${
                    card.dataTag === 'LIVE'
                      ? 'bg-[#18A879]/12 text-[#18A879]'
                      : 'bg-[#0879D1]/12 text-[#0879D1]'
                  }`}
                >
                  {card.dataTag}
                </span>
                <Icon className={`w-3.5 h-3.5 ${card.accent}`} />
              </div>
            </div>

            <div
              className={`text-base sm:text-lg font-extrabold font-mono tabular-nums tracking-tight truncate ${
                card.isRiskCard ? 'text-[#E84A5A]' : 'text-[#063A6B]'
              }`}
            >
              {card.value}
            </div>

            <div className="text-[10px] text-[#55738C] mt-1 flex items-center gap-1 truncate">
              {card.trend === 'warning' ? (
                <ArrowUpRight className="w-3 h-3 text-[#E84A5A] shrink-0" />
              ) : (
                <ArrowDownRight className="w-3 h-3 text-[#18A879] shrink-0" />
              )}
              <span className="truncate font-medium">{card.subtext}</span>
            </div>
          </button>
        );
      })}
    </div>
  );
};
