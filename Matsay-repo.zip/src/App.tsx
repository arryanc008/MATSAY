import React, { useEffect } from 'react';
import { MaritimeProvider, useMaritime } from './context/MaritimeContext';
import { Sidebar } from './components/common/Sidebar';
import { Header } from './components/common/Header';
import { BottomNav } from './components/common/BottomNav';
import { MobileOpsModal } from './components/common/MobileOpsModal';
import { LoginPage } from './pages/LoginPage';
import { CommandCenterPage } from './pages/CommandCenterPage';
import { FleetMapPage } from './pages/FleetMapPage';
import { VesselsPage } from './pages/VesselsPage';
import { OptimizationPage } from './pages/OptimizationPage';
import { RoutesPage } from './pages/RoutesPage';
import { CargoPage } from './pages/CargoPage';
import { FuelPage } from './pages/FuelPage';
import { WeatherPage } from './pages/WeatherPage';
import { SustainabilityPage } from './pages/SustainabilityPage';
import { AlertsPage } from './pages/AlertsPage';
import { CommunicationsPage } from './pages/CommunicationsPage';
import { ScenariosPage } from './pages/ScenariosPage';
import { AnalyticsPage } from './pages/AnalyticsPage';
import { MatsayOpsPage } from './pages/MatsayOpsPage';

const AppContent: React.FC = () => {
  const { session, currentPath, setCurrentPath } = useMaritime();

  // Sync with browser url path if set
  useEffect(() => {
    const handlePopState = () => {
      const path = window.location.pathname;
      if (path && path !== '/') {
        setCurrentPath(path);
      }
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [setCurrentPath]);

  // Keep URL updated for clean navigation
  useEffect(() => {
    if (window.location.pathname !== currentPath) {
      window.history.pushState(null, '', currentPath);
    }
  }, [currentPath]);

  if (!session.isAuthenticated || currentPath === '/login') {
    return <LoginPage />;
  }

  const renderActivePage = () => {
    switch (currentPath) {
      case '/command-center':
        return <CommandCenterPage />;
      case '/map':
        return <FleetMapPage />;
      case '/vessels':
        return <VesselsPage />;
      case '/optimization':
        return <OptimizationPage />;
      case '/routes':
        return <RoutesPage />;
      case '/cargo':
        return <CargoPage />;
      case '/fuel':
        return <FuelPage />;
      case '/weather':
        return <WeatherPage />;
      case '/sustainability':
        return <SustainabilityPage />;
      case '/alerts':
        return <AlertsPage />;
      case '/communications':
        return <CommunicationsPage />;
      case '/scenarios':
        return <ScenariosPage />;
      case '/analytics':
        return <AnalyticsPage />;
      case '/ops':
        return <MatsayOpsPage />;
      default:
        return <CommandCenterPage />;
    }
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#F4FBFF] text-[#063A6B]">
      {/* Dark Navy Sidebar (Desktop & Tablet Compact, Mobile Drawer) */}
      <Sidebar />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-full overflow-hidden min-w-0">
        {/* Light Blue / White Operational Header */}
        <Header />

        {/* Scrollable Viewport Content */}
        <main className="flex-1 overflow-y-auto p-3 sm:p-4 lg:p-6 pb-20 md:pb-6 bg-[#F4FBFF]">
          <div className="max-w-[1920px] mx-auto">
            {renderActivePage()}
          </div>
        </main>

        {/* Mobile Bottom Navigation (Only on mobile < md) */}
        <BottomNav />

        {/* Mobile Floating AI Assistant & Sheet */}
        <MobileOpsModal />
      </div>
    </div>
  );
};

export default function App() {
  return (
    <MaritimeProvider>
      <AppContent />
    </MaritimeProvider>
  );
}
