export type VesselType = 'Container' | 'Tanker' | 'Bulk Carrier' | 'LNG' | 'Cargo';

export type VesselStatus = 'IN TRANSIT' | 'AT ANCHOR' | 'MOORED' | 'DRIFTING' | 'MAINTENANCE';

export type RiskLevel = 'Normal' | 'Warning' | 'Critical';

export interface Coordinates {
  lat: number;
  lng: number;
}

export interface Waypoint extends Coordinates {
  name?: string;
  speedLimit?: number;
  weatherRisk?: 'Low' | 'Moderate' | 'High';
  distanceFromStartNm?: number;
}

export interface VesselSpecs {
  lengthM: number;
  beamM: number;
  draftM: number;
  deadweightTons: number;
  capacityTeuOrM3: string;
  fuelType: 'VLSFO' | 'MGO' | 'LNG' | 'Methanol' | 'Ammonia';
  mainEngine: string;
  operatingSpeedKts: number;
  builtYear: number;
  flag: string;
}

export interface VesselTelemetry {
  fuelRemainingMt: number;
  fuelConsumptionMtPerDay: number;
  co2EmissionsTonsPerDay: number;
  engineRpm: number;
  engineLoadPct: number;
  shaftPowerKw: number;
  waterDepthM: number;
  seaTemperatureC: number;
  airTemperatureC: number;
  windSpeedKts: number;
  windDirectionDeg: number;
  waveHeightM: number;
  currentSpeedKts: number;
  currentDirectionDeg: number;
}

export interface Vessel {
  id: string;
  name: string;
  imo: string;
  mmsi?: string;
  type: VesselType;
  status: VesselStatus;
  scheduleStatus: 'On Schedule' | 'Warning' | 'Critical';
  position: Coordinates;
  heading: number; // 0-359 deg
  speedKts: number;
  destination: string;
  origin: string;
  eta: string;
  etd: string;
  cargoDescription: string;
  cargoUtilizationPct: number;
  specs: VesselSpecs;
  telemetry: VesselTelemetry;
  plannedRoute: Waypoint[];
  optimizedRoute?: Waypoint[];
  recommendationPending?: boolean;
  liveAisAvailable?: boolean;
  dataQuality?: 'LIVE_AIS' | 'AUTHORITATIVE_REGISTRY';
  lastAisUpdate?: string;
}

export interface IntegrationStatus {
  metocean: {
    provider: string;
    isLive: boolean;
    source: string;
    lastObservation: string;
  };
  ais: {
    isConfigured: boolean;
    provider: string;
    status: 'LIVE_STREAM_ACTIVE' | 'UNAVAILABLE' | 'CONNECTING' | 'RECONNECTING' | 'ERROR';
    message: string;
  };
  database: {
    type: string;
    status: string;
  };
}

export interface Port {
  id: string;
  name: string;
  country: string;
  coordinates: Coordinates;
  code: string;
  berthsAvailable: number;
  averageWaitHours: number;
  currentVesselsCount: number;
}

export interface RestrictedZone {
  id: string;
  name: string;
  type: 'Piracy High Risk Area' | 'Marine Protected Area' | 'Military Exercise' | 'ECA Emission Control';
  coordinates: Coordinates[];
  severity: 'Warning' | 'Restricted' | 'Strict Speed Limit';
  notes: string;
}

export interface StormSystem {
  id: string;
  name: string;
  category: 'Tropical Depression' | 'Tropical Storm' | 'Cyclone Cat 1' | 'Cyclone Cat 2' | 'Cyclone Cat 3';
  coordinates: Coordinates;
  radiusNm: number;
  maxWindKts: number;
  movementSpeedKts: number;
  headingDeg: number;
}

export interface OptimizationWeights {
  fuel: number; // 0-100
  cost: number;
  co2: number;
  time: number;
  utilization: number;
  reliability: number;
}

export interface OptimizationConstraints {
  vesselCapacity: boolean;
  vesselAvailability: boolean;
  deliveryDeadline: boolean;
  fuelAvailability: boolean;
  portConstraints: boolean;
  routeRestrictions: boolean;
  emissionLimits: boolean;
  weatherRiskThreshold: number; // 1-5
}

export interface ParetoSolution {
  id: string;
  label: string;
  fuelMt: number;
  costUsd: number;
  co2Tons: number;
  durationHours: number;
  scheduleReliabilityPct: number;
  quantumFitnessScore: number;
  focus: 'Fuel-focused' | 'Balanced' | 'Emission-focused' | 'Time-focused';
}

export interface OptimizationResult {
  runId: string;
  timestamp: string;
  algorithm: 'Quantum-Inspired PSO' | 'Classical GA' | 'Standard PSO';
  convergenceIterations: number;
  executionTimeMs: number;
  currentPlan: {
    totalFuelMt: number;
    totalCostUsd: number;
    totalCo2Tons: number;
    averageEtaHours: number;
    fleetUtilizationPct: number;
    scheduleReliabilityPct: number;
  };
  optimizedPlan: {
    totalFuelMt: number;
    totalCostUsd: number;
    totalCo2Tons: number;
    averageEtaHours: number;
    fleetUtilizationPct: number;
    scheduleReliabilityPct: number;
  };
  delta: {
    fuelPct: number;
    costPct: number;
    co2Pct: number;
    timePct: number;
    reliabilityPct: number;
    utilizationPct: number;
  };
  paretoFront: ParetoSolution[];
  recommendations: Array<{
    id: string;
    vesselId: string;
    vesselName: string;
    action: string;
    reason: string;
    expectedImpact: string;
    modelConfidencePct: number;
    status: 'PENDING' | 'APPROVED' | 'MODIFIED' | 'REJECTED';
  }>;
}

export interface AlertItem {
  id: string;
  category: 'Critical' | 'Warning' | 'Information' | 'Resolved';
  title: string;
  description: string;
  vesselId?: string;
  vesselName?: string;
  timestamp: string;
  acknowledged: boolean;
  actionRequired?: string;
}

export interface CommunicationMessage {
  id: string;
  channel: 'Fleet-wide' | 'Vessel-specific' | 'Operations' | 'Weather' | 'Emergency';
  sender: string;
  recipient: string;
  subject: string;
  body: string;
  timestamp: string;
  status: 'SENT' | 'DELIVERED' | 'READ';
  urgent: boolean;
}

export interface UserSession {
  isAuthenticated: boolean;
  user: {
    id: string;
    name: string;
    rank: string;
    email: string;
    assignedRegion: string;
    clearanceLevel: string;
    avatarUrl?: string;
  } | null;
}
