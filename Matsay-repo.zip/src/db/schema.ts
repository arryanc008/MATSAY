import { pgTable, serial, text, integer, boolean, timestamp } from 'drizzle-orm/pg-core';

// Users table authenticated via Firebase Auth
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  uid: text('uid').notNull().unique(), // Firebase Auth UID
  email: text('email').notNull(),
  displayName: text('display_name'),
  role: text('role').default('Fleet Commander'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Authoritative Fleet Vessels Table
export const vessels = pgTable('vessels', {
  id: text('id').primaryKey(),
  imo: text('imo').notNull().unique(),
  mmsi: text('mmsi'),
  name: text('name').notNull(),
  type: text('type').notNull(),
  status: text('status').notNull(),
  scheduleStatus: text('schedule_status').notNull(),
  lat: text('lat').notNull(),
  lng: text('lng').notNull(),
  heading: integer('heading').notNull(),
  speedKts: text('speed_kts').notNull(),
  origin: text('origin').notNull(),
  destination: text('destination').notNull(),
  eta: text('eta').notNull(),
  cargoDescription: text('cargo_description').notNull(),
  cargoUtilizationPct: integer('cargo_utilization_pct').notNull(),
  deadweightTons: integer('deadweight_tons').notNull(),
  lengthM: text('length_m').notNull(),
  beamM: text('beam_m').notNull(),
  draftM: text('draft_m').notNull(),
  fuelType: text('fuel_type').notNull(),
  mainEngine: text('main_engine').notNull(),
  fuelRemainingMt: text('fuel_remaining_mt').notNull(),
  fuelConsumptionMtPerDay: text('fuel_consumption_mt_per_day').notNull(),
  co2EmissionsTonsPerDay: text('co2_emissions_tons_per_day').notNull(),
  liveAisAvailable: boolean('live_ais_available').default(false),
  lastAisUpdate: timestamp('last_ais_update').defaultNow(),
});

// Authoritative World Ports Table (UN/LOCODE)
export const ports = pgTable('ports', {
  id: text('id').primaryKey(),
  code: text('code').notNull().unique(),
  name: text('name').notNull(),
  country: text('country').notNull(),
  lat: text('lat').notNull(),
  lng: text('lng').notNull(),
  berthsAvailable: integer('berths_available').notNull(),
  averageWaitHours: text('average_wait_hours').notNull(),
});

// Real MetOcean Weather Observation & Forecast Cache (Open-Meteo API)
export const weatherCache = pgTable('weather_cache', {
  id: serial('id').primaryKey(),
  lat: text('lat').notNull(),
  lng: text('lng').notNull(),
  waveHeightM: text('wave_height_m').notNull(),
  waveDirectionDeg: integer('wave_direction_deg'),
  windSpeedKts: text('wind_speed_kts').notNull(),
  windDirectionDeg: integer('wind_direction_deg'),
  currentSpeedKts: text('current_speed_kts').notNull(),
  seaTempC: text('sea_temp_c'),
  source: text('source').notNull(), // 'OPEN_METEO_MARINE_API'
  cachedAt: timestamp('cached_at').defaultNow(),
});

// Operational Incidents & Alerts Table
export const alerts = pgTable('alerts', {
  id: text('id').primaryKey(),
  category: text('category').notNull(),
  title: text('title').notNull(),
  description: text('description').notNull(),
  vesselId: text('vessel_id'),
  vesselName: text('vessel_name'),
  acknowledged: boolean('acknowledged').default(false),
  actionRequired: text('action_required'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Operational Dispatch Communications Table
export const communications = pgTable('communications', {
  id: text('id').primaryKey(),
  channel: text('channel').notNull(),
  sender: text('sender').notNull(),
  recipient: text('recipient').notNull(),
  subject: text('subject').notNull(),
  body: text('body').notNull(),
  urgent: boolean('urgent').default(false),
  status: text('status').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

// Admiralty Human-in-the-Loop Audit Trail Table
export const auditLogs = pgTable('audit_logs', {
  id: text('id').primaryKey(),
  timestamp: text('timestamp').notNull(),
  commanderName: text('commander_name').notNull(),
  recommendationId: text('recommendation_id').notNull(),
  vesselName: text('vessel_name').notNull(),
  action: text('action').notNull(),
  notes: text('notes'),
});

// Quantum-Inspired Fleet Optimization Runs Table
export const optimizationRuns = pgTable('optimization_runs', {
  id: text('id').primaryKey(),
  runId: text('run_id').notNull(),
  algorithm: text('algorithm').notNull(),
  weights: text('weights').notNull(),
  currentPlan: text('current_plan').notNull(),
  optimizedPlan: text('optimized_plan').notNull(),
  delta: text('delta').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});
