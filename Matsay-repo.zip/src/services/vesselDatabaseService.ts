import { db, isDatabaseConfigured } from '../db/index.ts';
import {
  vessels as vesselsTable,
  ports as portsTable,
  alerts as alertsTable,
  communications as communicationsTable,
  auditLogs as auditLogsTable
} from '../db/schema.ts';
import { desc, eq } from 'drizzle-orm';
import {
  INITIAL_VESSELS,
  INITIAL_PORTS,
  INITIAL_ALERTS,
  INITIAL_COMMUNICATIONS
} from '../data/mockMaritimeData.ts';

export async function initializeDatabaseSeedIfEmpty() {
  if (!isDatabaseConfigured()) {
    return;
  }
  try {
    const existingVessels = await db.select().from(vesselsTable).limit(1);
    if (existingVessels.length === 0) {
      for (const v of INITIAL_VESSELS) {
        await db
          .insert(vesselsTable)
          .values({
            id: v.id,
            imo: v.imo,
            mmsi: v.mmsi || null,
            name: v.name,
            type: v.type,
            status: v.status,
            scheduleStatus: v.scheduleStatus,
            lat: String(v.position.lat),
            lng: String(v.position.lng),
            heading: v.heading,
            speedKts: String(v.speedKts),
            origin: v.origin,
            destination: v.destination,
            eta: v.eta,
            cargoDescription: v.cargoDescription,
            cargoUtilizationPct: v.cargoUtilizationPct,
            deadweightTons: v.specs.deadweightTons,
            lengthM: String(v.specs.lengthM),
            beamM: String(v.specs.beamM),
            draftM: String(v.specs.draftM),
            fuelType: v.specs.fuelType,
            mainEngine: v.specs.mainEngine,
            fuelRemainingMt: String(v.telemetry.fuelRemainingMt),
            fuelConsumptionMtPerDay: String(v.telemetry.fuelConsumptionMtPerDay),
            co2EmissionsTonsPerDay: String(v.telemetry.co2EmissionsTonsPerDay),
            liveAisAvailable: false
          })
          .onConflictDoNothing();
      }
    }

    const existingPorts = await db.select().from(portsTable).limit(1);
    if (existingPorts.length === 0) {
      for (const p of INITIAL_PORTS) {
        await db
          .insert(portsTable)
          .values({
            id: p.id,
            code: p.code,
            name: p.name,
            country: p.country,
            lat: String(p.coordinates.lat),
            lng: String(p.coordinates.lng),
            berthsAvailable: p.berthsAvailable,
            averageWaitHours: String(p.averageWaitHours)
          })
          .onConflictDoNothing();
      }
    }

    const existingAlerts = await db.select().from(alertsTable).limit(1);
    if (existingAlerts.length === 0) {
      for (const a of INITIAL_ALERTS) {
        await db
          .insert(alertsTable)
          .values({
            id: a.id,
            category: a.category,
            title: a.title,
            description: a.description,
            vesselId: a.vesselId,
            vesselName: a.vesselName,
            acknowledged: a.acknowledged,
            actionRequired: a.actionRequired
          })
          .onConflictDoNothing();
      }
    }

    const existingComms = await db.select().from(communicationsTable).limit(1);
    if (existingComms.length === 0) {
      for (const c of INITIAL_COMMUNICATIONS) {
        await db
          .insert(communicationsTable)
          .values({
            id: c.id,
            channel: c.channel,
            sender: c.sender,
            recipient: c.recipient,
            subject: c.subject,
            body: c.body,
            urgent: c.urgent,
            status: c.status
          })
          .onConflictDoNothing();
      }
    }
  } catch (err) {
    console.warn('Database seeding skipped or deferred.');
  }
}

export async function getAllVessels() {
  if (!isDatabaseConfigured()) {
    return INITIAL_VESSELS.map((v) => ({
      id: v.id,
      imo: v.imo,
      mmsi: v.mmsi || null,
      name: v.name,
      type: v.type,
      status: v.status,
      scheduleStatus: v.scheduleStatus,
      lat: String(v.position.lat),
      lng: String(v.position.lng),
      heading: v.heading,
      speedKts: String(v.speedKts),
      origin: v.origin,
      destination: v.destination,
      eta: v.eta,
      cargoDescription: v.cargoDescription,
      cargoUtilizationPct: v.cargoUtilizationPct,
      deadweightTons: v.specs.deadweightTons,
      lengthM: String(v.specs.lengthM),
      beamM: String(v.specs.beamM),
      draftM: String(v.specs.draftM),
      fuelType: v.specs.fuelType,
      mainEngine: v.specs.mainEngine,
      fuelRemainingMt: String(v.telemetry.fuelRemainingMt),
      fuelConsumptionMtPerDay: String(v.telemetry.fuelConsumptionMtPerDay),
      co2EmissionsTonsPerDay: String(v.telemetry.co2EmissionsTonsPerDay),
      liveAisAvailable: false
    }));
  }
  try {
    return await db.select().from(vesselsTable);
  } catch (err) {
    throw new Error('Vessel data temporarily unavailable');
  }
}

export async function getAllPorts() {
  if (!isDatabaseConfigured()) {
    return INITIAL_PORTS.map((p) => ({
      id: p.id,
      code: p.code,
      name: p.name,
      country: p.country,
      lat: String(p.coordinates.lat),
      lng: String(p.coordinates.lng),
      berthsAvailable: p.berthsAvailable,
      averageWaitHours: String(p.averageWaitHours)
    }));
  }
  try {
    return await db.select().from(portsTable);
  } catch (err) {
    throw new Error('Port data temporarily unavailable');
  }
}

export async function getAllAlerts() {
  if (!isDatabaseConfigured()) {
    return INITIAL_ALERTS;
  }
  try {
    return await db.select().from(alertsTable).orderBy(desc(alertsTable.createdAt));
  } catch (err) {
    throw new Error('Alert data temporarily unavailable');
  }
}

export async function acknowledgeAlertInDb(id: string) {
  if (!isDatabaseConfigured()) {
    return;
  }
  try {
    await db
      .update(alertsTable)
      .set({ acknowledged: true, category: 'Resolved' })
      .where(eq(alertsTable.id, id));
  } catch (err) {
    throw new Error('Failed to update alert');
  }
}

export async function getAllCommunications() {
  if (!isDatabaseConfigured()) {
    return INITIAL_COMMUNICATIONS;
  }
  try {
    return await db
      .select()
      .from(communicationsTable)
      .orderBy(desc(communicationsTable.createdAt));
  } catch (err) {
    throw new Error('Communications temporarily unavailable');
  }
}

export async function insertCommunication(msg: {
  id: string;
  channel: string;
  sender: string;
  recipient: string;
  subject: string;
  body: string;
  urgent: boolean;
  status: string;
}) {
  if (!isDatabaseConfigured()) {
    return;
  }
  try {
    await db.insert(communicationsTable).values(msg);
  } catch (err) {
    throw new Error('Failed to save communication');
  }
}

export async function recordAuditLog(entry: {
  id: string;
  timestamp: string;
  commanderName: string;
  recommendationId: string;
  vesselName: string;
  action: string;
  notes?: string;
}) {
  if (!isDatabaseConfigured()) {
    return;
  }
  try {
    await db.insert(auditLogsTable).values(entry);
  } catch (err) {
    throw new Error('Failed to save audit log');
  }
}

export async function getAuditLogs() {
  if (!isDatabaseConfigured()) {
    return [];
  }
  try {
    return await db.select().from(auditLogsTable);
  } catch (err) {
    throw new Error('Audit logs temporarily unavailable');
  }
}
