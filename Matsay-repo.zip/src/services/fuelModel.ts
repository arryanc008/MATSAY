import { Vessel, VesselSpecs } from '../types/maritime';

export interface FuelPredictionInput {
  vessel: Vessel;
  speedKts: number;
  cargoLoadPct: number;
  distanceNm: number;
  windSpeedKts: number;
  windAngleRelDeg: number; // 0 = headwind, 180 = following wind
  waveHeightM: number;
  currentSpeedKts: number;
  currentAngleRelDeg: number; // 0 = adverse, 180 = favorable
  fuelType: VesselSpecs['fuelType'];
  fuelPricePerMtUsd?: number;
}

export interface FuelPredictionResult {
  estimatedDurationHours: number;
  speedOverGroundKts: number;
  predictedFuelMtPerDay: number;
  totalPredictedFuelMt: number;
  fuelCostUsd: number;
  co2EmissionsTons: number;
  admiraltyCoefficient: number;
  weatherFuelPenaltyPct: number;
  currentBenefitKts: number;
  sfocGramsPerKwh: number;
}

const FUEL_CO2_FACTORS: Record<VesselSpecs['fuelType'], number> = {
  VLSFO: 3.114,
  MGO: 3.206,
  LNG: 2.750,
  Methanol: 1.375,
  Ammonia: 0.05
};

const DEFAULT_FUEL_PRICES: Record<VesselSpecs['fuelType'], number> = {
  VLSFO: 645,
  MGO: 820,
  LNG: 580,
  Methanol: 710,
  Ammonia: 950
};

export function calculateFuelPrediction(input: FuelPredictionInput): FuelPredictionResult {
  const {
    vessel,
    speedKts,
    cargoLoadPct,
    distanceNm,
    windSpeedKts,
    windAngleRelDeg,
    waveHeightM,
    currentSpeedKts,
    currentAngleRelDeg,
    fuelType,
    fuelPricePerMtUsd
  } = input;

  // 1. Current component along vessel heading (positive = favorable, negative = adverse)
  const currentBenefitKts = currentSpeedKts * Math.cos((currentAngleRelDeg * Math.PI) / 180);
  const speedOverGroundKts = Math.max(4, speedKts + currentBenefitKts);

  // 2. Base Admiralty formulation: Power proportional to Displacement^(2/3) * Speed^3
  const displacementTons = (vessel.specs.deadweightTons * 1.15) * (0.4 + (cargoLoadPct / 100) * 0.6);
  const admiraltyCoeff = 580; // Standard modern hull form benchmark

  // Base shaft power in kW in calm water
  const calmPowerKw = (Math.pow(displacementTons, 2 / 3) * Math.pow(speedKts, 3)) / admiraltyCoeff;

  // 3. Weather resistance modeling (empirical Kwon / ISO 15016 approximation)
  // Headwind penalty: maximum when relative wind angle is near 0 deg
  const windAngleFactor = Math.max(0, Math.cos((windAngleRelDeg * Math.PI) / 180));
  const addedWindResistancePct = (Math.pow(windSpeedKts / 20, 1.8) * windAngleFactor * 7.5);

  // Wave resistance penalty: proportional to wave height squared
  const addedWaveResistancePct = Math.pow(waveHeightM / 1.5, 1.6) * 6.2;

  const weatherFuelPenaltyPct = Math.max(0, addedWindResistancePct + addedWaveResistancePct);

  // Total required power including weather
  const totalPowerKw = calmPowerKw * (1 + weatherFuelPenaltyPct / 100);

  // 4. Specific Fuel Oil Consumption (SFOC)
  const sfocGramsPerKwh = fuelType === 'LNG' ? 165 : fuelType === 'Methanol' ? 290 : 178;

  // Fuel consumption per day (MT/day) = (Power kW * SFOC g/kWh * 24 h) / 1,000,000
  const predictedFuelMtPerDay = (totalPowerKw * sfocGramsPerKwh * 24) / 1_000_000;

  // Voyage duration in hours
  const estimatedDurationHours = distanceNm / Math.max(1, speedOverGroundKts);

  // Total voyage fuel in Metric Tons
  const totalPredictedFuelMt = (predictedFuelMtPerDay / 24) * estimatedDurationHours;

  // Economics & Environmental
  const price = fuelPricePerMtUsd ?? DEFAULT_FUEL_PRICES[fuelType];
  const fuelCostUsd = totalPredictedFuelMt * price;
  const co2Factor = FUEL_CO2_FACTORS[fuelType];
  const co2EmissionsTons = totalPredictedFuelMt * co2Factor;

  return {
    estimatedDurationHours,
    speedOverGroundKts,
    predictedFuelMtPerDay: Number(predictedFuelMtPerDay.toFixed(1)),
    totalPredictedFuelMt: Number(totalPredictedFuelMt.toFixed(1)),
    fuelCostUsd: Math.round(fuelCostUsd),
    co2EmissionsTons: Number(co2EmissionsTons.toFixed(1)),
    admiraltyCoefficient: admiraltyCoeff,
    weatherFuelPenaltyPct: Number(weatherFuelPenaltyPct.toFixed(1)),
    currentBenefitKts: Number(currentBenefitKts.toFixed(1)),
    sfocGramsPerKwh
  };
}
