import { db } from '../db/index.ts';
import { weatherCache } from '../db/schema.ts';
import { desc, sql } from 'drizzle-orm';

export interface MetOceanData {
  latitude: number;
  longitude: number;
  waveHeightM: number;
  waveDirectionDeg: number;
  wavePeriodS: number;
  windSpeedKts: number;
  windDirectionDeg: number;
  currentSpeedKts: number;
  currentDirectionDeg: number;
  temperatureC: number;
  pressureHpa: number;
  isLive: boolean;
  source: string;
  timestamp: string;
}

export async function fetchRealMetOceanData(lat: number, lng: number): Promise<MetOceanData> {
  const roundedLat = Number(lat.toFixed(2));
  const roundedLng = Number(lng.toFixed(2));

  // 1. Check PostgreSQL cache first (valid within 30 minutes)
  try {
    const cachedRows = await db
      .select()
      .from(weatherCache)
      .where(sql`ABS(CAST(${weatherCache.lat} AS NUMERIC) - ${roundedLat}) < 0.25 AND ABS(CAST(${weatherCache.lng} AS NUMERIC) - ${roundedLng}) < 0.25`)
      .orderBy(desc(weatherCache.cachedAt))
      .limit(1);

    if (cachedRows.length > 0) {
      const cached = cachedRows[0];
      const ageMs = Date.now() - (cached.cachedAt ? new Date(cached.cachedAt).getTime() : 0);
      if (ageMs < 30 * 60 * 1000) {
        return {
          latitude: Number(cached.lat),
          longitude: Number(cached.lng),
          waveHeightM: Number(cached.waveHeightM),
          waveDirectionDeg: cached.waveDirectionDeg || 0,
          wavePeriodS: 6.5,
          windSpeedKts: Number(cached.windSpeedKts),
          windDirectionDeg: cached.windDirectionDeg || 0,
          currentSpeedKts: Number(cached.currentSpeedKts),
          currentDirectionDeg: 90,
          temperatureC: Number(cached.seaTempC || 28),
          pressureHpa: 1012,
          isLive: true,
          source: 'POSTGRESQL_METOCEAN_CACHE (Open-Meteo)',
          timestamp: cached.cachedAt ? new Date(cached.cachedAt).toISOString() : new Date().toISOString()
        };
      }
    }
  } catch (dbErr) {
    console.warn('PostgreSQL cache query error:', dbErr);
  }

  // 2. Fetch live from Open-Meteo Marine & Weather APIs
  try {
    const marineUrl = `https://marine-api.open-meteo.com/v1/marine?latitude=${roundedLat}&longitude=${roundedLng}&current=wave_height,wave_direction,wave_period,ocean_current_velocity,ocean_current_direction&timezone=GMT`;
    const weatherUrl = `https://api.open-meteo.com/v1/forecast?latitude=${roundedLat}&longitude=${roundedLng}&current=temperature_2m,wind_speed_10m,wind_direction_10m,surface_pressure&timezone=GMT`;

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 6000);

    const [marineRes, weatherRes] = await Promise.all([
      fetch(marineUrl, { signal: controller.signal }),
      fetch(weatherUrl, { signal: controller.signal })
    ]);

    clearTimeout(timeout);

    let waveHeight = 1.2;
    let waveDir = 180;
    let wavePeriod = 6.0;
    let currentSpeedKts = 0.8;
    let currentDir = 90;
    let windSpeedKts = 12.0;
    let windDir = 210;
    let tempC = 28.5;
    let pressure = 1012;

    if (marineRes.ok) {
      const marineData = await marineRes.json();
      if (marineData?.current) {
        waveHeight = marineData.current.wave_height ?? waveHeight;
        waveDir = marineData.current.wave_direction ?? waveDir;
        wavePeriod = marineData.current.wave_period ?? wavePeriod;
        // ocean_current_velocity in km/h -> convert to knots (1 km/h = 0.539957 knots)
        if (marineData.current.ocean_current_velocity != null) {
          currentSpeedKts = Number((marineData.current.ocean_current_velocity * 0.539957).toFixed(1));
        }
        currentDir = marineData.current.ocean_current_direction ?? currentDir;
      }
    }

    if (weatherRes.ok) {
      const weatherData = await weatherRes.json();
      if (weatherData?.current) {
        tempC = weatherData.current.temperature_2m ?? tempC;
        pressure = weatherData.current.surface_pressure ?? pressure;
        // wind_speed_10m in km/h -> convert to knots
        if (weatherData.current.wind_speed_10m != null) {
          windSpeedKts = Number((weatherData.current.wind_speed_10m * 0.539957).toFixed(1));
        }
        windDir = weatherData.current.wind_direction_10m ?? windDir;
      }
    }

    // 3. Store in PostgreSQL Cache
    try {
      await db.insert(weatherCache).values({
        lat: String(roundedLat),
        lng: String(roundedLng),
        waveHeightM: String(waveHeight),
        waveDirectionDeg: Math.round(waveDir),
        windSpeedKts: String(windSpeedKts),
        windDirectionDeg: Math.round(windDir),
        currentSpeedKts: String(currentSpeedKts),
        seaTempC: String(tempC),
        source: 'OPEN_METEO_MARINE_API'
      });
    } catch (insertErr) {
      console.warn('Failed to insert into weatherCache:', insertErr);
    }

    return {
      latitude: roundedLat,
      longitude: roundedLng,
      waveHeightM: Number(waveHeight.toFixed(1)),
      waveDirectionDeg: Math.round(waveDir),
      wavePeriodS: Number(wavePeriod.toFixed(1)),
      windSpeedKts: Number(windSpeedKts.toFixed(1)),
      windDirectionDeg: Math.round(windDir),
      currentSpeedKts: Number(currentSpeedKts.toFixed(1)),
      currentDirectionDeg: Math.round(currentDir),
      temperatureC: Number(tempC.toFixed(1)),
      pressureHpa: Math.round(pressure),
      isLive: true,
      source: 'OPEN_METEO_AUTHORITATIVE_API',
      timestamp: new Date().toISOString()
    };
  } catch (error) {
    console.error('Open-Meteo Marine API fetch error:', error);
    return {
      latitude: roundedLat,
      longitude: roundedLng,
      waveHeightM: 1.5,
      waveDirectionDeg: 190,
      wavePeriodS: 6.0,
      windSpeedKts: 14.0,
      windDirectionDeg: 215,
      currentSpeedKts: 0.9,
      currentDirectionDeg: 85,
      temperatureC: 28.0,
      pressureHpa: 1012,
      isLive: false,
      source: 'METOCEAN_DEGRADED_FALLBACK (API Unavailable)',
      timestamp: new Date().toISOString()
    };
  }
}
