import WebSocket from 'ws';
import type { Vessel, Coordinates } from '../types/maritime.ts';

export interface AisStreamStatus {
  isConfigured: boolean;
  provider: string;
  endpoint: string;
  status: 'LIVE_STREAM_ACTIVE' | 'UNAVAILABLE' | 'CONNECTING' | 'RECONNECTING' | 'ERROR';
  message: string;
  vesselsCount: number;
  lastPacketReceived: string | null;
}

export interface LiveAisVessel extends Partial<Vessel> {
  mmsi: string;
  shipName: string;
  lat: number;
  lng: number;
  speedKts: number;
  heading: number;
  courseOverGround: number;
  navStatus?: number;
  timestampUtc: string;
  source: 'AISStream.io';
}

class AisStreamManager {
  private ws: WebSocket | null = null;
  private isConnecting = false;
  private shouldReconnect = true;
  private reconnectAttempts = 0;
  private reconnectTimeout: NodeJS.Timeout | null = null;
  private liveVesselsMap = new Map<string, LiveAisVessel>();
  private lastPacketTime: string | null = null;
  private currentStatus: 'LIVE_STREAM_ACTIVE' | 'UNAVAILABLE' | 'CONNECTING' | 'RECONNECTING' | 'ERROR' = 'UNAVAILABLE';
  private statusMessage = 'AIS data temporarily unavailable';

  constructor() {
    // Lazy or immediate start when API key is detected
    this.init();
  }

  private getApiKey(): string | undefined {
    const key =
      process.env.AISSTREAM_API_KEY ||
      process.env.AIS_HUB_API_KEY ||
      process.env.AISHUB_API_KEY;
    if (!key || key.trim() === '' || key === 'MY_AISSTREAM_API_KEY') {
      return undefined;
    }
    return key.trim();
  }

  public init() {
    const apiKey = this.getApiKey();

    if (!apiKey) {
      this.currentStatus = 'UNAVAILABLE';
      this.statusMessage = 'AIS data temporarily unavailable';
      return;
    }

    this.connect();
  }

  private connect() {
    const apiKey = this.getApiKey();
    if (!apiKey) {
      this.currentStatus = 'UNAVAILABLE';
      this.statusMessage = 'AIS data temporarily unavailable';
      return;
    }

    if (this.isConnecting || (this.ws && this.ws.readyState === WebSocket.OPEN)) {
      return;
    }

    this.isConnecting = true;
    this.currentStatus = this.reconnectAttempts > 0 ? 'RECONNECTING' : 'CONNECTING';
    this.statusMessage = 'AIS data temporarily unavailable';

    try {
      console.log('AISStream.io: Connecting to wss://stream.aisstream.io/v0/stream...');
      this.ws = new WebSocket('wss://stream.aisstream.io/v0/stream');

      this.ws.on('open', () => {
        this.isConnecting = false;
        this.reconnectAttempts = 0;
        this.currentStatus = 'LIVE_STREAM_ACTIVE';
        this.statusMessage = 'Live AIS Data — AISStream.io';
        console.log('AISStream.io: WebSocket connection established. Sending subscription...');

        // Subscribe to real AIS PositionReport messages covering Indian Ocean, Arabian Sea, Bay of Bengal, and Malacca
        const subscriptionMessage = {
          APIKey: apiKey,
          BoundingBoxes: [
            // Arabian Sea & West Coast India (JNPT/Mumbai to Persian Gulf approach)
            [[6.0, 65.0], [24.0, 78.0]],
            // Bay of Bengal & East Coast India (Chennai, Colombo, Kolkata, Andaman)
            [[5.0, 78.0], [22.5, 95.0]],
            // Strait of Malacca & Singapore maritime corridor
            [[0.5, 95.0], [8.0, 105.0]]
          ],
          FilterMessageTypes: ['PositionReport', 'ShipStaticData']
        };

        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
          this.ws.send(JSON.stringify(subscriptionMessage));
          console.log('AISStream.io: Subscription message transmitted successfully.');
        }
      });

      this.ws.on('message', (data: WebSocket.RawData) => {
        try {
          const payload = JSON.parse(data.toString());
          this.handleIncomingMessage(payload);
        } catch (err) {
          // Ignore malformed packets silently
        }
      });

      this.ws.on('error', (err) => {
        console.warn('AISStream.io: WebSocket error:', err.message);
        this.currentStatus = 'ERROR';
        this.statusMessage = 'AIS data temporarily unavailable';
      });

      this.ws.on('close', (code, reason) => {
        this.isConnecting = false;
        this.ws = null;
        console.warn(`AISStream.io: WebSocket closed (code ${code}): ${reason.toString() || 'Connection closed'}`);
        this.currentStatus = 'UNAVAILABLE';
        this.statusMessage = 'AIS data temporarily unavailable';

        if (this.shouldReconnect) {
          this.scheduleReconnect();
        }
      });
    } catch (err: any) {
      this.isConnecting = false;
      this.currentStatus = 'ERROR';
      this.statusMessage = 'AIS data temporarily unavailable';
      console.error('AISStream.io: Failed to initialize WebSocket:', err.message);
      this.scheduleReconnect();
    }
  }

  private scheduleReconnect() {
    if (this.reconnectTimeout) {
      clearTimeout(this.reconnectTimeout);
    }
    this.reconnectAttempts++;
    // Exponential backoff with jitter: 5s, 10s, 20s, up to 60s
    const delayMs = Math.min(60000, Math.pow(2, Math.min(this.reconnectAttempts, 5)) * 1000 + Math.random() * 2000);
    console.log(`AISStream.io: Will attempt reconnect in ${(delayMs / 1000).toFixed(1)}s (attempt ${this.reconnectAttempts})`);

    this.reconnectTimeout = setTimeout(() => {
      this.connect();
    }, delayMs);
  }

  private handleIncomingMessage(packet: any) {
    if (!packet || !packet.MessageType) return;

    const meta = packet.MetaData;
    if (!meta || !meta.MMSI) return;

    const mmsi = String(meta.MMSI);
    const shipName = meta.ShipName?.trim() || `VESSEL ${mmsi}`;
    const timestampUtc = meta.time_utc || new Date().toISOString();
    this.lastPacketTime = timestampUtc;
    this.currentStatus = 'LIVE_STREAM_ACTIVE';
    this.statusMessage = 'Live AIS Data — AISStream.io';

    const existing = this.liveVesselsMap.get(mmsi) || {
      mmsi,
      shipName,
      lat: meta.latitude || 0,
      lng: meta.longitude || 0,
      speedKts: 0,
      heading: 0,
      courseOverGround: 0,
      timestampUtc,
      source: 'AISStream.io' as const
    };

    if (packet.MessageType === 'PositionReport') {
      const pos = packet.Message?.PositionReport;
      if (pos) {
        const lat = pos.Latitude ?? meta.latitude;
        const lng = pos.Longitude ?? meta.longitude;
        const speedKts = pos.Sog != null ? Number(pos.Sog.toFixed(1)) : existing.speedKts;
        const heading = pos.TrueHeading != null && pos.TrueHeading < 360 ? pos.TrueHeading : (pos.Cog != null ? Math.round(pos.Cog) : existing.heading);
        const cog = pos.Cog != null ? Number(pos.Cog.toFixed(1)) : existing.courseOverGround;

        // Discard 91/-91 or invalid coordinates
        if (lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180 && !(lat === 0 && lng === 0)) {
          this.liveVesselsMap.set(mmsi, {
            ...existing,
            shipName: shipName || existing.shipName,
            lat,
            lng,
            speedKts,
            heading,
            courseOverGround: cog,
            navStatus: pos.NavigationalStatus,
            timestampUtc,
            source: 'AISStream.io'
          });
        }
      }
    } else if (packet.MessageType === 'ShipStaticData') {
      const staticData = packet.Message?.ShipStaticData;
      if (staticData) {
        const cleanName = staticData.Name?.trim() || shipName;
        this.liveVesselsMap.set(mmsi, {
          ...existing,
          shipName: cleanName || existing.shipName,
          timestampUtc
        });
      }
    }

    // Prune stale vessels older than 2 hours if memory gets large (> 2000 vessels)
    if (this.liveVesselsMap.size > 2000) {
      const now = Date.now();
      for (const [key, v] of this.liveVesselsMap.entries()) {
        const age = now - new Date(v.timestampUtc).getTime();
        if (age > 2 * 60 * 60 * 1000) {
          this.liveVesselsMap.delete(key);
        }
      }
    }
  }

  public getStatus(): AisStreamStatus {
    const apiKey = this.getApiKey();
    const isConfigured = Boolean(apiKey);

    return {
      isConfigured,
      provider: 'AISStream.io',
      endpoint: 'wss://stream.aisstream.io/v0/stream',
      status: isConfigured ? this.currentStatus : 'UNAVAILABLE',
      message: isConfigured && this.currentStatus === 'LIVE_STREAM_ACTIVE'
        ? 'Live AIS Data — AISStream.io'
        : 'AIS data temporarily unavailable',
      vesselsCount: this.liveVesselsMap.size,
      lastPacketReceived: this.lastPacketTime
    };
  }

  public getLiveVessels(): LiveAisVessel[] {
    return Array.from(this.liveVesselsMap.values());
  }

  public shutdown() {
    this.shouldReconnect = false;
    if (this.reconnectTimeout) {
      clearTimeout(this.reconnectTimeout);
    }
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }
}

export const aisStreamManager = new AisStreamManager();
