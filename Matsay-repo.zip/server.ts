import express, { type Request, type Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { db, isDatabaseConfigured } from './src/db/index.ts';
import { sql } from 'drizzle-orm';
import {
  initializeDatabaseSeedIfEmpty,
  getAllVessels,
  getAllPorts,
  getAllAlerts,
  acknowledgeAlertInDb,
  getAllCommunications,
  insertCommunication,
  recordAuditLog,
  getAuditLogs
} from './src/services/vesselDatabaseService.ts';
import { fetchRealMetOceanData } from './src/services/metoceanService.ts';
import { aisStreamManager } from './src/services/aisStreamService.ts';
import { optionalAuth, requireAuth } from './src/middleware/auth.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);
const isProduction = process.env.NODE_ENV === 'production';

app.use(express.json());

// Initialize database data seed asynchronously on startup
initializeDatabaseSeedIfEmpty().catch(() => {
  // Handled gracefully by fallback dataset
});

// 1. Health and Integration Status Endpoint
app.get('/api/health', async (_req: Request, res: Response) => {
  let dbStatus = 'CONNECTED';
  if (!isDatabaseConfigured()) {
    dbStatus = 'FALLBACK_ACTIVE';
  } else {
    try {
      await db.execute(sql`SELECT 1`);
    } catch {
      dbStatus = 'DISCONNECTED';
    }
  }

  const ais = aisStreamManager.getStatus();

  res.json({
    status: 'ONLINE',
    service: 'MATSAY Fleet Command Center Backend',
    database: {
      type: 'Cloud SQL (PostgreSQL)',
      status: dbStatus
    },
    integrations: {
      metocean: {
        provider: 'Open-Meteo Marine & Atmospheric API',
        status: 'OPERATIONAL',
        rateLimit: 'Fair-use open cache active'
      },
      ais: ais,
      portsDataset: {
        authority: 'UN/LOCODE & World Port Index',
        status: 'OPERATIONAL'
      }
    },
    timestamp: new Date().toISOString()
  });
});

// 2. Authoritative Vessels API
app.get('/api/vessels', async (_req: Request, res: Response) => {
  try {
    const vesselRows = await getAllVessels();
    res.json(vesselRows);
  } catch {
    res.status(503).json({ error: 'Vessel data temporarily unavailable' });
  }
});

// 3. Real MetOcean Marine Weather API with PostgreSQL caching
app.get('/api/weather/live', async (req: Request, res: Response) => {
  try {
    const lat = parseFloat(req.query.lat as string) || 6.25;
    const lng = parseFloat(req.query.lng as string) || 78.4;

    const weather = await fetchRealMetOceanData(lat, lng);
    res.json(weather);
  } catch {
    res.status(503).json({ error: 'Weather data temporarily unavailable' });
  }
});

// 4. Unified AIS Server-Side Proxy Endpoints (/api/ais, /api/ais/status, /api/ais/vessels)
app.get('/api/ais', (_req: Request, res: Response) => {
  const status = aisStreamManager.getStatus();
  const liveVessels = aisStreamManager.getLiveVessels();

  res.json({
    available: status.status === 'LIVE_STREAM_ACTIVE',
    provider: status.provider,
    status: status.status,
    message: status.message,
    vesselsCount: liveVessels.length,
    vessels: liveVessels,
    lastUpdate: status.lastPacketReceived
  });
});

app.get('/api/ais/status', (_req: Request, res: Response) => {
  const status = aisStreamManager.getStatus();
  res.json(status);
});

app.get('/api/ais/vessels', (_req: Request, res: Response) => {
  const status = aisStreamManager.getStatus();
  const liveVessels = aisStreamManager.getLiveVessels();

  res.json({
    available: status.status === 'LIVE_STREAM_ACTIVE',
    provider: 'AISStream.io',
    message: status.message,
    vesselsCount: liveVessels.length,
    vessels: liveVessels,
    lastUpdate: status.lastPacketReceived
  });
});

// 5. Server-Side Google AI / Gemini Endpoint (/api/ai)
app.post('/api/ai', async (req: Request, res: Response) => {
  const apiKey = process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY;
  if (
    !apiKey ||
    apiKey.trim() === '' ||
    apiKey === 'MY_GEMINI_API_KEY' ||
    apiKey === 'MY_GOOGLE_API_KEY'
  ) {
    res.status(200).json({
      available: false,
      message: 'AI assistant is temporarily unavailable'
    });
    return;
  }

  try {
    const { query, fleetSummary } = req.body || {};
    if (!query || typeof query !== 'string') {
      res.status(400).json({ error: 'Invalid query parameter' });
      return;
    }

    const ai = new GoogleGenAI({ apiKey: apiKey.trim() });
    const systemPrompt = `You are MATSAY OPS, the operational intelligence assistant for the MATSAY Maritime Fleet Command Center.
Respond concisely (2-4 sentences) in an authoritative naval/maritime operations tone.
Base your analysis on the provided live fleet telemetry summary: ${
      fleetSummary ? JSON.stringify(fleetSummary) : '24 active Indian Ocean fleet units'
    }.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `${systemPrompt}\n\nCommander Query: ${query}`
    });

    const replyText = response.text?.trim();
    if (!replyText) {
      res.status(200).json({
        available: false,
        message: 'AI assistant is temporarily unavailable'
      });
      return;
    }

    res.json({
      available: true,
      reply: replyText,
      source: 'GEMINI_SERVER_PROXY'
    });
  } catch {
    res.status(200).json({
      available: false,
      message: 'AI assistant is temporarily unavailable'
    });
  }
});

// 6. Ports API
app.get('/api/ports', async (_req: Request, res: Response) => {
  try {
    const portRows = await getAllPorts();
    res.json(portRows);
  } catch {
    res.status(503).json({ error: 'Port data temporarily unavailable' });
  }
});

// 7. Alerts API
app.get('/api/alerts', async (_req: Request, res: Response) => {
  try {
    const alertRows = await getAllAlerts();
    res.json(alertRows);
  } catch {
    res.status(503).json({ error: 'Alerts temporarily unavailable' });
  }
});

app.post('/api/alerts/:id/ack', async (req: Request, res: Response) => {
  try {
    await acknowledgeAlertInDb(req.params.id);
    res.json({ success: true, id: req.params.id });
  } catch {
    res.status(503).json({ error: 'Failed to acknowledge alert' });
  }
});

// 8. Operational Communications API
app.get('/api/communications', async (_req: Request, res: Response) => {
  try {
    const comms = await getAllCommunications();
    res.json(comms);
  } catch {
    res.status(503).json({ error: 'Communications temporarily unavailable' });
  }
});

app.post('/api/communications', async (req: Request, res: Response) => {
  try {
    const { id, channel, sender, recipient, subject, body, urgent, status } = req.body;
    await insertCommunication({
      id: id || `msg-${Date.now()}`,
      channel: channel || 'Operations',
      sender: sender || 'Fleet Commander',
      recipient: recipient || 'Fleet Broadcast',
      subject: subject || 'Operational Notice',
      body: body || '',
      urgent: Boolean(urgent),
      status: status || 'SENT'
    });
    res.json({ success: true });
  } catch {
    res.status(503).json({ error: 'Failed to store communication' });
  }
});

// 9. Admiralty Audit Logs (Human-in-the-Loop)
app.get('/api/audit-logs', async (_req: Request, res: Response) => {
  try {
    const logs = await getAuditLogs();
    res.json(logs);
  } catch {
    res.status(503).json({ error: 'Audit trail temporarily unavailable' });
  }
});

app.post('/api/audit-logs', async (req: Request, res: Response) => {
  try {
    const { id, timestamp, commanderName, recommendationId, vesselName, action, notes } = req.body;
    await recordAuditLog({
      id: id || `audit-${Date.now()}`,
      timestamp: timestamp || new Date().toISOString(),
      commanderName: commanderName || 'Fleet Commander',
      recommendationId: recommendationId || 'rec-00',
      vesselName: vesselName || 'Fleet Unit',
      action: action || 'APPROVED',
      notes: notes || ''
    });
    res.json({ success: true });
  } catch {
    res.status(503).json({ error: 'Failed to record audit log' });
  }
});

// Mount Vite or static assets
async function startServer() {
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`MATSAY Fleet Command Center running on port ${PORT}`);
  });
}

export default app;

if (!process.env.VERCEL) {
  startServer().catch((err) => {
    console.error('Failed to start server:', err);
  });
}
